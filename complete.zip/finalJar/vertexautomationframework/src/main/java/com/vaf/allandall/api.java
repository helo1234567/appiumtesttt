package com.vaf.allandall;
import com.vaf.utils.Excel_Api;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import cucumber.api.java.en.And;

import org.testng.annotations.Test;


public class api {
    private String responsePlaceHolder = "#{}"; // Placeholder used in the JSON string for value replacement

    public Response PostRequest(String body, String header, String query, String endpoint, String post) {
        RestAssured.baseURI = "https://rahulshettyacademy.com";
        JSONObject headerJson = new JSONObject(header);
        Map<String, String> headers = new HashMap<>();

        // Extract key-value pairs from the JSON object and store them in the HashMap
        Iterator<String> keys = headerJson.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String value = headerJson.getString(key);
            headers.put(key, value);
        }

        RequestSpecification request = RestAssured.given().baseUri("https://rahulshettyacademy.com")
                .queryParam(query)
                .headers(headers)
                .body(body);

        Response response;

        if (post.equalsIgnoreCase("post")) {
            response = request.post(endpoint);
        } else if (post.equalsIgnoreCase("get")) {
            response = request.get(endpoint);
        } else {
            throw new IllegalArgumentException("Invalid request type: " + post);
        }
        System.out.println(response.asString());
        return response;
    }

    @Test
    @And("User sends {string} request at row <{int}> for endpoint {string}")
    public void Post_Req(String post, int index, String endpoint) throws IOException {
        ArrayList<String> data = Excel_Api.getData(post);
        String post1 = "posts";
        ArrayList<String> data1 = Excel_Api.getData(post1);
        Response postResponse = PostRequest(data.get(1), data.get(2), data.get(3), endpoint, post);

        String responseBody = postResponse.asString();

        // Iterate through the Excel column and replace #{} placeholders with corresponding values from the response
        for (int i = index + 1; i < data1.size(); i++) {
            String body = data1.get(i);
            String replacedBody = replacePlaceholders(body, responseBody);
            // Use the replacedBody for further processing
            // ...
            System.out.println("Replaced Body: " + replacedBody);
        }
    }

    private String replacePlaceholders(String body, String responseBody) {
        JSONObject bodyJson = new JSONObject(body);
        Iterator<String> keys = bodyJson.keys();

        while (keys.hasNext()) {
            String key = keys.next();
            String value = bodyJson.getString(key);

            if (value.startsWith("#") && value.endsWith("}")) {
                String placeholder = value.substring(2, value.length() - 1); // Extract placeholder without #{}
                String responseKey = value.replace("#{" + placeholder + "}", placeholder); // Get the placeholder without #{} for response search

                if (responseBody.contains(responseKey)) {
                    String responseValue = extractResponseValue(responseBody, responseKey);
                    bodyJson.put(key, responseValue);
                }
            }
        }

        return bodyJson.toString();
    }

    private String extractResponseValue(String responseBody, String responseKey) {
        JSONObject responseJson = new JSONObject(responseBody);
        return responseJson.optString(responseKey);
    }
}






