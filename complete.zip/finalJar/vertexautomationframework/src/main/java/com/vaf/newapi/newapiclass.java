package com.vaf.newapi;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class newapiclass {

    public Response PostRequest(String body, String header, String query, String endpoint, String post) {
        RestAssured.baseURI = "https://rahulshettyacademy.com";
        JSONObject headerJson = new JSONObject(header);
        Map<String, String> headers = new HashMap<>();

        // Extract key-value pairs from the JSON object and store them in the HashMap
        Iterator<String> keys = headerJson.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String value = headerJson.getString(key);
            headers.put(key, value);
        }

        RequestSpecification request = RestAssured.given().baseUri("https://rahulshettyacademy.com")
                .queryParam(query)
                .headers(headers)
                .body(body);

        Response response;

        if (post.equalsIgnoreCase("post")) {
            response = request.post(endpoint);
        } else if (post.equalsIgnoreCase("get")) {
            response = request.get(endpoint);
        } else {
            throw new IllegalArgumentException("Invalid request type: " + post);
        }
        System.out.println(response.asString());
        return response;

    }
}