package com.charter.utils;

import java.io.File;  
import java.io.FileInputStream;  
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;  
import org.apache.poi.hssf.usermodel.HSSFWorkbook;  
import org.apache.poi.ss.usermodel.Cell;  
import org.apache.poi.ss.usermodel.FormulaEvaluator;  
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.util.CellUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHSSFUtility {

	private static String MOCK_FILE_PATH = "mock_datashee.xls";
	private static String LOCATOR_FILE_PATH = "locators_datashee.xls";

	public static List<String> valuesFor(String key) {
		List<String> values = new ArrayList<String>();

		try {

			File file;
			try {
				file = getFileFromURL(MOCK_FILE_PATH);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("File not found: " + e.getMessage());
				return null;
			}


			FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file
			//creating Workbook instance that refers to .xlsx file
			HSSFWorkbook wb = new HSSFWorkbook(fis);
			HSSFSheet sheet = wb.getSheetAt(0);     //creating a Sheet object to retrieve object
			Iterator<Row> itr = sheet.iterator();    //iterating over excel file

			Integer rowIndex = 0;
			Integer foundIndex = -1;
			while (itr.hasNext()) {
				Row row = itr.next();
				Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column

				Integer cellIndex = 0;

				if (foundIndex < 0) {
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();
						if ( cell.getStringCellValue().equals(key) ) {
							foundIndex = cellIndex;
							break;
						}

						cellIndex++;
					}
				} else {
					Cell cellVal = CellUtil.getCell(row, foundIndex);
					values.add(cellVal.getStringCellValue());
				}

			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		values.removeIf(entries->entries.isEmpty());

		return values;
	}

	public static String locatorFor(String compoundKey) {

		String sheetName = compoundKey.split("[.]")[0];
		String key = compoundKey.split("[.]")[1];

		List<String> values = new ArrayList<String>();

		try {

			File file;
			try {
				file = getFileFromURL(LOCATOR_FILE_PATH);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("File not found: " + e.getMessage());
				return null;
			}


			FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file
			//creating Workbook instance that refers to .xlsx file
			HSSFWorkbook wb = new HSSFWorkbook(fis);
			HSSFSheet sheet = wb.getSheet(sheetName);//wb.getSheetAt(0);     //creating a Sheet object to retrieve object

			Iterator<Row> itr = sheet.iterator();    //iterating over excel file

			Integer rowIndex = 0;
			Boolean foundIndex = false;
			while (itr.hasNext())   {
				Row row = itr.next();
				Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column

				Integer cellIndex = 0;

				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();

					if (foundIndex) {
						return cell.getStringCellValue();
					}


					if ( cell.getStringCellValue().equals(key) ) {
						foundIndex = true;
					} else {
						break;
					}

					//System.out.println("CELL: " + cell.getStringCellValue());

					cellIndex++;
				}

//				if (!foundIndex) {
//
//				} else {
//					Cell cellVal = CellUtil.getCell(row, foundIndex);
//					values.add(cellVal.getStringCellValue());
//				}

			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		//values.removeIf(entries->entries.isEmpty());

		return null;
	}

	private static File getFileFromURL(String filePath) throws URISyntaxException {
		URL url = new ExcelHSSFUtility().getClass().getClassLoader().getResource(filePath);
		File file = null;
		file = new File(url.toURI());
		return file;
	}
	
}  