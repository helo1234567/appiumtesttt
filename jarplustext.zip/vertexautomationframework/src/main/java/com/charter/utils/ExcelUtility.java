package com.charter.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
public class ExcelUtility {

    public static String locatorFor(String filePath, String compoundKey) {

        String extension = getFileExtension(filePath);

        if (extension.equalsIgnoreCase("xls")) {
            return locatorForHSSF(filePath, compoundKey);
        } else if (extension.equalsIgnoreCase("xlsx")) {
            return locatorForXSSF(filePath, compoundKey);
        } else {
            System.out.println("Unsupported file type: " + extension);
            return null;
        }
    }

    private static String getFileExtension(String filePath) {
        int lastIndex = filePath.lastIndexOf('.');
        if (lastIndex == -1) {
            return "";
        }
        return filePath.substring(lastIndex + 1);
    }

    private static String locatorForHSSF(String filePath, String compoundKey) {

        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];

        try {
            File file = new File(filePath);

            FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file
            //creating Workbook instance that refers to .xls file
            HSSFWorkbook wb = new HSSFWorkbook(fis);
            HSSFSheet sheet = wb.getSheet(sheetName);//wb.getSheetAt(0);     //creating a Sheet object to retrieve object

            Iterator<Row> itr = sheet.iterator();    //iterating over excel file

            Integer rowIndex = 0;
            Boolean foundIndex = false;
            while (itr.hasNext())   {
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column

                Integer cellIndex = 0;

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (foundIndex) {
                        return cell.getStringCellValue();
                    }

                    if (cell.getStringCellValue().equals(key)) {
                        foundIndex = true;
                    } else {
                        break;
                    }

                    //System.out.println("CELL: " + cell.getStringCellValue());

                    cellIndex++;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static String locatorForXSSF(String filePath, String compoundKey) {
        // XSSF implementation
        // ...
        return null;
    }

//    String filePath = "path/to/excel/file.xls";
//    String compoundKey = "Sheet1.key1";
//    String locator = ExcelHSSFUtility.locatorFor(filePath, compoundKey);
}
