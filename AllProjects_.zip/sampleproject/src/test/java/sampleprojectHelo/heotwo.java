package sampleprojectHelo;

import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import java.io.FileInputStream;
import java.io.File;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.messages.types.Duration;

public class heotwo {
	
	public enum LocatorType { 
		xpath,
		cssSelector, 
		cssId, 
		cssClass,
	}
	
	static WebDriver driver=new FirefoxDriver();
	//static WebDriver driver=new ChromeDriver();
	
	heoone object =new heoone(driver);
	
	
	@BeforeAll
	public static void before() {
//		 ChromeOptions chromeOptions = new ChromeOptions();
//		 chromeOptions.addArguments("--remote-allow-origins=*");
//		 ChromeDriver driver = new ChromeDriver(chromeOptions);
//		 System.setProperty("webdriver.http.factory", "jdk-http-client");
		 //System.setProperty("webdriver.chrome.driver","C:\\Users\\Hassan\\Desktop\\chromedriver_win32 (3)\\chromedriver.exe");
		 System.setProperty("webdriver.gecko.driver","C:\\Users\\DELL\\Downloads\\geckodriver-v0.33.0-win32\\geckodriver.exe");
		 //driver.get("https://www.spectrum.com/");
		
	}
	
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) throws IOException {

	driver.get(url);
	
	
	}
	

	@When("Maximixe the window")
	public void Maximixw_window1() throws IOException {

	
		 driver.manage().window().maximize();
	
	}
	

	
	@Then("Close the Browser")
	public void Close_Browser() throws IOException {
		driver.close();

	}
	@When("user click on {string}")
	 public void Click(String locatorName) throws IOException {
		 
	
		 
		
	FileInputStream file = new FileInputStream(new File("./src/test/resources/excel/locators.xlsx"));
       XSSFWorkbook workbook = new XSSFWorkbook(file);
       XSSFSheet sheet = workbook.getSheetAt(0);

      
       for (Row row : sheet) {
          
           Cell cell = row.getCell(0);
           if (cell.getStringCellValue().equals(locatorName)) {
              
               String locatorValue = row.getCell(1).getStringCellValue();
               String locatortype=row.getCell(2).getStringCellValue(); 
               driver.findElement(By.xpath(locatorValue)).click();
               break;
           }
       }

       
   }

	
	
	
	@When("user {string} on {string}")
	 public void Clicks(String action,String locatorName) throws IOException {
		
		if (action.equals("click"))
		{
	        object.onlyclick(locatorName);
	    } 
		else if (action.equals("hover")) 
		{
	        object.getLocatorData(locatorName);
	    } else 
	    {
	        System.out.println("Unexpected action: " + action);
	    }
		 

	
	}
	@Then("get attribute of MobileTab")
	public void Verify_URL() {
		
		String attribute=object.getAttribute(object.Hover_Mobile_Tab, "title");
		System.out.println(attribute);
	    
	}
	
	@Then("change Tab")
	public void Change_tab() throws IOException, InterruptedException {
		
		//WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(100));
		Actions act=new Actions(driver);
		//wait.until(ExpectedConditions.visibilityOf(object.Hover_Mobile_Tab));
	
			act.sendKeys(Keys.PAGE_UP).build().perform();
			act.sendKeys(Keys.PAGE_UP).build().perform();
			Thread.sleep(5000);
			object.make_reservation.click();
			Thread.sleep(5000);
		    object.switchToTab(1);
		    driver.close();

	}
	

}
