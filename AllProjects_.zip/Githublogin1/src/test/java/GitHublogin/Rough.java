package GitHublogin;

import static org.testng.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert.*;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Rough {
	
	
	SoftAssert softassert=new SoftAssert();
	
	@Test(description="Login with real data")
	public void SuccessfulLogin() throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("helo1234567");
		driver.findElement(By.id("password")).sendKeys("Asad777&");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		softassert.assertEquals(driver.getTitle(), "GitHub");
		driver.close();
		

	}

	@Test(description="Login with fake data")
	public void UnsuccesfulLogin() throws InterruptedException  {
		WebDriver driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("helo1234");
		driver.findElement(By.id("password")).sendKeys("Asad77");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		String actualTitle=driver.getTitle();
		String expectedTitle="Sign in to GitHub · GitHub";
		softassert.assertEquals(actualTitle, expectedTitle );
		driver.close();
	}
	@Test(description="Login with Null values")
	public void UnsuccesfulLogin1() throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("");
		driver.findElement(By.id("password")).sendKeys("");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		softassert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
		driver.close();
	    

	}
	@Test(description="Login with Invalid data")
	public void UnsuccesfulLogin2() throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("@##$@@!$");
		driver.findElement(By.id("password")).sendKeys("!@#$%$#@#@");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		softassert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
		driver.close();
	}
	@Test(description="After Login search something")
	public void search() throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("helo1234567");
		driver.findElement(By.id("password")).sendKeys("Asad777&");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("q")).sendKeys("Testerw"+Keys.ENTER);
		softassert.assertEquals(driver.getTitle(), "Search · Testerw");
		driver.close();
	}

}
