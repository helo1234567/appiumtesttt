package GitHublogin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class GitLoginnn {
	
	WebDriver driver=new ChromeDriver();
	
	@BeforeMethod
	public void openGitHub() {
		driver.get("https://github.com/login");
	}
	
	@AfterMethod
	public void closetab() {
		driver.close();
	}
	
	@Test(description="Login with real data")
	public void SuccessfulLogin() {
		
	    driver.findElement(By.id("login_field")).sendKeys("helo1234567");
		driver.findElement(By.id("password")).sendKeys("Asad777&");
		driver.findElement(By.name("commit")).click();
		Assert.assertEquals(driver.getTitle(), "GitHub");
		

	}

	@Test(description="Login with fake data")
	public void UnsuccesfulLogin() throws InterruptedException {
		
		driver.findElement(By.id("login_field")).sendKeys("helo1234");
		driver.findElement(By.id("password")).sendKeys("Asad77");
		driver.findElement(By.name("commit")).click();
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");

	}
	@Test(description="Login with Null values")
	public void UnsuccesfulLogin1() {
		
		driver.findElement(By.id("login_field")).sendKeys("");
		driver.findElement(By.id("password")).sendKeys("");
		driver.findElement(By.name("commit")).click();
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
	    
	    

	}
	@Test(description="Login with Invalid data")
	public void UnsuccesfulLogin2() {
		
		driver.findElement(By.id("login_field")).sendKeys("@##$@@!$");
		driver.findElement(By.id("password")).sendKeys("!@#$%$#@#@");
		driver.findElement(By.name("commit")).click();
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
	}
	@Test(description="After Login search something")
	public void search() {
		
		driver.findElement(By.id("login_field")).sendKeys("helo1234567");
		driver.findElement(By.id("password")).sendKeys("Asad777&");
		driver.findElement(By.name("commit")).click();
		driver.findElement(By.name("q")).sendKeys("Testerw"+Keys.ENTER);
		Assert.assertEquals(driver.getTitle(), "Search · Testerw");
	}

}
