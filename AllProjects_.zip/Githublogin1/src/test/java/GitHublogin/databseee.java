package GitHublogin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.checkerframework.framework.qual.FromByteCode;
import org.openqa.selenium.support.ui.Select;

public class databseee {

	public static void main(String[] args) {
		try
        {
            Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");

           // String userName = "sa";
         //   String password = "password";
            String connstring = "jdbc:sqlserver:DESKTOP-DJNQI78\\MSSQLSERVER01;"+"databaseName=master;integratedSecurity=true;";
            Connection conn = DriverManager.getConnection(connstring);
            Statement stmt = conn.createStatement();
            String query="SELECT * FROM LOGING"; 
            ResultSet rs = stmt.executeQuery(query);
            String[] result = new String[20];
            
            while (rs.next()){
            	System.out.println(rs.getString(1)+" "+rs.getString(2));
            }
        
        }
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
