package GitHublogin;



import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import graphql.Assert;

public class kuchbhi {
	
	
		@Test
		public void Task1() throws InterruptedException {
			WebDriver driver=new ChromeDriver();
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
			driver.manage().window().maximize();
			driver.get("https://omayo.blogspot.in/");
			WebElement entername=driver.findElement(By.xpath("//textarea[@id='ta1']"));
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@id='ta1']")));
			entername.sendKeys("Asad Raza Mahmood");
			WebElement description =driver.findElement(By.xpath("//*[@id=\"HTML11\"]/div[1]/textarea"));
			description.clear();
			description.sendKeys("helo asad");
			Assert.assertNotNull(entername);
			
			}
			@Test
			public void Task2() {
				WebDriver driver=new ChromeDriver();
				driver.get("https://omayo.blogspot.in/");
				String t1=driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]")).getText();
				String t2=driver.findElement(By.xpath("//table/tbody/tr[1]/td[2]")).getText();
				String t3=driver.findElement(By.xpath("//table/tbody/tr[1]/td[3]")).getText();
				System.out.println(t1+" "+t2+" "+t3); 
				
				
				String t4=driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]")).getText();
				String t5=driver.findElement(By.xpath("//table/tbody/tr[2]/td[2]")).getText();
				String t6=driver.findElement(By.xpath("//table/tbody/tr[2]/td[3]")).getText();
				System.out.println(t4+" "+t5+" "+t6); 
				
				String t7=driver.findElement(By.xpath("//table/tbody/tr[3]/td[1]")).getText();
				String t8=driver.findElement(By.xpath("//table/tbody/tr[2]/td[3]")).getText();
				String t9=driver.findElement(By.xpath("//table/tbody/tr[2]/td[3]")).getText();
				System.out.println(t7+" "+t8+" "+t9); 
				String t10=driver.findElement(By.xpath("//table/tbody/tr[4]/td[1]")).getText();
				String t11=driver.findElement(By.xpath("//table/tbody/tr[4]/td[2]")).getText();
				String t12=driver.findElement(By.xpath("//table/tbody/tr[4]/td[3]")).getText();
				System.out.println(t10+" "+t11+" "+t12); 
				
				driver.findElement(By.xpath("//input[@type='text']")).sendKeys("asad");
				driver.findElement(By.xpath("//input[@type='password']")).sendKeys("helo");
				driver.findElement(By.xpath("//button[@type='button' and @value='LogIn']")).click();
				
				
				
			}
			
			@Test
			public void Task3() throws InterruptedException {
				WebDriver driver=new ChromeDriver();
				driver.get("https://omayo.blogspot.in/");
				String newwindow=driver.getWindowHandle();
				
				WebElement frame1=driver.findElement(By.xpath("//iframe[@id='iframe1']"));
				driver.switchTo().frame(frame1);
				driver.switchTo().window(newwindow);
				WebElement frame2=driver.findElement(By.xpath("//iframe[@id='iframe2']"));
				driver.switchTo().frame(frame2);
				driver.switchTo().window(newwindow);
				
				driver.findElement(By.xpath("//input[@type='text' and @name='userid' ]")).sendKeys("asad");
				driver.findElement(By.xpath("//input[@type='password' and @name='pswrd' ]")).sendKeys("helo");
				driver.findElement(By.xpath("//input[@type='button' and @value='Login' ]")).click();
				Thread.sleep(3000);
				Alert alert=driver.switchTo().alert();
				alert.accept();
				
			
				
			}
			
			@Test
			public void Task4() throws InterruptedException {
				WebDriver driver=new ChromeDriver();
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
				driver.get("https://omayo.blogspot.in/");
				String newwindow=driver.getWindowHandle();
				
				driver.findElement(By.xpath("//option[@value='Hyundaix']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='drop1']")));
				WebElement dropdown=driver.findElement(By.xpath("//select[@id='drop1']"));
				Select select= new Select(dropdown);
				select.selectByVisibleText("doc 3");
				Thread.sleep(3000);
				WebElement unm5=driver.findElement(By.xpath("//input[@name='fname']"));
				unm5.clear();
				unm5.sendKeys("Hello World");
				Thread.sleep(3000);
				driver.findElement(By.xpath("//button[@id='but2']")).click();
				Thread.sleep(3000);
				driver.findElement(By.xpath("//button[text()='Submit']")).click();
				Thread.sleep(3000);
				driver.findElement(By.xpath("//button[text()='Login']")).click();
				Thread.sleep(3000);
				driver.findElement(By.xpath("//button[text()='Register']")).click();
				Thread.sleep(3000);
				
				driver.findElement(By.xpath("//input[@id='alert2']")).click();
				Thread.sleep(3000);
				Alert alert1=driver.switchTo().alert();
				alert1.accept();
				
				driver.findElement(By.xpath("//a[text()='Open a popup window']")).click();
				java.util.Set<String> handles=driver.getWindowHandles();
				
				for(String handle:handles) {
					if(!handle.equals(newwindow)) {
						driver.switchTo().window(handle);
						String text=driver.findElement(By.xpath("//body")).getText();
						
						System.out.println(text);
					}
					
				}
				driver.switchTo().window(newwindow);
				
				driver.findElement(By.xpath("//button[text()='Try it']")).click();
				Thread.sleep(3000);
				Actions act = new Actions(driver);

				//Double click on element
				WebElement ele = driver.findElement(By.xpath("//button[text()=' Double click Here   ']")); 
				act.doubleClick(ele).perform();
				Thread.sleep(3000);
				Alert alert2=driver.switchTo().alert();
				alert2.accept();
				
				driver.findElement(By.xpath("//button[text()='Check this']")).click();
				Thread.sleep(12000);
				
				driver.findElement(By.xpath("//input[@id='dte']")).click();
				
			}
			
			@Test
			public void Task5() throws InterruptedException {
				
				WebDriver driver=new ChromeDriver();
				driver.get("https://omayo.blogspot.in/");
				driver.findElement(By.xpath("//input[@id='radio1']")).click();
				driver.findElement(By.xpath("//input[@id='alert1']")).click();
				Thread.sleep(3000);
				Alert alert2=driver.switchTo().alert();
				alert2.accept();
				
				driver.findElement(By.xpath("//input[@id='checkbox2']")).click();
				Thread.sleep(3000);
				driver.findElement(By.xpath("//input[@id='checkbox1']")).click();
				Thread.sleep(3000);
				
				String t15=driver.findElement(By.xpath("//input[@id='rotb']")).getText();
				System.out.println("t15");
				Thread.sleep(3000);
				
				driver.findElement(By.xpath("//input[@id='prompt']")).click();
				Thread.sleep(3000);
				driver.switchTo().alert().sendKeys("asad");
				driver.switchTo().alert().accept();
				
				driver.findElement(By.xpath("//input[@id='confirm']")).click();
				Thread.sleep(3000);
				driver.switchTo().alert().dismiss();
				
				driver.findElement(By.xpath("//input[@class='classone' and @type='text' ]")).sendKeys("kuch bhi");
				Thread.sleep(3000);
				driver.findElement(By.xpath("//input[@class='classone' and @type='text' ]")).sendKeys("waoooo");
				Thread.sleep(3000);
				driver.findElement(By.xpath("//input[@value='Car']")).click();
				Actions act = new Actions(driver);

				//Double click on element
				WebElement ele1 = driver.findElement(By.xpath("//input[@value='Bag']")); 
				act.doubleClick(ele1).perform();
				Thread.sleep(3000);
				driver.findElement(By.xpath("//input[@value='Book']")).click();
				Thread.sleep(3000);
				driver.findElement(By.xpath("//input[@value='Bag']")).click();
				Thread.sleep(3000);
				
				WebElement ele2 = driver.findElement(By.xpath("//button[@class='dropbtn']")); 
				act.doubleClick(ele2).perform();
				
				Select select= new Select(ele2);
				select.selectByVisibleText("Facebook");
				
				//driver.findElement(By.xpath("//a[text()='Facebook']")).click();
				
				
			}

}
