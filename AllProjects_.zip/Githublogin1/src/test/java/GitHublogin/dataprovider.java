package GitHublogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataprovider {
	WebDriver driver;
	@Test(dataProvider="logindetails")
	public void SuccessfulLogin(String username,String password) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
		driver.get("https://github.com/login");
		driver.manage().window().maximize();
		driver.findElement(By.id("login_field")).sendKeys(username);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.findElement(By.name("commit")).click();
		Assert.assertEquals(driver.getTitle(), "GitHub");
		

	}
	@DataProvider( name="logindetails")
	public Object[][] login(){
		
		Object [][] data=new Object[1][2]; 
		data[0][0]="helo1234567";
		data[0][1]="Asad777&";
		
		return data;
		
	}
	
}
