package GitHublogin;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Takinfromusernew {
	WebDriver driver;
   
   
	@Test
	public void openGitHub() {
    	
    		driver=new ChromeDriver();
    		driver.manage().window().maximize();
    		//driver.get("https://github.com/login");
    	 }
	
	/*@AfterMethod
	public void closetab() {
		driver.close();
	}*/
	
	@Test(groups={"asad","hassan"},dependsOnMethods={"openGitHub"})
	public void UnSuccessfulLogin() throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("helo123");
		driver.findElement(By.id("password")).sendKeys("Asad456789");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
		driver.close();
		

	}

	@Test(groups={"hassan","asadd"},dependsOnMethods={"openGitHub"})
	public void succesfulLogin() throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("helo1234567");
		driver.findElement(By.id("password")).sendKeys("Asad777&");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getTitle(), "GitHub");
		driver.close();
	}
	@Test(groups={"raza","hassan"},dependsOnMethods={"openGitHub"})
	public void UnsuccesfulLogin1() throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("");
		driver.findElement(By.id("password")).sendKeys("");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
		driver.close();
	    

	}
	@Test(groups={"mahmood","asad"},dependsOnMethods={"openGitHub"})
	public void UnsuccesfulLogin2() throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("@##$@@!$");
		driver.findElement(By.id("password")).sendKeys("!@#$%$#@#@");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getTitle(), "Sign in to GitHub · GitHub");
		driver.close();
	}
	@Test(groups={"flowofasad","hassan"},dependsOnMethods={"openGitHub"})
	public void search() throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		driver.findElement(By.id("login_field")).sendKeys("helo1234567");
		driver.findElement(By.id("password")).sendKeys("Asad777&");
		driver.findElement(By.name("commit")).click();
		Thread.sleep(2000);
		driver.findElement(By.name("q")).sendKeys("Testerw"+Keys.ENTER);
		//Assert.assertEquals(driver.getTitle(), "Search · Testerw");
		WebElement Allcourses=driver.findElement(By.xpath("//span[contains(text(),'Best match')]"));
		Assert.assertEquals(true, Allcourses.isDisplayed());
		driver.close();
	}


}
