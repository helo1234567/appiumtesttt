package GitHublogin;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Rough1234566 {

	public static void main(String[] args) {
		
		String t4=driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]")).getText();
		String t5=driver.findElement(By.xpath("//table/tbody/tr[2]/td[2]")).getText();
		String t6=driver.findElement(By.xpath("//table/tbody/tr[2]/td[3]")).getText();
		System.out.println(t4+" "+t5+" "+t6); 

	}

}
