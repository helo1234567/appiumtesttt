package GitHublogin;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import graphql.Assert;

public class declab3 {
	
	WebDriver driver;
	
	//Initialize Driver and get Website before every method
	@BeforeMethod
	public void openwebsite() throws InterruptedException {
			
    		driver=new ChromeDriver();
    		driver.manage().window().maximize();
    		driver.get("https://omayo.blogspot.in/");
    		
    	
    		}
	//close window after every method
    @AfterMethod
	public void closetab() throws InterruptedException {
		driver.close();
		
	}
    
   
    
	@Test(description="Enter name and description in two text boxes")
	public void Task1() throws InterruptedException {
		//initialize object of wait
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		WebElement entername=driver.findElement(By.xpath("//textarea[@id='ta1']"));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@id='ta1']")));
		//send name inside box
		entername.sendKeys("Asad Raza Mahmood");
		//get text of second box
		String gettext=driver.findElement(By.xpath("//textarea[@rows=10 and @cols=30]")).getText();
		WebElement description =driver.findElement(By.xpath("//textarea[@rows=10 and @cols=30]"));
		//clear text inside the box
		description.clear();
		//send keys inside the box
		description.sendKeys("helo asad");
		Assert.assertNotNull(entername);
		//print get text 
		System.out.println(gettext);
		Thread.sleep(3000);
	
		
		}
	
	@Test(description="Print table ")
	public void Task2() {
		//find table 
		WebElement printtable=driver.findElement(By.xpath("//*[@id='table1']"));
		//stored rows values in list
		List<WebElement> rows=printtable.findElements(By.tagName("tr"));
		List<WebElement> headings=printtable.findElements(By.tagName("th"));
		for(int i=0;i<headings.size();i++) {
			System.out.print(headings.get(i).getText()+"  ");
			
		}
		for(int i=0;i<rows.size();i++) {
			List<WebElement>  coloms= rows.get(i).findElements(By.tagName("td"));
			
			for(int j=0;j<coloms.size();j++) {
				System.out.print(coloms.get(j).getText()+"  ");
			}
			System.out.println("  ");
		}
			
	}
	@Test(description="Enter login details")
	public void Task2_login() throws InterruptedException {
		
		driver.findElement(By.xpath("//form[contains(text(),'Username: ')]//child::input[@type='text']")).sendKeys("asad");
		driver.findElement(By.xpath("//form[contains(text(),'Username: ')]//child::input[@type='password']")).sendKeys("1234566");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[@type='button' and @value='LogIn']")).click();
		assertEquals(driver.getTitle(), "omayo (QAFox.com)");
		
		}
	@Test(description="Switch frames ")
	public void Task3() throws InterruptedException {
		//Initialize parent window handle 
		String newwindow=driver.getWindowHandle();
		//find first frame
		WebElement frame1=driver.findElement(By.xpath("//iframe[@id='iframe1']"));
		//switch to frame
		driver.switchTo().frame(frame1);
		//switch to window again
		driver.switchTo().window(newwindow);
		assertEquals(driver.getTitle(), "omayo (QAFox.com)");
		WebElement frame2=driver.findElement(By.xpath("//iframe[@id='iframe2']"));
		driver.switchTo().frame(frame2);
		driver.switchTo().window(newwindow);
		assertEquals(driver.getTitle(), "omayo (QAFox.com)");
		
		
	
}
	@Test(description="Enter login details and handle alert")
	public void Task3_login() throws InterruptedException {
		
		driver.findElement(By.xpath("//input[@type='text' and @name='userid' ]")).sendKeys("asad");
		driver.findElement(By.xpath("//input[@type='password' and @name='pswrd' ]")).sendKeys("helo");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@type='button' and @value='Login' ]")).click();
		Thread.sleep(3000);
		//handle popup
		Alert alert=driver.switchTo().alert();
		alert.accept();
		assertEquals(driver.getTitle(), "omayo (QAFox.com)");
		
		}
	
	
	@Test
	public void Task4() throws InterruptedException {
		
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		//Initialize parent window
		String newwindow=driver.getWindowHandle();
		//click on Hyundaix
		driver.findElement(By.xpath("//option[@value='Hyundaix']")).click();
		Thread.sleep(3000);
		//select doc 3 from dropdown
		WebElement dropdown=driver.findElement(By.xpath("//select[@id='drop1']"));
		Select select= new Select(dropdown);
		Thread.sleep(3000);
		select.selectByVisibleText("doc 3");
		Thread.sleep(3000);
		//clear text from box and send helo world
		WebElement unm5=driver.findElement(By.xpath("//input[@name='fname']"));
		unm5.clear();
		unm5.sendKeys("Hello World");
		Thread.sleep(3000);
		//click on enabled button
		driver.findElement(By.xpath("//button[@id='but2']")).click();
		Thread.sleep(3000);
		//click on submit button
		driver.findElement(By.xpath("//button[text()='Submit']")).click();
		Thread.sleep(3000);
		//click on Login button
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		Thread.sleep(3000);
		//click on register button
		driver.findElement(By.xpath("//button[text()='Register']")).click();
		Thread.sleep(3000);
		//click on (click after text disappears) button & handle alert
		driver.findElement(By.xpath("//input[@id='alert2']")).click();
		Alert alert1=driver.switchTo().alert();
		alert1.accept();
		//click on popup button
		driver.findElement(By.xpath("//a[text()='Open a popup window']")).click();
		//switch to windows and get text of child window
		java.util.Set<String> handles=driver.getWindowHandles();
		
		for(String handle:handles) {
			if(!handle.equals(newwindow)) {
				driver.switchTo().window(handle);
				String text=driver.findElement(By.xpath("//body")).getText();
				
				System.out.println(text);
				driver.close();
			}
			
			
		}
		//switch to parent window
		driver.switchTo().window(newwindow);
		//click on try button
		driver.findElement(By.xpath("//button[text()='Try it']")).click();
		Thread.sleep(3000);
		Actions act = new Actions(driver);
		//Double click on element
		WebElement ele = driver.findElement(By.xpath("//button[text()=' Double click Here   ']")); 
		Thread.sleep(3000);
		act.doubleClick(ele).perform();
		Thread.sleep(3000);
		//handle alert
		Alert alert2=driver.switchTo().alert();
		alert2.accept();
		//click on check this button
		driver.findElement(By.xpath("//button[text()='Check this']")).click();
		//wait until the checkbox is enabled
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='dte']"))).isEnabled();
		driver.findElement(By.xpath("//input[@id='dte']")).click();
		
	}
	
	@Test
	public void Task5() throws InterruptedException {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(6));
		//click on male
		driver.findElement(By.xpath("//input[@id='radio1']")).click();
		Thread.sleep(3000);
		//click on (click to get alert) and handle elert
		driver.findElement(By.xpath("//input[@id='alert1']")).click();
		Thread.sleep(3000);
		Alert alert2=driver.switchTo().alert();
		alert2.accept();
		//select blue color and deselect orange
		driver.findElement(By.xpath("//input[@id='checkbox2']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id='checkbox1']")).click();
		Thread.sleep(3000);
		//read text of box and print
		WebElement innertext=driver.findElement(By.xpath("//input[@id='rotb']"));
		innertext.isDisplayed();
		//System.out.println(innertext);
		Thread.sleep(3000);
		//click on getprompt and handle alert
		driver.findElement(By.xpath("//input[@id='prompt']")).click();
		Thread.sleep(2000);
		 
		driver.switchTo().alert().sendKeys("asad");
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
		//click on getconfirmation and handlealert 
		driver.findElement(By.xpath("//input[@id='confirm']")).click();
		Thread.sleep(3000);
		driver.switchTo().alert().dismiss();
		//send keys to first box
		driver.findElement(By.xpath("//div[@id='HTML24']/child::div/input[@class='classone']")).sendKeys("kuch bhi");
		Thread.sleep(3000);
		//send keys to second box
		driver.findElement(By.xpath("//div[@id='HTML28']/child::div/input[@class='classone']")).sendKeys("waoooo");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@value='Car']")).click();
		Actions act = new Actions(driver);

		//Double click on book
		WebElement ele1 = driver.findElement(By.xpath("//input[@value='Book']")); 
		act.doubleClick(ele1).perform();
		Thread.sleep(3000);
		//click on bag
		driver.findElement(By.xpath("//input[@value='Bag']")).click();
		Thread.sleep(3000);
		//click on book
		driver.findElement(By.xpath("//input[@value='Book']")).click();
		Thread.sleep(3000);
		//double click on dropdown
		WebElement ele3 = driver.findElement(By.xpath("//button[@class='dropbtn']")); 
		ele3.click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Facebook']"))).isDisplayed();
		WebElement unm=driver.findElement(By.xpath("//a[text()='Facebook']"));
		unm.click();
		
		
		
		
	}

}
