import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.WebElement;
public class app {


	public static void main(String[] args) throws MalformedURLException {
		
		
		DesiredCapabilities cap=new DesiredCapabilities(); 
		//cap.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
		
		cap.setCapability("deviceName", "Infinix X695");
		cap.setCapability("udid", "067682516J100808");
		cap.setCapability("platformName", "Android ");
		cap.setCapability("platformVersion", "11");
		cap.setCapability("appPackage", "com.transsion.calculator9.0.5.28");
		cap.setCapability("appActivity", "com.transsion.calculator.Calculator");
		URL url=new URL("http://127.0.0.1:4723/wd/hub");
		AndroidDriver<WebElement> driver=new AndroidDriver<WebElement>(url,cap);
		
		System.out.println("started");
		
	}

}
