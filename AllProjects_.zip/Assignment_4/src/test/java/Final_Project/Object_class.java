package Final_Project;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class Object_class {
	
WebDriver driver;
	
	
	Logger log=Logger.getLogger("Object_class");
	
	
	@FindBy(xpath="(//li[@id='menu-item-4761']//child::a[@class='dropdown-toggle'])[2]")
	WebElement click_laptop;
	
	@FindBy(xpath="//h2[@class='woocommerce-loop-product__title']")
	WebElement Names;
	
	@FindBy(xpath="(//i[@class='ec ec-menu'])[2]")
	WebElement products;
	
	@FindBy(xpath="//select[@name='ppp']")
	WebElement select1;
	
	@FindBy(xpath="//span[@class='woocommerce-Price-currencySymbol']")
	WebElement price;
	
	@FindBy(xpath="//div[@class='product-thumbnail product-item__thumbnail']")
	WebElement picture;
	
	     Object_class(WebDriver d){
		this.driver=d;
		PageFactory.initElements(d,this);
	}
	   
	   
	  public void clicklaptop() throws InterruptedException, IOException, AWTException {
		   WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(15));
		   wait.until(ExpectedConditions.visibilityOf(click_laptop));
		   Actions act=new Actions(driver);
		   act.moveToElement(click_laptop).click().perform();
		   log.info("move to laptop to click");
		   wait.until(ExpectedConditions.visibilityOf(select1));
		   Select sel=new Select(select1);
		   sel.selectByVisibleText("Show All");
		   log.info("select show all to get every item at one place");
		   Thread.sleep(10000);
		  
		  
		  
		  
		   ArrayList<String> Tnames=new ArrayList<String>(); 
		   List<WebElement> Tabletnames=driver.findElements(By.xpath("//div[@class='product-loop-body product-item__body']//child::h2[@class='woocommerce-loop-product__title']"));
		   for(WebElement e:Tabletnames) {
			   String names=e.getText();
			  // log.info("get text of every webelement(name of laptop)"); 
			   Tnames.add(names);
			  // log.info("Add names in arraylist(Tnames)"); 
			  
		   }
		   
		   ArrayList<String> Price=new ArrayList<String>(); 
		   List<WebElement> Prices=driver.findElements(By.xpath("//span[@class='price']"));
		   for(WebElement e:Prices) {
			   String price1=e.getText();
			  // log.info("get text of every webelement(price of laptop)"); 
			   Price.add(price1);
			  // log.info("Add names in arraylist(price)"); 
		   }
	   
		   
		   ArrayList<String> description=new ArrayList<String>(); 
		   List<WebElement> descriptions=driver.findElements(By.xpath("//div[@class='product-short-description']"));
		   for(WebElement e:descriptions) {
			   String d1=e.getText();
			  // log.info("get text of every webelement(description of laptop)"); 
			   description.add(d1);
			 //  log.info("Add names in arraylist(description)"); 
			  
		   }
	   
		   
		   XSSFWorkbook workbook1=new XSSFWorkbook();
			XSSFSheet sheet1=workbook1.createSheet("asadraza");
			 log.info("create sheet with name asadraza"); 
			sheet1.createRow(0);
			 log.info("create row zero"); 
			sheet1.getRow(0).createCell(0).setCellValue("Names");
			 log.info("get rown and set first colom value as Names"); 
			sheet1.getRow(0).createCell(1).setCellValue("Price");
			log.info("get rown and set second colom value as Names");
			sheet1.getRow(0).createCell(2).setCellValue("Description");
			log.info("get rown and set second colom value as Names");
			for(int i=1;i<Tnames.size();i=i++) {
				//DataFormatter df=new DataFormatter();
				sheet1.createRow(i);
				//log.info("create row (i)");
				sheet1.getRow(i).createCell(0).setCellValue(Tnames.get(i));
				//log.info("set first colom with Names of laptops ");
			}
			
			for(int i=1;i<Price.size();i++) {
				//DataFormatter df=new DataFormatter();
				
				
				sheet1.getRow(i).createCell(1).setCellValue(Price.get(i));
				
			}
			
			for(int i=1;i<description.size();i++) {
				//DataFormatter df=new DataFormatter();
				
				
				sheet1.getRow(i).createCell(2).setCellValue(description.get(i));
				
			}
			
			File fil=new File("C:\\Users\\Hassan\\eclipse-workspace\\Assignment_4\\newfiles\\home.xlsx");
			FileOutputStream fos=new FileOutputStream(fil);
			workbook1.write(fos);
	
//	  	
		  for (int i=1; i<5; i++) {
			  Actions a = new Actions(driver);
			    a.moveToElement(picture).contextClick().build().perform();
			    
			    Robot robot = new Robot();
			    
			  
			    for(int n=0; n<8;n++)
					{
					robot.keyPress(KeyEvent.VK_DOWN);
					robot.keyRelease(KeyEvent.VK_DOWN);
					
					
					}
					
					
					robot.keyPress(KeyEvent.VK_ENTER);
					robot.keyRelease(KeyEvent.VK_ENTER);
					log.info("go down at every image ");
					Thread.sleep(2000);
					robot.keyPress(KeyEvent.VK_ENTER);
					robot.keyRelease(KeyEvent.VK_ENTER);
					driver.navigate().back();
					Thread.sleep(3000);
					
			  
		  }

}
}
