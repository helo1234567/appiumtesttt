package Amazon_Automate;

import java.awt.AWTException;
import java.io.IOException;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import HomeTask.Object_Class;

public class Main_Class {
	WebDriver driver=new ChromeDriver();
	helo11 object=new helo11(driver);
	
	
	
	@Test
	public void Before_method() {
		
		driver.get("https://www.amazon.com/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fs%3Fk%3Damazon%2Blogin%26adgrpid%3D79685717977%26gclid%3DCjwKCAiA5sieBhBnEiwAR9oh2lUVSW75oFTw-gaJCLpmigTp0p6W2u_99FazFcwK2vpigtiiYIPJHhoC-vkQAvD_BwE%26hvadid%3D585359104713%26hvdev%3Dc%26hvlocphy%3D1011082%26hvnetw%3Dg%26hvqmt%3De%26hvrand%3D3136590290410418121%26hvtargid%3Dkwd-360364907677%26hydadcr%3D2745_13541852%26tag%3Dhydglogoo-20%26ref%3Dnav_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=usflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&");
		driver.manage().window().maximize();
		//PropertyConfigurator.configure("log4j.properties");
		}
	@Test
	public void All_Tasks() throws InterruptedException, IOException, AWTException {
		
		object.signin();

	}
}