package Amazon_Automate;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class helo11 {
	WebDriver driver;
	@FindBy(xpath="//input[@type='email']")
	WebElement signinn;

	@FindBy(xpath="//input[@id='continue']")
	WebElement clickcontinue;

	@FindBy(xpath="//input[@type='password']")
	WebElement enterpasword;

	@FindBy(xpath="//input[@type='password']")
	WebElement clickpassword;

	@FindBy(xpath="//span[@class='hm-icon-label']")
	WebElement clickonmenu;


			public helo11(WebDriver d){
			this.driver=d;
			PageFactory.initElements(d,this);
		}
		   
	   
		  public void signin(){
			   WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(1000));
			   wait.until(ExpectedConditions.visibilityOf(clickcontinue));
			   signinn.sendKeys("asadrazamahmood@gmail.com");
			   wait.until(ExpectedConditions.visibilityOf(clickcontinue));
			   clickcontinue.click();
			   wait.until(ExpectedConditions.visibilityOf(enterpasword));
			   enterpasword.sendKeys("Asad777&");
			   clickpassword.click();
			   wait.until(ExpectedConditions.visibilityOf(clickonmenu));
			   clickonmenu.click();


		  
		  }

}
