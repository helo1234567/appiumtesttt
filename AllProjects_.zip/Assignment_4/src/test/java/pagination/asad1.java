package pagination;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.DrbgParameters.NextBytes;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;



public class asad1 {
	
WebDriver driver;
	
	

	
	@FindBy(xpath="//table[@id='example']")
	WebElement table;
	
	@FindBy(xpath="//a[@class='paginate_button ']")
	WebElement next;
	
	@FindBy(id="example_next")
	WebElement pressnext;
	
asad1(WebDriver d){
		driver=d;
		PageFactory.initElements(d,this);
}


public void enterdescription() throws InterruptedException, IOException {
   
	
	XSSFWorkbook workbook1=new XSSFWorkbook();
	XSSFSheet sheet1=workbook1.createSheet("asads sheet");
	 //log.info("create sheet with name asadraza"); 
	//sheet1.createRow(0);
//	 //log.info("create row zero"); 
//	sheet1.getRow(0).createCell(0).setCellValue("Names");
//	 //log.info("get rown and set first colom value as Names"); 
//	sheet1.getRow(0).createCell(1).setCellValue("Price");
//	//log.info("get rown and set second colom value as Names");
//	sheet1.getRow(0).createCell(2).setCellValue("Description");
//	//log.info("get rown and set second colom value as Names");
	
	
	int size=driver.findElements(By.xpath("//a[@class='paginate_button ']")).size();
	//List<WebElement> rows=table.findElements(By.tagName("tr"));
//		List<WebElement> headings=table.findElements(By.tagName("th"));
//		for(int i=0;i<headings.size();i++) {
//			
//			System.out.print(headings.get(i).getText()+"  ");
//			
//		}
	//ArrayList<ArrayList<String>> Price = new ArrayList<ArrayList<String>>();
	int noofrows=100;
	int noofcoloms=5;
	
	//String array[][]=new String[noofrows-1][noofcoloms];
	
	ArrayList<String> Price=new ArrayList<String>(); 
	for(int m=0;m<size;m++) {
		
		
		List<WebElement> rows=table.findElements(By.tagName("tr"));
		
		for(int i=0;i<rows.size();i++) {
			
			List<WebElement>  coloms= rows.get(i).findElements(By.tagName("td"));
			sheet1.createRow(i);
			for(int j=0;j<coloms.size();j++) {
			
				DataFormatter df=new DataFormatter();
				//array[i][j]=df.formatCellValue(sheet1.getRow(i).getCell(j));
				sheet1.getRow(i).createCell(j).setCellValue(coloms.get(j).getText());
			
				System.out.print(coloms.get(j).getText()+"  ");
				
			
				//System.out.println(Price);
				
			}
			System.out.println("  ");
		}	
		pressnext.click();
		Thread.sleep(3000);
		//System.out.println(Price);
}
	//System.out.println(Price);
	
//	for(int i=0;i<Price.size();i++) {
//		DataFormatter df=new DataFormatter();
//		
//		sheet1.createRow(i);
//	
//		
//		sheet1.getRow(i).createCell(0).setCellValue(Price.get(i));
//			
//		
//	
//		
//	}
		
		File fil=new File("C:\\\\Users\\\\Hassan\\\\eclipse-workspace\\\\Assignment_4\\\\HomeExcelfiles\\\\home1.xlsx");
		FileOutputStream fos=new FileOutputStream(fil);
		workbook1.write(fos);	
}


}
