package Trello;

import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class Main_Class {
	
	WebDriver driver=new ChromeDriver();
	Object_Class object=new Object_Class(driver);
	
	@BeforeMethod
	public void Before_method() {
		
		driver.get("https://trello.com");
		driver.manage().window().maximize();
		
		}
	@Test
	public void All_Tasks() throws InterruptedException {
		String alphbates="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		 StringBuilder sb = new StringBuilder();
		    Random random = new Random();
		    int length=7;
		    for (int i = 0; i < length; i++) {
		    	int index=random.nextInt(alphbates.length());
		    	char randomChar=alphbates.charAt(index);
		    	sb.append(randomChar);
	 }
		String randomstring=sb.toString();
		
		object.login();
		object.CreateBoard(randomstring);
		object.Createfirstlist(randomstring);
		object.Createsecondlist(randomstring);
		object.Addcard(randomstring);
		object.Movecard(randomstring);
		object.editcardname();
		object.deletecard();
	}

}
