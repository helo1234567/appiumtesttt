package Lab_7;

import java.awt.AWTException;
import java.time.Duration;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Task_1 {

		//Logger log=Logger.getLogger("AllMethods");
		WebDriver driver;

		
		@FindBy(xpath="//button[contains(text(),'Bank Manager Login')]")
		WebElement BMlogin;
		
		@FindBy(xpath="//button[contains(text(),'Add Customer')]")
		WebElement addcustomer;
		
		@FindBy(xpath="//input[@type='text' and @placeholder='First Name' ] ")
		WebElement firstname;
		
		
		@FindBy(xpath="//input[@type='text' and @placeholder='Last Name' ] ")
		WebElement lastname;
		
		@FindBy(xpath="//input[@type='text' and @placeholder='Post Code' ] ")
		WebElement postcode;
		
		@FindBy(xpath="//button[@type='submit' and @class='btn btn-default' ] ")
		WebElement addcustomer1;
		
		@FindBy(xpath="//button[contains(text(),'Open Account')]")
		WebElement openaccount;
		
		@FindBy(xpath="//select[@id='userSelect']")
		WebElement acountnamedropdown;
		
		@FindBy(xpath="//select[@id='currency']")
		WebElement currencydropdown;
		
		@FindBy(xpath="//button[@type='submit']")
		WebElement press;
		
		@FindBy(xpath="//button[contains(text(),'Customer Login')]")
		WebElement customerlogin;
		
		@FindBy(xpath="//select[@id='userSelect']")
		WebElement yournamedropdown;
		
		@FindBy(xpath="//button[@class='btn btn-default' and @type='submit' ]")
		WebElement login;
		
		@FindBy(xpath="//button[contains(text(),'Deposit')]")
		WebElement deposit;
		
		@FindBy(xpath="//input[@type='number' and @placeholder='amount']")
		WebElement amountdeposited;
		
		@FindBy(xpath="//button[@type='submit' and @class='btn btn-default']")
		WebElement deposit2;
		
		@FindBy(xpath="//button[@class='btn btn-lg tab' and @ng-click='withdrawl()']")
		WebElement withdraw;
		
		@FindBy(xpath="//input[@type='number' and @placeholder='amount']")
		WebElement amountwithdraw;
		
		@FindBy(xpath="//button[@type='submit' and @class='btn btn-default']")
		WebElement withdraw1;
		
		
		@FindBy(xpath="//button[@ng-class='btnClass1' and @class='btn btn-lg tab']")
		WebElement transaction;
		
		@FindBy(xpath="//table[@class='table table-bordered table-striped']")
		WebElement table3;
		
		
		@FindBy(xpath="//button[@class='btn' and @ng-show='showDate']")
		WebElement reset;
		
		@FindBy(xpath="//button[@class='btn logout' and @ng-show='logout']")
		WebElement logout;
		
		@FindBy(xpath="//button[@ng-class='btnClass3' and @class='btn btn-lg tab']")
		WebElement customers;
		
		@FindBy(xpath="//div[@class='marTop ng-scope']")
		WebElement table4;
		
		
		@FindBy(xpath="//button[@ng-click='deleteCust(cust)']")
		WebElement delete;
		
		@FindBy(xpath="//input[@type='text']")
		WebElement typetext;
		
		@FindBy(xpath="//input[@id='start']")
		WebElement dateset;
		
		
		Task_1(WebDriver d){
			this.driver=d;
			PageFactory.initElements(d,this);
		}

		public void login() throws InterruptedException, AWTException { 
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
			wait.until(ExpectedConditions.visibilityOf(BMlogin));
			
			BMlogin.click();
			wait.until(ExpectedConditions.visibilityOf(addcustomer));
			addcustomer.click();
			wait.until(ExpectedConditions.visibilityOf(firstname));
			firstname.sendKeys("hassan");
			Thread.sleep(1000);
			lastname.sendKeys("raza");
			Thread.sleep(1000);
			postcode.sendKeys("12345");
			Thread.sleep(1000);
			addcustomer1.click();
			Thread.sleep(2000);
			Alert alert1=driver.switchTo().alert();
			alert1.accept();
			Thread.sleep(2000);
			openaccount.click();
			Thread.sleep(3000);
			Select select= new Select(acountnamedropdown);
			Thread.sleep(3000);
			select.selectByVisibleText("hassan raza");
			Thread.sleep(2000);
			Select select1= new Select(currencydropdown);
			select1.selectByVisibleText("Dollar");
			press.click();
			Thread.sleep(2000);
			Alert alert2=driver.switchTo().alert();
			alert2.accept();
			driver.navigate().back();
			driver.navigate().back();
			driver.navigate().back();
			wait.until(ExpectedConditions.visibilityOf(customerlogin));
			customerlogin.click();
			wait.until(ExpectedConditions.visibilityOf(yournamedropdown));
			Select select2= new Select(yournamedropdown);
			select2.selectByVisibleText("hassan raza");
			wait.until(ExpectedConditions.visibilityOf(login));
			login.click();
			wait.until(ExpectedConditions.visibilityOf(deposit));
			deposit.click();
			wait.until(ExpectedConditions.visibilityOf(amountdeposited));
			amountdeposited.sendKeys("5000");
			deposit2.click();
			Thread.sleep(2000);
			withdraw.click();
			Thread.sleep(3000);
			wait.until(ExpectedConditions.visibilityOf(amountwithdraw));
			amountwithdraw.sendKeys("5000");
			Thread.sleep(3000);
			withdraw1.click();
			transaction.click();
			Thread.sleep(3000);
			
			dateset.click();
			
			
			
			
			
			List<WebElement> rows=table3.findElements(By.tagName("tr"));
	   		List<WebElement> headings=table3.findElements(By.tagName("th"));
	   		for(int i=0;i<headings.size();i++) {
	   			System.out.print(headings.get(i).getText()+"  ");
	   			
	   		}
	   		for(int i=0;i<rows.size();i++) {
	   			List<WebElement>  coloms= rows.get(i).findElements(By.tagName("td"));
	   			
	   			for(int j=0;j<coloms.size();j++) {
	   				System.out.print(coloms.get(j).getText()+"  ");
	   			}
	   			System.out.println("  ");
	   		}
	   		
	   		reset.click();
	   		logout.click();
	   		Thread.sleep(2000);
	   		driver.navigate().back();
			driver.navigate().back();
			driver.navigate().back();
			driver.navigate().back();
			
			wait.until(ExpectedConditions.visibilityOf(BMlogin));
			BMlogin.click();
			customers.click();
			wait.until(ExpectedConditions.visibilityOf(typetext));
			typetext.sendKeys("hassan");
			Thread.sleep(2000);
			typetext.sendKeys(Keys.ENTER);
			Thread.sleep(3000);
			delete.click();
			Thread.sleep(2000);
			typetext.clear();
			
			driver.close();
			
			}
}
