package io.appium.java_client.android;

public @interface AndroidElement {

}
