package practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.testng.annotations.Test;

public class sdaefsfdgfdg {
@Test
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); 
	String connectionUrl ="jdbc:sqlserver://DESKTOP-DJNQI78\\MSSQLSERVER01;" + "databaseName=Booksinformation;integratedSecurity=true;" +"encrypt=true;trustServerCertificate=true";
	//url = "jdbc:sqlserver://" +serverName + ":1433;DatabaseName=" + dbName + ";encrypt=true;trustServerCertificate=true;";
	//String connectionUrl = "jdbc:sqlserver://DESKTOP-DJNQI78\\MSSQLSERVER01;databaseName=Booksinformation;integratedSecurity=false;"; 
	Connection con = DriverManager.getConnection(connectionUrl);  
	JOptionPane.showMessageDialog(null, "connection ok");
	Statement stmt = con.createStatement();
    //String query="SELECT * FROM customers";
	String create="CREATE TABLE Persons (username varchar(25),password varchar(25)";
    String s="INSERT INTO persons (username,password)VALUES ('asadrazamahmood@gmail.com', 'Asad777&')";
    ResultSet rs = stmt.executeQuery(create);
   // stmt.executeQuery(s);
	}

}
