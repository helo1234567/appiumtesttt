package runnerpackage;

import org.junit.runner.RunWith;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
//@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/resources/MobileFeatures",
		glue={"Step_Defs_and_WebElements"},
		monochrome=true,
		plugin = { "pretty",
				
				"json:target/cucumber-report.json",
				"junit:target/cucumber-report.xml" }
)

public class Mobilerunner extends AbstractTestNGCucumberTests {
	

}
