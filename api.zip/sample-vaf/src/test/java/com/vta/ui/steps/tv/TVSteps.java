package com.vta.ui.steps.tv;

import java.io.IOException;

import org.junit.Assert;
import org.testng.annotations.Test;

import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.tv.TVModule;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TVSteps {

	UIManager mgr = new UIManager(BrowserType.FF32);
	TVModule tvModule = new TVModule(mgr.driver);

	@Test(priority = 0)
	@When("I navigate {string}")
	public void I_navigate(String url) throws IOException {

		mgr.startSession(url);

	}

	@Test(priority = 1)
	@Then("Verify that url of the page must be {string}")
	public void verify_url(String title) throws IOException {
		String actual_url = mgr.getURL();
		UIManager.assertEqual(title, actual_url, "Verify title is matched ");

	}

	@Test(priority = 1)
	@Then("Close the Browser")
	public void Browser() throws IOException {
		mgr.endSession();

	}

	@Test(priority = 2)
	@Given("User is on Home page of Spectrum.com")
	public void Home_Page() throws IOException {

		System.out.print("spectrum.com");

	}

	@Test(priority = 3)
	@When("User Click on TV Tab")
	public void Hover_over() throws IOException {

		System.out.print("spectrum.com");
		mgr.waitUntilVisible(tvModule.Tv_tab);
		mgr.click(tvModule.Tv_tab);
		// mgr.waitUntilVisible(m.click_spectrum_Internet);
	}

	
	/*
	 * @Test(priority=4)
	 * 
	 * @Then("Verify that User must see {string} in dropdown") public void
	 * verify_From_dropdown(String dropdown_value) throws IOException { String
	 * Text=m.click_spectrum_Cable_TV.getText();
	 * UIManager.assertEqual(dropdown_value, Text,
	 * "Verify dropdown_value is displayed ");
	 * 
	 * }
	 */
	 
	 @Test(priority=4)
	 @Then("User can send data {string} in Street Address") 
	public void enter_street_address(String para) throws InterruptedException {
		 mgr.fillTextField(tvModule.Spectrum_TV_stAddress, "ABC");
		 Thread.sleep(7000);
//			  String Text=m.Spectrum_TV_stAddress.getText();
//			  //Thread.sleep(7000);
//			  UIManager.assertEqual(para, Text,
//			  "Verify Spectrum_TV_stAddress is Entered ");
			 Assert.assertNotNull(tvModule.Spectrum_TV_stAddress);
	 
	 }
	 
	 @Test(priority=5)
	 @Then("User can send data {string} in Apt Unit") 
	public void enter_Apt_Unit(String para) throws InterruptedException {
		 mgr.fillTextField(tvModule.Spectrum_TV_aptUnit, "XYZ");
		 Thread.sleep(1000);
//			  String Text=m.Spectrum_TV_stAddress.getText();
//			  //Thread.sleep(7000);
//			  UIManager.assertEqual(para, Text,
//			  "Verify Spectrum_TV_stAddress is Entered ");
			 Assert.assertNotNull(tvModule.Spectrum_TV_aptUnit);
	 
	 }
	 
	 @Test(priority=5)
	 @Then("User can send data {string} in Zip Code") 
	public void enter_zip_code(String para) throws InterruptedException {
		 mgr.fillTextField(tvModule.Spectrum_TV_zipCode, "547925");
		 Thread.sleep(2000);
//			  String Text=m.Spectrum_TV_stAddress.getText();
//			  //Thread.sleep(7000);
//			  UIManager.assertEqual(para, Text,
//			  "Verify Spectrum_TV_stAddress is Entered ");
			 Assert.assertNotNull(tvModule.Spectrum_TV_zipCode);
	 
	 }
	 
	 @Test(priority=5)
	 @Then("User can Click on Go Button") 
	public void Click_go_Button() throws InterruptedException {
		 mgr.click(tvModule.Click_Go_Button);
		 Thread.sleep(7000);
		 Assert.assertNotNull(tvModule.Click_Go_Button);
	 
	 }
	 
	 
	@Test(priority = 3)
	@When("User Hover over on TV Tab and click on Spectrum Cable TV in dropdown")
	public void click_fromdropdown() throws IOException {

		mgr.hoverAndClick(tvModule.Tv_tab, tvModule.click_spectrum_Cable_TV);

	}
}
