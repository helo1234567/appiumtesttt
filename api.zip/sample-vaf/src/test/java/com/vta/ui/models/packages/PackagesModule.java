package com.vta.ui.models.packages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PackagesModule {
WebDriver driver;
	
	public PackagesModule(WebDriver d) {
		driver=d;
		PageFactory.initElements(d, this);
	}
	
	@FindBy(xpath="(//a[@href='/packages'])[1]")
	public
	WebElement packages_tab;

	@FindBy(xpath="(//a[@href='/packages' and @title='Shop Packages'])[1]")
	public
	WebElement packages_dropdown;
	
	@FindBy(xpath="(//a[@href='/packages' and @title='Shop Packages'])[1]")
	public
	WebElement dropdown_shop_packages;

	@FindBy(xpath="//img[@class='spectrum-one' and @alt='Spectrum One']")
	public
	WebElement verify_shoppackages_page;

	@FindBy(xpath="//input[@class='sp-radio' and @type='radio' and @value='300 Mbps for $49.99/mo']")
	public WebElement choose_internet_speed_300Mbps;
	
	@FindBy(id="button-get-offer")
	public
	WebElement Getoffer_button;
	
	@FindBy(id="address1-modal")
	public
	WebElement street_address;
	
	@FindBy(id="address1-standalone")
	public
	WebElement street_address2;
	
	@FindBy(id="apt-modal")
	public
	WebElement Apt_Unit;
	

	@FindBy(id="apt-standalone")
	public
	WebElement Apt_Unit2;
	
	@FindBy(id="zip-modal")
	public
	WebElement zipcode;
	
	@FindBy(id="zip-standalone")
	public
	WebElement zipcode2;
	
	@FindBy(xpath="(//button[@class='sp-localization-submit'])[4]")
	public
	WebElement Go_button;
	
	@FindBy(xpath="//button[@class='sp-localization-submit' and @data-linktype='cta_button' and @data-linkname='packages-test-localization_GO']")
	public WebElement Go2_button;
	
	@FindBy(id="radioGrp-packages-1")
	public
	WebElement choose_internet_speed_500Mbps;
	
	@FindBy(id="radioGrp-packages-2")
	public
	WebElement choose_internet_speed_1Gbps;
	
	@FindBy(id="SpectrumLogo")
	public
	WebElement out_of_footprint;
	
	@FindBy(xpath="(//img[@class='nav-logo-img w-auto' and @alt='GCI'])[1]")
	public
	WebElement GCI_logo;
	
	@FindBy(xpath="//div[@class='sp-bundleBuilder__item tv-container' and @data-linkname='card-bundletv' and @aria-label='TV from $59.99 per month for 12 months']")
	public WebElement TV_Service;
	
	@FindBy(xpath="//div[@class='sp-bundleBuilder__item internet-container' and @data-linkname='card-bundleinternet' and @aria-label='Internet from $49.99 per month for 12 months']")
	public
	WebElement internet_Service;
	
	@FindBy(xpath="//div[@class='sp-bundleBuilder__item homephone-container' and @data-linkname='card-bundlehomephone' and @aria-label='Home phone from $19.99 per month']")
	public WebElement home_phone_Service;
	
	@FindBy(xpath="(//div[@class='whole p-col'])[1]")
	public
	WebElement TV_monthly_charges;
	
	@FindBy(xpath="(//a[@class='cmp-navigation__item-link' and @data-linkname='Spectrum One' and @href='/packages/spectrum-one'])[1]")
	public WebElement Spectrum_One;
	
	@FindBy(xpath="//img[@class='image-superHero' and @alt='Spectrum One -  Get Internet, FREE Advanced WiFi and 1 FREE Unlimited Mobile line ']")
	public WebElement verify_Spectrum_One_page;
	
	@FindBy(xpath="//*[@id=\"button-5b019c64a1\"]/span")
	public WebElement Get_offer2_button;
	
	@FindBy(id="SpectrumLogo")
	public WebElement verify_address_page;
	
	@FindBy(xpath="//input[@class='form-control' and @name='line1']")
	public WebElement street_address3;
	
	@FindBy(xpath="//input[@class='form-control' and @name='line2']")
	public WebElement Apt_Unit3;
	
	@FindBy(xpath="//*[@id=\"zipcode--data\"]")
	public WebElement zipcode3;
	
	@FindBy(xpath="//*[@id=\"landmark-main\"]/div/div/form/button")
	public WebElement Find_Offers_button;

}
