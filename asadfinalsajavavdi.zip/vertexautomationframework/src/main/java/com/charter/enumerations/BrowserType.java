package com.charter.enumerations;

public enum BrowserType{ 
	CHROME32, CHROME32_NOHEAD, FF32, FF32_NOHEAD, FF64, FF64_NOHEAD, EDGE, IE32, IE64 
}

