package com.charter.steps;

import static org.junit.Assert.assertEquals;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import com.charter.utils.ExcelUtil;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import com.charter.enumerations.BrowserType;
import com.charter.utils.ExcelXSSFUtility;
import com.charter.web.*;
import com.charter.web.UIManager.LocatorType;

public class UISteps {

	UIManager mgr = new UIManager(BrowserType.FF32);


	@Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) {

		mgr.startSession(url);
	}

	@Test
	@When("Maximize the window")
	public void Maximize_window() {

		mgr.maximizeBrowser();
	}

	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_Title(String Page_Title) {

		String actual_Title = mgr.getTitle();
		UIManager.assertEqual(actual_Title, Page_Title, "Verify Title is matched or not");
	}

	@Test
	@Then("Close the Browser")
	public void Close_Browser() {

		mgr.endSession();
	}

	@Test
	@And("User Hover over on {string}")
	public void Hover_Over(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.hover(value, type);
	}

	@Test
	@Then("Verify that User will see {string} after Hover over")
	public void verify_dropdown_value(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isDisplayed(value, type);
	}

	@And("User Hover over on {string} and Click on {string}")
	public void Hover_and_click(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.hoverAndClick(value, value1, type);
	}

	@Test
	@Then("Verify that the URL of page should be {string}")
	public void Verify_URL(String Current_URL) {

		String actual_URL = mgr.getURL();
		UIManager.assertEqual(actual_URL, Current_URL, "Verify that URL is matched or not");
	}

	@Test
	@And("User Click on {string}")
	public void Click(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.click(value, type);
	}

	@Test
	@And("Scroll to {string}")
	public void Scroll_to_dropdown(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.scroll(value,type,false);

	}

	@Test
	@And("Select {string} from {string}")
	public void select_dropdown(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.selectDropdownOption(value1, value, type);

	}


	@Test
	@Then("User Scroll to {string} and Click on {string}")
	public void Scroll_and_click(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.scroll_and_Click(value, value1, type);

	}

	@Test
	@And("wait for {string}")
	public void Wait_For_Specific_condition(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.waitUntilVisible(value, type);

	}

	@Test
	@Then("Verify that the {string} button should be enabled")
	public void Verify_Button_Enability(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isEnabled(value, type);

	}

	@Test
	@Then("Verify that {string} is selected successfully from {string}")
	public void verify_dropdown_selection(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.assertTrue_isDisplayed(value, type);

	}

	@Test
	@Then("Verify that user will see {string} on next page")
	public void Verify_Nextpage_ocator(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isDisplayed(value, type);

	}

	@Test
	@Then("Verify that user will see {string}")
	public void verify_nextpage_locator(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isDisplayed(value, type);

	}

	@Test
	@Then("Verify that {string} should be selected already")
	public void verify_isSelected(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isSelected(value, type);

	}

//	@Test
//	@Then("Verify that user will see {string} in next page")
//	public void verify_nextpage_locator_comapre_text(String key) throws InterruptedException {
//		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
//		String name = (String) locatorMap.get("name");
//		String value = (String) locatorMap.get("value");
//		LocatorType type = (LocatorType) locatorMap.get("type");
//		mgr.assertEqual_compareText(value, name, type);
//
//	}

	@Test
	@And("Enter username in {string} Field")
	public void Enter_Text(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String text = (String) locatorMap.get("Text");
		mgr.fillTextField(value,text,type);

	}

	@Test
	@And("User Navigate Back")
	public void Navigate_Back() throws InterruptedException {

		mgr.navigateBack();

	}
	@Test
	@And("User Navigate Forward")
	public void User_Navigate_Forward() throws InterruptedException {

		mgr.navigateForward();

	}

	@Test
	@And("Take screenshot")
	public void User_Take_screenshot () throws InterruptedException {

		mgr.logScreenshot();

	}
	@Test
	@And("User Log {string}")
	public void User_Log_Information(String key) throws InterruptedException {

		mgr.logInfo(key);

	}

	@Test
	@And("Minimize the window")
	public void Minimize_window() throws InterruptedException {

		mgr.minimizeBrowser();

	}

	@Test
	@Then("User gets all data from {string} and {string}")
	public void User_gets_all_data_from_excel(String usernameKey, String passwordKey) throws InterruptedException {
		List<String> usernames = ExcelUtil.valuesFor(usernameKey);
		List<String> passwords = ExcelUtil.valuesFor(passwordKey);
		for (int i = 0; i < usernames.size(); i++) {
			String username = usernames.get(i);
			String password = passwords.get(i);
			System.out.println(username);
		}
	}

}






