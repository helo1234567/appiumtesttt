package com.charter.web;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.charter.enumerations.BrowserType;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.charter.utils.LogUtil;

public class UIManager {
	public enum LocatorType { 
		xpath,
		cssSelector, 
		cssId, 
		cssClass,
	}

	private Duration timeOut = Duration.ofMillis(40000);
	public WebDriver driver;
	private NgWebDriver ngWebDriver = null;
	
	public WebDriver getChromeDriver() { return new ChromeDriver(); }
	public WebDriver getFirefoxDriver() { return  new FirefoxDriver(); }
	
	
	public UIManager(BrowserType browserType) {
		switch (browserType) {
		case CHROME32:
			driver = getChromeDriver();
			break;
		case FF32:
			driver = getFirefoxDriver();
			break;
		}
		
		this.ngWebDriver = new NgWebDriver((JavascriptExecutor) driver);
	}
	
	// Session Methods
	public void startSession(String url) { driver.get(url); }
	public void endSession() { driver.quit(); }
	public void waitImplicit(Integer duration) { driver.manage().timeouts().implicitlyWait(Duration.ofMillis(duration)); }
	public void waitForAngular() { ngWebDriver.waitForAngularRequestsToFinish(); }
	public WebDriverWait explicitWait() { return new WebDriverWait(driver, timeOut); }
	public void waitUntilVisible(String locator) { this.waitUntilVisible(locator, LocatorType.xpath); }
	public void waitUntilVisible(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
	}
	public void waitUntilVisible(WebElement element) {
		explicitWait().until(ExpectedConditions.visibilityOf(element));
	}
	
	// WebElement
	public WebElement elementBy(LocatorType type, String locator) {
		switch(type) {
		case cssSelector:
			return driver.findElement(By.cssSelector(locator));
		case cssId:
			return driver.findElement(By.id(locator));
		case cssClass:
			return driver.findElement(By.className(locator));
		default:
			return driver.findElement(By.xpath(locator));
		}
	}
	
	
	// Action: Hover and Click
	
	public void hoverAndClick(String hoverLocator, String clickLocator) { this.hoverAndClick(hoverLocator, clickLocator, LocatorType.xpath); }
	public void hoverAndClick(String hoverLocator, String clickLocator, LocatorType locatorType) {
		
		WebElement hoverElement = this.elementBy(locatorType, hoverLocator);
		
//		this.hoverAndClick(hoverElement, clickElement);
		
		// Instantiate Action Class
		Actions actions = new Actions(driver);
				
		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();
		
		this.waitUntilVisible(clickLocator);
		
		WebElement clickElement = this.elementBy(locatorType, clickLocator);
		
		// Mouse hover menuOption 'Rock'
		actions.moveToElement(clickElement).perform();
				
		// Click on the element
		clickElement.click();
	}

	public void hover(String hoverLocator) { this.hover(hoverLocator,LocatorType.xpath); }
	public void hover(String hoverLocator, LocatorType locatorType) {

		WebElement hoverElement = this.elementBy(locatorType, hoverLocator);

//		this.hoverAndClick(hoverElement, clickElement);

		// Instantiate Action Class
		Actions actions = new Actions(driver);
		this.waitUntilVisible(hoverLocator);
		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();


	}
	
	public void hoverAndClick(WebElement hoverElement,WebElement clickElement) {
		// Instantiate Action Class
		Actions actions = new Actions(driver);
		
		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();
		
		this.waitUntilVisible(clickElement);
		
		// Mouse hover menuOption 'Rock'
		actions.moveToElement(clickElement).perform();
		
		// Click on the element
		clickElement.click();
	}
	public void hover(WebElement hoverElement) {
		// Instantiate Action Class
		Actions actions = new Actions(driver);
				
		// Mouse hover menuOption 'Music'
		actions.moveToElement(hoverElement).perform();
		
	}
	
	
	// Actions: Clickable
	public void click(String locator) { this.click(locator, LocatorType.xpath); }
	public void click(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.waitUntilVisible(we);
		this.click(we);
	}


	public void click(WebElement element) {
		explicitWait().until(ExpectedConditions.elementToBeClickable(element));
		element.click();
	}
	
	// Textfield
	
	public void fillTextField(String locator, String text) throws InterruptedException { this.fillTextField(locator, text, LocatorType.xpath);}
	public void fillTextField(String locator, String text, LocatorType locatorType) throws InterruptedException {
		WebElement we = this.elementBy(locatorType, locator);
		this.fillTextField(we, text);
	}
	public void fillTextField(String locator, Keys key, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);

		this.fillTextField(we, key);
	}
	public void fillTextField(WebElement element, String text) throws InterruptedException {

		this.waitUntilVisible(element);
		element.sendKeys(text);
	}
	public void fillTextField(WebElement element, Keys key) {
		element.sendKeys(key);
	}
	
	// Dropdown
	
	public void selectDropdownOption(String dropdownLocator, String clickLocator) { this.selectDropdownOption(dropdownLocator, clickLocator,LocatorType.xpath); }
	public void selectDropdownOption(String dropdownLocator, String clickLocator,LocatorType locatorType) {
		WebElement selectDropdown = this.elementBy(locatorType, dropdownLocator);
		WebElement selectElement = this.elementBy(locatorType, clickLocator);
		String  interactValue=selectElement.getText();
		this.selectDropdownOption(selectDropdown, selectElement, interactValue);
		
	}
	
	
	
	public void selectDropdownOption(WebElement dropdownElement, WebElement clickElement,String dropdownvalue) {
		explicitWait().until(ExpectedConditions.visibilityOf(dropdownElement));
		
		Select select = new Select(dropdownElement);
		
		explicitWait().until(ExpectedConditions.visibilityOf(clickElement));
		
		select.selectByVisibleText(dropdownvalue);
	}
	
	// Browser Navigation
	
	public void scroll(WebElement element) {
		this.scroll(element, true);
	}
	public void scroll(WebElement element, boolean scrollIntoView) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", element);
	}
	public void scroll(String element) {
		this.scroll(element, true);
	}
	public void scroll(String element,LocatorType locatorType, boolean scrollIntoView) {
		WebElement scrollLocator = this.elementBy(locatorType, element);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", scrollLocator);
	}

	public void scroll(String element, boolean scrollIntoView) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", element);
	}

	public void scroll_and_Click(String element,String element2,LocatorType locatorType) {
		this.scroll_and_Click(element,element2,locatorType,false);
	}
	public void scroll_and_Click(String element,String element2,LocatorType locatorType,boolean scrollIntoView) {
		WebElement we = this.elementBy(locatorType, element);
		WebElement we1 = this.elementBy(locatorType, element2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")", we);
		we.click();
	}


	public void navigateTo(String address) {
		driver.navigate().to(address);
	}
	
	public void navigateBack() {
		driver.navigate().back();		
	}
	public void navigateForward() {
		driver.navigate().forward();
	}
	// Custom Logs
	public void logScreenshot() {
		String screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
		LogUtil.logBase64(screenshot, "Attached Screenshot");
	}
	
	
	public void logInfo(String value) {
		LogUtil.logInfo(value);	
	}
	
	// Action Methods with WebElement
	
	public String getTitle() { 
		return driver.getTitle();
	}
	
	public String getURL() {
		return driver.getCurrentUrl();
	}
	public String getText(WebElement element) {
		return element.getText();
	}

	public String getText(String locator) { return this.getText(locator, LocatorType.xpath);

	}
	public String getText(String locator,LocatorType locatorType)
	{
		WebElement we = this.elementBy(locatorType, locator);
		return we.getText();
	}
	// ASSERTIONS
	
	public static void assertEqual(String orignal, String expected, String message) throws AssertionError {
		Assert.assertEquals(orignal, expected, message);
	}
	
	public static void assertEqual(boolean orignal, boolean expected, String message) throws AssertionError {
		Assert.assertEquals(orignal, expected, message);
	}
	
	public static void assertTrue(boolean condition, String message) throws AssertionError {
		Assert.assertTrue(condition, message);
	}

	public void assertTrue_isDisplayed(String locator, LocatorType locatorType) throws AssertionError {
		WebElement we = this.elementBy(locatorType, locator);
		Assert.assertTrue(we.isDisplayed());
	}

	public void assertTrue_isEnabled(String locator, LocatorType locatorType) throws AssertionError {
		WebElement we = this.elementBy(locatorType, locator);
		Assert.assertTrue(we.isEnabled());
	}

	public void assertTrue_isSelected(String locator, LocatorType locatorType) throws AssertionError {
		WebElement we = this.elementBy(locatorType, locator);
		Assert.assertTrue(we.isSelected());
	}

	public void assertEqual_compareText(String locator,String locatorname, LocatorType locatorType) throws AssertionError {
		WebElement we = this.elementBy(locatorType, locator);
		String text=we.getText();
		Assert.assertEquals(locatorname,text);
	}
	public static void assertFalse(boolean condition, String message) throws AssertionError {
		Assert.assertFalse(condition, message);
	}
	public void switchToFrame(String locator){
		switchToFrame(locator, LocatorType.xpath);
	}
	public void switchToFrame(String locator, LocatorType locatorType) {
		WebElement we = this.elementBy(locatorType, locator);
		this.driver.switchTo().frame(we);
	}
	public void switchToFrame(WebElement frameElement){
		driver.switchTo().frame(frameElement);
	}
	public void switchToFrame(int index){
		driver.switchTo().frame(index);
	}
	public void switchToParentFrame(){
		driver.switchTo().parentFrame();
	}
	public void switchToOutOfFrame(){
		driver.switchTo().defaultContent();
	}

	public void maximizeBrowser(){
		driver.manage().window().maximize();
	}

	public void minimizeBrowser(){
		driver.manage().window().minimize();
	}
	public void switchToTab(int tabIndex){
		Set<String> windowHandles=driver.getWindowHandles();
		List<String> windowHandlesList = new ArrayList<>(windowHandles);
		driver.switchTo().window(windowHandlesList.get(tabIndex));
	}
	public String getAttribute(String locator,String attributeName){
		WebElement element = driver.findElement(By.xpath(locator));
		return element.getAttribute(attributeName);
	}


}
