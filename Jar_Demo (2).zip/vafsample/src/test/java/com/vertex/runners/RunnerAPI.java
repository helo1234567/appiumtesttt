package com.vertex.runners;

import com.vaf.BaseRunner;
import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import io.cucumber.junit.Cucumber;
import org.junit.runner.RunWith;


@RunWith(Cucumber.class)
@CucumberOptions(
		tags = { "@Sample" },
		features="src/test/resources/Features.API",
		glue={"com.vaf.steps"})
public class RunnerAPI extends BaseRunner {

}

