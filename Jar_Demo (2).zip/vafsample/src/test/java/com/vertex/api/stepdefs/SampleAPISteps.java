////<!DOCTYPE suite SYSTEM "http://testng.org/testng-1.0.dtd" >
//package com.vertex.api.stepdefs;
//
//import com.vertex.api.model.SampleAPIModel;
//import org.testng.annotations.Test;
//
//import cucumber.api.java.en.When;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import io.restassured.response.Response;
//import io.restassured.response.ResponseBody;
//
////import project.api.SpectrumAPIBuilder;
////import project.domain.page.SpectrumHomePage;
//import com.vaf.api.APIManager;
//
//
//public class SampleAPISteps {
//
//	Response activeResponse;
//
//	String authCode           = "";
//	String access_token       = "";
//	String id_token           = "";
//	String refresh_token      = "";
//	String mbo_access_token   = "";
//	String akana_access_token = "";
//
//
//	@Then("Verify that I have recieved the {string}")
//	public void assertAuthCodePresent(String key) {
//		APIManager.verifyHasKey(activeResponse, key);
//	}
//
//	@Then("Verify that Server responded OK")
//	public void assertResponseOK() {
//		APIManager.verifyResponseOK(activeResponse);
//	}
//
//	@Then("Verify that response has key {string} with value {string}")
//	public void assertKeyHasValue(String key, String value) {
//		APIManager.keyHasValue(activeResponse, key, value);
//	}
//	@Then("Verify that response has key {string} with value {int}")
//	public void assertKeyHasValue(String key, int value) {
//		APIManager.keyHasValue(activeResponse, key, value);
//	}
//	@Then("Verify that response has key {string} with boolean value {string}")
//	public void assertKeyHasBooleanValue(String key, String value) {
//		APIManager.keyHasValue(activeResponse, key, value.equals("true") );
//	}
//
//
//	@Given("I Request autherization code from Spectrum Server")
//	@Test
//	public void specAuthTest() {
//		activeResponse = SampleAPIModel.specAuthRequest();
//		ResponseBody response = activeResponse.getBody();
//
//		authCode = response.jsonPath().getString("authCode");
//
//	}
//
//
//	@Given("I Request session tokens from Spectrum Server")
//	@Test(description = "Test Token based on authCode", dependsOnMethods = "specAuthTest")
//	public void specTokenTest() {
//
//		System.out.println("AUTH CODE: " + authCode + "\n");
//		activeResponse = null;
//		activeResponse = SampleAPIModel.specTokenRequest(authCode);
//		ResponseBody response = activeResponse.getBody();
//
//		access_token       = response.jsonPath().getString("access_token");
//		id_token           = response.jsonPath().getString("id_token");
//		refresh_token      = response.jsonPath().getString("refresh_token");
//		mbo_access_token   = response.jsonPath().getString("mbo_access_token");
//		akana_access_token = response.jsonPath().getString("akana_access_token");
//
//		System.out.println("MBO: " + response.asString());
//		System.out.println("MBO: " + mbo_access_token);
//	}
//
//	@When("I Login to the spectrum mobile api")
//	@Test(description = "Test Login based on tokens recieved from the token api", dependsOnMethods = "specTokenTest")
//	public void specLoginTest() {
//		activeResponse = SampleAPIModel.specLoginRequest(akana_access_token, mbo_access_token);
//		ResponseBody response = activeResponse.getBody();
//	}
//
//	@When("I Check users elegibility")
//	@Test(description = "Test user elegibility", dependsOnMethods = "specTokenTest")
//	public void specBuyInfoEligibilityTest() {
//		activeResponse = SampleAPIModel.specBuyInfoEligibilityRequest(akana_access_token, mbo_access_token);
//		ResponseBody response = activeResponse.getBody();
//	}
//
//	@When("I Request public key")
//	@Test(description = "Test Fetch public key", dependsOnMethods = "specTokenTest")
//	public void specPublicKeyTest() {
//		activeResponse = SampleAPIModel.specPublicKeyRequest(akana_access_token);
//		ResponseBody response = activeResponse.getBody();
//	}
//}
