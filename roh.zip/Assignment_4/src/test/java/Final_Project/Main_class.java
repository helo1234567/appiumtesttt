package Final_Project;
import java.awt.AWTException;
import java.io.IOException;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class Main_class {
	
	WebDriver driver=new ChromeDriver();
	Object_class object=new Object_class(driver);
	
	@BeforeMethod
	public void Before_method() {
		
		driver.get("https://www.galaxy.pk/");
		driver.manage().window().maximize();
		PropertyConfigurator.configure("log4j.properties");
		}
	@Test
	public void All_Tasks() throws InterruptedException, IOException, AWTException {
		
		object.clicklaptop();
		
	}

}
