package curemd;
import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
public class Helo2 {
	
	
	Logger log=Logger.getLogger("Helo2");
	WebDriver driver;
		
		
	@FindBy(xpath="//button[@type='button']")
	WebElement login1;

	@FindBy(xpath="//input[@name='vchLogin_Name']")
	WebElement username;

	@FindBy(xpath="//input[@name='vchPassword']")
	WebElement password;
		

	@FindBy(xpath="//i[@class='icon icon-patient']")
	WebElement patient;

	@FindBy(xpath="//iframe[@id='fra_Menu_CureMD']")
	WebElement frame1;


	
	@FindBy(xpath="//iframe[@id='fraCureMD_Body']")
	WebElement frame2;

	
	@FindBy(xpath="//td[@class='ButtonItem' and @title='Add Patient']")
	WebElement addpatient1;
	
	
	@FindBy(xpath="//select[@class='w102P' and @id='cmbVTitle']")
	WebElement title;
	
	@FindBy(xpath="//input[@id='txtVFNAME']")
	WebElement firstname1;
	
	@FindBy(xpath="//input[@id='txtVLNAME' and @type='text']")
	WebElement lastname1;
	
	@FindBy(xpath="//select[@id='cmbVSEX' and @class='w102P']")
	WebElement gender;
	
	@FindBy(xpath="//input[@id='txtDDOB' and @class='w75P']")
	WebElement date;
	
	@FindBy(xpath="//span[@class='select2-selection__arrow']")
	WebElement location;
	
	@FindBy(xpath="//input[@id='txtvcity' and @class='w100P']")
	WebElement city;
	
	@FindBy(xpath="//input[@id='txtVZIP' and @class='w44 fl']")
	WebElement zip;
	
	@FindBy(xpath="//input[@id='txtVEMAIL' and @class='w100P']")
	WebElement email;
	
	
	@FindBy(xpath="//input[@id='txtVSTATE' and @class='fl w30']")
	WebElement state;
	
	@FindBy(xpath="//input[@class='select2-search__field']")
	WebElement location1;
	
	@FindBy(id="imgpInsurance")
	WebElement primaryInsurance;
	
	@FindBy(id="imgSInsurance")
	WebElement secondaryInsurance;
	
	@FindBy(id="cmbIPLANID")
	WebElement primaryplanDropdown;
	
	@FindBy(id="cmbPlanAdd")
	WebElement primaryaddressDropdown;
	
	@FindBy(id="txtDSIGNONFILE")
	WebElement primarysignoutFile;
	
	@FindBy(id="cmbSECPLANID")
	WebElement secondaryplanDropdown;
	
	@FindBy(id="cmbSecPlanAdd")
	WebElement seconadaryaddressDropdown;
	
	@FindBy(id="txtSecDSIGNONFILE")
	WebElement secondarysignoutFile;
	
	@FindBy(id="tdsave")
	WebElement saveButton;
	
	@FindBy(id="DynamicBHdialogbox")
	WebElement save_as_new_frame;
	
	@FindBy(id="saveAsNewButton")
	WebElement saveAsNew;
	
	
	@FindBy (xpath="//a[@id='Provider_Notes_anchor']")
	WebElement providernote;
	
	@FindBy (xpath="//iframe[@id='fraCureMD_Patient_Menu']")
	WebElement provider_notes_frame;
	
	@FindBy (xpath="//a[@id='Provider_Notes_New_Case_anchor']")
	WebElement newcase;
	
	@FindBy (xpath="//input[@id='txtVCNAME']")
	WebElement newcase_name;
	
	@FindBy (xpath="//input[@name='txtDSTART']")
	WebElement newCase_DOB;
	
	@FindBy (xpath="//td[@id='cmdSubmit']")
	WebElement newCase_Save;
	
	@FindBy (xpath="//span[contains(text(),'asad')]")
	WebElement newCase_Save_or_not;
	
	@FindBy (id="Provider_Notes_Provider_Notes_anchor")
	WebElement providernote_from_dropdown;
	
	@FindBy (xpath="//td[@class='ButtonItem' and @id='SpAdd1']")
	WebElement addprovider_notebutton;
	
	@FindBy (xpath="//input[@id='Sdate' and @name='Sdate']")
	WebElement providernote_date;
	
	@FindBy (xpath="//span[@class='select2-selection__rendered' and @id='select2-cmbProvider-container']")
	WebElement provider_dropdownselect;
	
	@FindBy (xpath="//input[@class='select2-search__field']")
	WebElement provider_dropdown_sendkeys;
	
	@FindBy (xpath="//select[@id='cmbRTemplate']")
	WebElement note_template;
	
	@FindBy (xpath="//select[@id='txtVREASON']")
	WebElement visit_reason;
	
	@FindBy (xpath="//span[@id='select2-cmbLocation-container']")
	WebElement location_addnotes;
	
	@FindBy (xpath="//input[@class='select2-search__field']")
	WebElement location_sendkeys;
	
	@FindBy (id="btnSave")
	WebElement create_providernote;
	
	@FindBy (xpath="//span[contains(text(),'Admit Note')]")
	WebElement admit_note;
	
	@FindBy (xpath="//a[@id='Clinical_Diagnoses_6_anchor']/child::a[@style='cursor:pointer;color:green;font-size:10px;font-family:arial']")
	WebElement diagnosisButton;
	
	@FindBy (id="tdAddDiagnosis")
	WebElement diagnoses_add;
	
	
	@FindBy (id="DynamicBHdialogbox")
	WebElement diagnoses_frame;
	
	@FindBy (xpath="//input[@id='txtKeyword']")
	WebElement search_ICD;
	
	@FindBy (xpath="//img[@id='imgMaster']")
	WebElement click_search;
	
	@FindBy (xpath="//td[@id='tdSaveDiagnosis']")
	WebElement click_save;
	
	@FindBy (xpath="//a[@id='0']")
	WebElement click_term;
	
	@FindBy (id="tdSoapAccept")
	WebElement click_accept;
	
	@FindBy (xpath="//span[@title='Cholera due to Vibrio cholerae 01, biovar eltor']")
	WebElement fulldescription;
	
	@FindBy (id="Clinical_Lab_Order_7_anchor")
	WebElement click_order;
	
	@FindBy (xpath="//a[@id='OrderResult_8_2_anchor']//child::a")
	WebElement add_Procedure;
	
	@FindBy (xpath="//input[@id='txtSearch']")
	WebElement procedure_sendkeys;
	
	@FindBy (xpath="//span[contains(text(),'99211 - ')]")
	WebElement procedure_click;
	
	@FindBy (id="BaseIntelliSenseControl1_spSearch")
	WebElement procedure_click1;
	
	@FindBy (xpath="//ul[@id='ulSearchResultFav']//child::a")
	WebElement select_description;
	
	@FindBy (xpath="//td[@id='tdSaveDiagnosis']")
	WebElement save_accept;
	
	@FindBy (id="sp_eSuperbill")
	WebElement super_bill;
	
	@FindBy (xpath="//select[@id='cmdPatType']")
	WebElement select_patient;
	
	@FindBy (xpath="//td[@onclick='javascript:SubmitForm()']")
	WebElement click_create;
	
	@FindBy (xpath="//select[@id='ddleandm']")
	WebElement evaluation_management;
	
	@FindBy (xpath="//input[@id='chk99211']")
	WebElement check_box;
	
	@FindBy (xpath="//input[@id='gvSuperBill_ctl02_txtDxPointer']")
	WebElement Dx_ptr ;
	
	@FindBy (xpath="//input[@id='chkDxPointer_1']")
	WebElement select_one ;

	 @FindBy (xpath="//input[@id='gvSuperBill_ctl02_txtAmount']")
	 WebElement EnterAmount;

	@FindBy (xpath="//td[@id='sp_eSuperbill']")
	 WebElement SuperBill;

	
	

	public Helo2(WebDriver d){
		this.driver=d;
		PageFactory.initElements(d,this);
	}

	public void login() throws InterruptedException { 
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(username));
		Thread.sleep(2000);
		log.info("enter username");
		username.sendKeys("ChargeFinancial");
		log.info("enter password");
		password.sendKeys("SuPPort.2014");
		log.info("click login");
		login1.click();
		log.info("enter login details and press login");
		//Assert.assertEquals(driver.getTitle(), " Welcome to CureMD");
		
		
	   }
	
	public void addPatient() throws InterruptedException { 
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
		String parenthandle = driver.getWindowHandle();
		java.util.Set<String> handles1=driver.getWindowHandles();								
		for(String handle:handles1) {															
			if(!handle.equals(parenthandle)) {												
				driver.switchTo().window(handle);
				wait.until(ExpectedConditions.visibilityOf(frame1));
				driver.switchTo().frame(frame1);  
				log.info("switch to frame1");
				patient.click();
				log.info("click on patient tab");
				driver.switchTo().defaultContent();	
				log.info("switch to defaultcontent");
				driver.switchTo().frame(frame2); 
				log.info("switch to frame2");
				wait.until(ExpectedConditions.visibilityOf(addpatient1));
				log.info("click on addpatient button");
				addpatient1.click();
				//Assert.assertTrue(title.isDisplayed());
			}
			
		}}
			
			public void Patient_details() throws InterruptedException { 
				
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
				wait.until(ExpectedConditions.visibilityOf(title));
				Select select1= new Select(title);
				select1.selectByIndex(0);
				log.info("select title eg Dr");
				Thread.sleep(2000);
				firstname1.sendKeys("rararar");
				log.info("enter firstname of the patient");
				Thread.sleep(2000);
				lastname1.sendKeys("asadadadad");
				log.info("enter lastname of patient");
				Thread.sleep(3000);
				Select select2= new Select(gender);
				select2.selectByIndex(0);
				log.info("enter gender");
				Thread.sleep(2000);
				date.sendKeys("12/08/2022");
				log.info("enter date");
				Thread.sleep(3000);
				location.click();
				location1.sendKeys("HOSPITAL",Keys.ENTER);
				log.info("enter location of patient");
				city.sendKeys("New York");
				log.info("enter city of patient");
				zip.sendKeys("10009");
				log.info("enter zipcode of city");
				email.sendKeys("gasadraza@gmail.com");
				log.info("enter email of patient");
				state.sendKeys("pakistan");
				log.info("enter state of patient");
				
				
			}
			
			public void Insuranceplan_Selection() throws InterruptedException { 

				Select select;
				Actions actions;
				primaryInsurance.click();
				log.info("expand primary insurance");
				select = new Select(primaryplanDropdown);
				select.selectByVisibleText("AARP");
				log.info("select plan from primaryplan dropdown");
				Thread.sleep(1000);
				select = new Select(primaryaddressDropdown);
				select.selectByVisibleText("P O BOX 1017");
				log.info("select address from primaryaddress dropdown");
				primarysignoutFile.sendKeys("12/01/2022");
				log.info("enter date of primaryinsurance plan");
				secondaryInsurance.click();
				log.info("expand secondary insurance");
				select = new Select(secondaryplanDropdown);
				select.selectByVisibleText("AETNA");
				log.info("select plan from secondaryplan dropdown");
				Thread.sleep(1000);
				select = new Select(seconadaryaddressDropdown);
				select.selectByVisibleText("P.O. BOX 981106");
				log.info("select address from secondaryaddress dropdown");
				secondarysignoutFile.sendKeys("12/02/2022");
				log.info("enter date of secondaryinsurance plan ");
				actions = new Actions(driver);
				actions.sendKeys(Keys.PAGE_UP).build().perform();
				actions.sendKeys(Keys.PAGE_UP).build().perform();
				saveButton.click();
				log.info("click on save button to save all data of patient");
				Thread.sleep(3000);
				//Assert.assertTrue(save_as_new_frame.isDisplayed());
				if(save_as_new_frame.isDisplayed()) {
					
					
					driver.switchTo().frame(save_as_new_frame);
					saveAsNew.click();
					
					
				}
				
			}
			
				public void providerNotes() throws InterruptedException { 
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
				driver.switchTo().defaultContent();
				log.info("switch to default frame");
				driver.switchTo().frame(provider_notes_frame);
				log.info("switch to provider_notes_frame");
				wait.until(ExpectedConditions.visibilityOf(providernote));
				providernote.click();
				log.info("click on providernote after switching frame");
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(newcase));	
				newcase.click();
				log.info("click on newcase after expanding providernote");
				driver.switchTo().defaultContent();
				log.info("switch to defaultcontent");
				driver.switchTo().frame(frame2);
				log.info("switch to frame2");
				wait.until(ExpectedConditions.visibilityOf(newcase_name));	
				newcase_name.sendKeys("asad");
				log.info("enter name of the patient");
				newCase_DOB.sendKeys("12/01/2022");
				log.info("enter date of birth of patient");
				Thread.sleep(3000);
				newCase_Save.click();
				//Assert.assertTrue(newCase_Save_or_not.isDisplayed());
				
				}
	
				public void Click_NoteButton() throws InterruptedException { 
					WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));	
					driver.switchTo().defaultContent();
					driver.switchTo().frame(provider_notes_frame);
					wait.until(ExpectedConditions.visibilityOf(providernote_from_dropdown));
					providernote_from_dropdown.click();
					driver.switchTo().defaultContent();
					driver.switchTo().frame(frame2);
					wait.until(ExpectedConditions.visibilityOf(addprovider_notebutton));
					addprovider_notebutton.click();
					providernote_date.sendKeys("12/14/2022");
					provider_dropdownselect.click();
					wait.until(ExpectedConditions.visibilityOf(provider_dropdownselect));
					provider_dropdown_sendkeys.sendKeys("Live, Test",Keys.ENTER);
					Thread.sleep(1000);
					Select select;
					select = new Select(note_template);
					select.selectByVisibleText("Education");
					Thread.sleep(2000);
					select = new Select(visit_reason);
					select.selectByIndex(1);
					Thread.sleep(2000);
					location_addnotes.click();
					Thread.sleep(2000);
					location_sendkeys.sendKeys("HOSPITAL",Keys.ENTER);
					Thread.sleep(1000);
					create_providernote.click();
					//Assert.assertTrue( admit_note.isEnabled());
				}
				
				public void add_Diagnoses() throws InterruptedException { 
					WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
					driver.switchTo().defaultContent();
					driver.switchTo().frame(provider_notes_frame);
					Thread.sleep(2000);
					diagnosisButton.click();
					driver.switchTo().defaultContent();
					driver.switchTo().frame(frame2);
					driver.switchTo().defaultContent();
					driver.switchTo().frame( diagnoses_frame);
					
					
					wait.until(ExpectedConditions.visibilityOf(search_ICD));
					search_ICD.sendKeys("A00.0");
					Thread.sleep(2000);
					click_search.click();
					Thread.sleep(3000);
					click_term.click();
					Thread.sleep(2000);
					click_save.click();
					Thread.sleep(2000);
					click_accept.click();
					//Assert.assertTrue( fulldescription.isDisplayed());
					
				}
				public void Add_Procedure() throws InterruptedException { 
					WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(20));
					driver.switchTo().defaultContent();
					driver.switchTo().frame(provider_notes_frame);
					Thread.sleep(3000);
					click_order.click();
					Thread.sleep(1000);
					add_Procedure.click();
					driver.switchTo().defaultContent();
					driver.switchTo().frame(frame2);
					driver.switchTo().defaultContent();
					driver.switchTo().frame( diagnoses_frame);
					procedure_sendkeys.sendKeys("99211");
					Thread.sleep(3000);
					procedure_click1.click();
					Thread.sleep(1000);
					select_description.click();
					Thread.sleep(1000);
					save_accept.click();
					
					
					
				
				}
				
				public void super_Bill() throws InterruptedException { 
					driver.switchTo().defaultContent();
		        	Thread.sleep(1000);
		        	driver.switchTo().frame(frame2);
		        	Thread.sleep(1000);
		        	SuperBill.click();
		        	Thread.sleep(1000);
		        	driver.switchTo().defaultContent();
		        	Thread.sleep(1000);
		        	driver.switchTo().frame(diagnoses_frame);
		        	Select select9= new Select(select_patient);
			        Thread.sleep(1000);
		        	select9.selectByVisibleText("New Patient");
			        Thread.sleep(1000);
			        click_create.click();
			        Thread.sleep(1000);
			        driver.switchTo().defaultContent();
		        	Thread.sleep(1000);
		        	driver.switchTo().frame(frame2);
		        	Select select10= new Select(evaluation_management);
		        	select10.selectByIndex(1);
		        	
		        	 Thread.sleep(1000);
		        	 Dx_ptr.click();
		        	 Thread.sleep(1000);
		        	 select_one.click();
		        	 Thread.sleep(1000);
		        	 Actions actions=new Actions(driver);
		        	 actions.doubleClick( EnterAmount).perform();
		        	Thread.sleep(1000);
		        	 EnterAmount.sendKeys("10"+Keys.ENTER);
		        	
			       
		        }
					
					
					


}
