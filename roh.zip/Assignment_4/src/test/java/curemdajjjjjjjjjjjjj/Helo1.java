package curemd;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class Helo1 {
	
	WebDriver driver=new ChromeDriver();
	Helo2 object=new Helo2(driver);
	
	@BeforeTest
	public void Before_method() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\4391\\Desktop\\chromedriver_win32\\chromedriver.exe");
		driver.get("http://release01.curemd.com/curemdy/datlogin.asp");
		driver.manage().window().maximize();
		driver.manage().window().maximize();
		// PropertyConfigurator.configure("log4j.properties");
		   
		}
	@Test(priority=0)
	public void Case0() throws InterruptedException, IOException {
		object.login();
		
		
	}
	@Test(priority=1)
	public void Case1_2() throws InterruptedException, IOException {
		object.addPatient();
		object.Patient_details();
		object.Insuranceplan_Selection();
		object.providerNotes();
		
		}
	@Test(priority=2)
	public void Case3() throws InterruptedException, IOException {
		object.Click_NoteButton();
		
		}
	
	@Test(priority=3)
	public void Case4() throws InterruptedException, IOException {
		object.add_Diagnoses();
		
		}
	
	@Test(priority=4)
	public void Case5() throws InterruptedException, IOException {
		object.Add_Procedure();
		
		}
	@Test(priority=5)
	public void Case6() throws InterruptedException, IOException {
		object.super_Bill();
		
		}
}
