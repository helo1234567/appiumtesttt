package HomeTask.copy;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Object_Class {
	
WebDriver driver;
	
	Logger log=Logger.getLogger("Object_class");
	
	@FindBy(xpath="(//li[@id='menu-item-4761']//child::a[@class='dropdown-toggle'])[2]")
	WebElement click_laptop;
	
	@FindBy(xpath="//h2[@class='woocommerce-loop-product__title']")
	WebElement Names;
	
	@FindBy(xpath="(//i[@class='ec ec-menu'])[2]")
	WebElement products;
	
	@FindBy(xpath="//select[@name='ppp']")
	WebElement select1;
	
	@FindBy(xpath="//span[@class='woocommerce-Price-currencySymbol']")
	WebElement price;
	
	@FindBy(xpath="//div[@class='product-thumbnail product-item__thumbnail']")
	WebElement picture;
	
	@FindBy(xpath="//img[@class='wp-post-image jetpack-lazy-image jetpack-lazy-image--handled']")
	WebElement image;
	
	@FindBy(xpath="(//a[@class='next page-numbers'])[2]")
	WebElement image1;
	
	@FindBy(xpath="//div[@class='product-loop-body product-item__body']/a")
	WebElement name1;
	
	@FindBy(xpath="//input[@id='goto-page']")
	WebElement putno;
	
	
	
	
	
	    public Object_Class(WebDriver d){
		this.driver=d;
		PageFactory.initElements(d,this);
	}
	   
   
	  public void clicklaptop() throws InterruptedException, IOException, AWTException {
		   WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(15));
		   wait.until(ExpectedConditions.visibilityOf(click_laptop));
		   
		   Actions act=new Actions(driver);
		   act.moveToElement(click_laptop).click().perform();
		   ArrayList<String> Tnames=new ArrayList<String>(); 
//		   String size=putno.getAttribute("max");
//		   int length = Integer.parseInt(size);
		   
//	  for(int j=1;j<=length;j++) {
//		  putno.click();
//			Thread.sleep(3000);
//			putno.clear();
//			Thread.sleep(3000);
//			putno.sendKeys(""+j+""+Keys.ENTER);
	  
			ArrayList<List<Integer>> group = new ArrayList<List<Integer>>();
		  //List<WebElement> Tabletnames=driver.findElements(By.xpath("//div[@class='product-loop-body product-item__body']//child::h2[@class='woocommerce-loop-product__title']"));
		 List<WebElement> Tabletdetails=driver.findElements(By.xpath("//div[@class='product-loop-body product-item__body']/a"));
		   for(WebElement e:Tabletdetails) {
			   String names=e.getText();
			   Tnames.add(names);
			   
			   
			 
			  
		   }
		   
		  
			
		   ArrayList<String> Price=new ArrayList<String>(); 
		   List<WebElement> Prices=driver.findElements(By.xpath("//span[@class='price']"));
		   for(WebElement e:Prices) {
			   String price1=e.getText();
			   Price.add(price1);
			   
		   }
	   
		   
		   ArrayList<String> description=new ArrayList<String>(); 
		   List<WebElement> descriptions=driver.findElements(By.xpath("//div[@class='product-short-description']"));
		   for(WebElement e:descriptions) {
			   String d1=e.getText();
			   description.add(d1);
			  
			  
		   
		   
	   
	  }  
	  
		   XSSFWorkbook workbook1=new XSSFWorkbook();
			XSSFSheet sheet1=workbook1.createSheet("asadraza");
			 log.info("create sheet with name asadraza"); 
			sheet1.createRow(0);
			 log.info("create row zero"); 
			sheet1.getRow(0).createCell(0).setCellValue("Names");
			 log.info("get rown and set first colom value as Names"); 
			sheet1.getRow(0).createCell(1).setCellValue("Price"); 
			log.info("get rown and set second colom value as Names");
			sheet1.getRow(0).createCell(2).setCellValue("Description");
			log.info("get rown and set second colom value as Names");
			
			for(int i=0;i<Tnames.size();i++) {
				DataFormatter df=new DataFormatter();
				
				sheet1.createRow(i);
				
				sheet1.getRow(i).createCell(0).setCellValue(Tnames.get(i));
				
			}
			
				for(int i=1;i<Prices.size();i++) {
					//DataFormatter df=new DataFormatter();
					
					
					sheet1.getRow(i).createCell(1).setCellValue(Price.get(i));
					
				}
				
				for(int i=1;i< descriptions.size();i++) {
					//DataFormatter df=new DataFormatter();
					
					
					sheet1.getRow(i).createCell(2).setCellValue(description.get(i));
					
				}

			File fil=new File("C:\\Users\\Hassan\\eclipse-workspace\\Assignment_4\\HomeExcelfiles\\home.xlsx");
			FileOutputStream fos=new FileOutputStream(fil);
			workbook1.write(fos);
			
//			 Actions a = new Actions(driver);
//			
//			 a.moveToElement(putno).build().perform();
			
			
	 // }
	  
	  
		   List<WebElement> pictures=driver.findElements(By.xpath("//div[@class='product-thumbnail product-item__thumbnail']"));
		   Robot robot = new Robot();
		   robot.keyPress(KeyEvent.VK_CONTROL);
		   robot.keyPress(KeyEvent.VK_S);
		   robot.keyRelease(KeyEvent.VK_CONTROL);
		   robot.keyRelease(KeyEvent.VK_S);
		   robot.keyPress(KeyEvent.VK_ENTER);
		   robot.keyRelease(KeyEvent.VK_ENTER);
		   
//		   for(WebElement e:pictures) {
//			   
//				  Actions a = new Actions(driver);
//				  
//				  a.sendKeys(Keys.PAGE_DOWN).build().perform();
//				  a.moveToElement(e).contextClick().build().perform();
//				    
//				    	Robot robot = new Robot();
//				    	for(int j=1;j<=8;j++) {
//				    		robot.keyPress(KeyEvent.VK_DOWN);
//							robot.keyRelease(KeyEvent.VK_DOWN);
//							
//				    	}
//				   
//				    	
//				    	
//					
//						
//						robot.keyPress(KeyEvent.VK_ENTER);
//						robot.keyRelease(KeyEvent.VK_ENTER);
//						Thread.sleep(4000);
//						robot.keyPress(KeyEvent.VK_ENTER);
//						robot.keyRelease(KeyEvent.VK_ENTER);
//						
//						Thread.sleep(3000);
//						
//				  
//		   }
//
//	  
	  }

	
	  
	  
	  

}










