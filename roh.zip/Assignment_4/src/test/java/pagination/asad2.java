package pagination;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



public class asad2 {
	WebDriver driver=new ChromeDriver();
	asad1 object =new asad1(driver);
    
    @BeforeTest
	public void Task1() throws InterruptedException {
		
    	
		driver.get("https://datatables.net/");
		driver.manage().window().maximize();
		
}
    @Test
    public void Task2() throws InterruptedException, IOException {
    	
    	object.enterdescription();
    	
    }

}