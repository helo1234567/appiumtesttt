package org.apache.commons.lang3;

public @interface RandomStringUtils {

}
