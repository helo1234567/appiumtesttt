package Trello;

import java.time.Duration;

import org.apache.commons.math3.ode.events.Action;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Object_Class {
	
WebDriver driver;
	
	
	
	@FindBy(xpath="//a[@class='Buttonsstyles__Button-sc-1jwidxo-0 kTwZBr']")
	WebElement loginButton;
	
	@FindBy(xpath="//input[@id='user']")
	WebElement enteremail;
	
	@FindBy(xpath="//input[@id='login']")
	WebElement submit_continue;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement pasword;
	
	@FindBy(xpath="//button[@id='login-submit']")
	WebElement login_submit;
	
	@FindBy(xpath="//p[@class='szBTSFrvPTLGHM']")
	WebElement create;
	
	@FindBy(xpath="(//div[@class='list-cards u-fancy-scrollbar u-clearfix js-list-cards js-sortable ui-sortable'])[1]")
	WebElement locator1;
	
	@FindBy(xpath="//p[contains(text(),'A board is made up of cards ordered on lists. Use it to manage projects, track information, or organize anything.')]")
	WebElement create1board1;
	
	@FindBy(xpath="//input[@type='text']")
	WebElement boardtitlee;
	
	@FindBy(xpath="//button[@class='ijFumaLuInvBrL bxgKMAm3lq5BpA SdamsUKjxSBwGb SEj5vUdI3VvxDc']")
	WebElement click_create;
	
	@FindBy(xpath="//input[@class='list-name-input']")
	WebElement firstlist;
	
	@FindBy(xpath="//span[@class='placeholder']")
	WebElement addanotherlist;
	
	@FindBy(xpath="//input[@class='nch-button nch-button--primary mod-list-add-button js-save-edit']")
	WebElement click_addlist;
	
	@FindBy(xpath="//input[@type='text' and @placeholder='Enter list title…']")
	WebElement secondlist;
	
	@FindBy(xpath="//input[@class='nch-button nch-button--primary mod-list-add-button js-save-edit']")
	WebElement click_addlist2;
	
	@FindBy(xpath="//a[@class='icon-lg icon-close dark-hover js-cancel-edit']")
	WebElement removethird;
	
	@FindBy(xpath="(//span[@class='js-add-a-card'])[1]")
	WebElement clickaddcard;
	
	@FindBy(xpath="//textarea[@class='list-card-composer-textarea js-card-title']")
	WebElement description_addlist;
	
	@FindBy(xpath="//input[@class='nch-button nch-button--primary confirm mod-compact js-add-card']")
	WebElement clickaddccard1;
	
	@FindBy(xpath="//a[@class='icon-lg icon-close dark-hover js-cancel']")
	WebElement crosss__description;
	
	@FindBy(xpath="//span[contains(text(),'Move')]")
	WebElement click_move2;
	
	@FindBy(xpath="//select[@class='js-select-list']")
	WebElement position;
	
	@FindBy(xpath="//input[@class='nch-button nch-button--primary wide js-submit']")
	WebElement move;
	
	@FindBy(xpath="//textarea[@class='list-card-edit-title js-edit-card-title']")
	WebElement edit_cardname;
	
	@FindBy(xpath="//input[@class='nch-button nch-button--primary wide js-save-edits']")
	WebElement click_save;
	
	@FindBy(xpath="//a[@class='button-link js-archive-card']//child::span[@class='js-sidebar-action-text']")
	WebElement archieve;
	
	@FindBy(xpath="//a[@class='quick-card-editor-buttons-item']//child::span[@class='quick-card-editor-buttons-item-text']")
	WebElement opencard;
	
	@FindBy(xpath="//a[@class='button-link js-delete-card negate']")
	WebElement delete;	
	
	@FindBy(xpath="//textarea[@class='list-card-composer-textarea js-card-title']")
	WebElement text_forsecondcard;
	
	@FindBy(xpath="//span[@class='list-card-title js-card-name']")
	WebElement clicktoopenpoup;
	
	@FindBy(xpath="//input[@class='list-name-input']")
	WebElement thirdlist;
	
	@FindBy(xpath="//a[@class='BIOyZdkbd7KotX _7xO25yaQAbZ4cb']")
	WebElement boarddisplayed;
	
	@FindBy(xpath="//input[@class='js-confirm full nch-button nch-button--danger']")
	WebElement deletecard;
	
	@FindBy(xpath="(//a[@class='open-card-composer js-open-card-composer'])[2]")
	WebElement clickaddccard2 ;
	
	 Object_Class(WebDriver d){
		this.driver=d;
		PageFactory.initElements(d,this);
	}
	   
	   
	   public void login() throws InterruptedException {
		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(loginButton));		
		loginButton.click();
		wait.until(ExpectedConditions.visibilityOf(enteremail));
		enteremail.sendKeys("asadrazamahmood@gmail.com");
		submit_continue.click();
		Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOf(pasword));
		pasword.sendKeys("Asad777&");
		login_submit.click();
		wait.until(ExpectedConditions.visibilityOf(create));
		Assert.assertTrue(create.isDisplayed());
		
	}
		public void CreateBoard(String randomstring) {
			WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
			wait.until(ExpectedConditions.visibilityOf(create));
			create.click();
			wait.until(ExpectedConditions.visibilityOf(create1board1));
			create1board1.click();
			wait.until(ExpectedConditions.visibilityOf(boardtitlee));
			boardtitlee.sendKeys(randomstring);
			click_create.click();
			//wait.until(ExpectedConditions.visibilityOf(boarddisplayed));
			//Assert.assertTrue(boarddisplayed.isDisplayed());
			   
		}	
			public void Createfirstlist(String randomstring) throws InterruptedException {
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
				//addanotherlist.click();
				 wait.until(ExpectedConditions.visibilityOf(firstlist));
				firstlist.sendKeys(randomstring);
				click_addlist.click();
				wait.until(ExpectedConditions.visibilityOf( secondlist));
				Assert.assertTrue( secondlist.isDisplayed());
			}
			public void Createsecondlist(String randomstring) throws InterruptedException {
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
				wait.until(ExpectedConditions.visibilityOf(secondlist));
				secondlist.sendKeys(randomstring);
				click_addlist2.click();
				Thread.sleep(4000);
				wait.until(ExpectedConditions.visibilityOf( thirdlist));
				Assert.assertTrue( thirdlist.isDisplayed());
				
			}
			
			public void Addcard(String randomstring) throws InterruptedException {
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
				wait.until(ExpectedConditions.visibilityOf(clickaddcard));
				clickaddcard.click();
				wait.until(ExpectedConditions.visibilityOf(description_addlist));
				description_addlist.sendKeys(randomstring);
				Thread.sleep(3000);
				clickaddccard1.click();
				Thread.sleep(2000);
				wait.until(ExpectedConditions.visibilityOf(text_forsecondcard));
				Assert.assertTrue(text_forsecondcard.isDisplayed());
				wait.until(ExpectedConditions.visibilityOf(crosss__description));
				crosss__description.click();
				Thread.sleep(3000);
				
				
			}
			
			public void Movecard(String randomstring) throws InterruptedException {
				
				
				
				Actions builder = new Actions(driver);

				//Building a drag and drop action
				builder.clickAndHold(locator1).moveToElement(clickaddccard2).release(clickaddccard2).build().perform();
				

				//Performing the drag and drop action
				
						

						//Performing the drag and drop action
					
//				Actions a = new Actions(driver);
//			    a.moveToElement(clicktoopenpoup).contextClick().build().perform();
//				click_move2.click();
//				Thread.sleep(2000);//
//				Select act=new Select(position);
//				act.selectByVisibleText(randomstring);
//				Thread.sleep(2000);
//
//				move.click();
//				Assert.assertEquals(clicktoopenpoup.getText(),randomstring);
				
			}
				
			public void editcardname() throws InterruptedException {
			      Actions a = new Actions(driver);
			      a.moveToElement(clicktoopenpoup).contextClick().build().perform();
			      Thread.sleep(4000);
			      edit_cardname.sendKeys("newcardname");
			      Thread.sleep(5000);
			      click_save.click();
			      Thread.sleep(6000);
			     // Assert.assertEquals(edit_cardname.getText(),"newcardname");
			      
			      
			}
			public void deletecard() throws InterruptedException {
				WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(30));
				
				  Actions a = new Actions(driver);
			      a.moveToElement(clicktoopenpoup).contextClick().build().perform();
			      Thread.sleep(3000);
			      opencard.click();
			      wait.until(ExpectedConditions.visibilityOf(archieve));
			     
				  
				 // a.sendKeys(Keys.PAGE_DOWN).build().perform();
				  a.moveToElement(archieve).build().perform();
				  
			      archieve.click();
				  Thread.sleep(4000);
				  delete.click();
				  Thread.sleep(4000);
				  deletecard.click();
				  driver.close();
				  //Assert.assertNull(clicktoopenpoup);
			} 

}
