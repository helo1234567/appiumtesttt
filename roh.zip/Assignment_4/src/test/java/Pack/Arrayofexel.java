package Pack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Arrayofexel {

	public static void main(String[] args) throws IOException {
		File excelfile=new File("./src/test/resources/test1.xlsx");
		System.out.println(excelfile.exists());
		FileInputStream fis=new FileInputStream(excelfile);
		XSSFWorkbook workbook=new XSSFWorkbook(fis);
		XSSFSheet sheet=workbook.getSheet("Sheet1");
		int noofrows=sheet.getPhysicalNumberOfRows();
		int noofcoloms=sheet.getRow(0).getLastCellNum();
		System.out.println(noofrows);
		System.out.println(noofcoloms);
		String array[][]=new String[noofrows][noofcoloms];
		for(int i=0;i<noofrows;i++) {
			for(int j=0;j<noofcoloms;j++) {
				DataFormatter df=new DataFormatter();
				array[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
				System.out.print(array[i][j]);
			}
			
		}
		
		workbook.close();
		fis.close();

	
	}

}
