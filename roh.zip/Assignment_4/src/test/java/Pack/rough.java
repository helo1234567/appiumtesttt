package Pack;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class rough {

	public static void main(String[] args) throws IOException {
		File file1=new File("./src/test/resources//NEPRA Complaint.xlsx");
		System.out.println(file1.exists());
		FileInputStream fis=new FileInputStream(file1);
		XSSFWorkbook workbook=new XSSFWorkbook(fis);
		XSSFSheet sheet=workbook.getSheet("Sheet2");
		int noofrows=sheet.getLastRowNum();
		int rows=sheet.getPhysicalNumberOfRows();
		int noofcoloms=sheet.getRow(0).getLastCellNum();
		
		System.out.println(noofrows);
		System.out.println(rows);
		System.out.println(noofcoloms);
		String array[][]=new String[noofrows][noofcoloms];
		for(int i=1;i<noofrows;i++) {
			for(int j=0;j<noofcoloms-4;j++) {
				DataFormatter df=new DataFormatter();
				array[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
			XSSFCell asad=sheet.getRow(i).getCell(j);
			System.out.println(asad);
			}
			
			
			
		}
		
		
	

	}

}
