package Pack;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class write {

	public static void main(String[] args) throws IOException {
		XSSFWorkbook workbook2=new XSSFWorkbook();
		XSSFSheet Sheet1=workbook2.createSheet("Sheet1");
		Sheet1.createRow(0);
		Sheet1.getRow(0).createCell(0).setCellValue("helo123");
		
		File file=new File("C:\\Users\\Hassan\\eclipse-workspace\\Assignment_4\\ExcelFiles\\testasad.xlsx");
		FileOutputStream fos=new FileOutputStream(file);
		workbook2.write(fos);
	}

}
