package Lab_7;

import org.openqa.selenium.WebDriver;
import java.awt.AWTException;

import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Task_2 {

	ChromeOptions ops = new ChromeOptions();
	
	WebDriver driver=new ChromeDriver();
	Task_1 object=new Task_1(driver);
	@BeforeMethod
	public void before() throws InterruptedException { 
		
    driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject");
    driver.manage().window().maximize();
  // PropertyConfigurator.configure("log4j.properties");
   
		
}
    
    @Test(description="All Steps")
	public void Task1() throws InterruptedException, AWTException { 
    	 
    	object.login();
    
		
    }
}
