package com.vta.ui.steps.mobile;

import java.io.IOException;

import org.testng.annotations.Test;

import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.mobile.MobileModule;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MobileSteps {
	
	UIManager mgr = new UIManager(BrowserType.CHROME32);
	MobileModule m = new MobileModule(mgr.driver);
	
	@Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) throws IOException {
		mgr.startSession(url);

	}
	
	@Test
	@When("Maximize the window")
	public void Maximize_window() throws IOException, InterruptedException {
		mgr.driver.manage().window().maximize();
		Thread.sleep(5000);
	}

	@Test
	@And("Click on Find a store Button")
	public void Click_on_FindStore() throws IOException {

		mgr.click(m.Find_Store);
		mgr.waitUntilVisible(m.visit_store);
	}

	@Test
	@And("Click on Manage Account Button")
	public void Click_on_Manageaccount() throws IOException {

		mgr.click(m.Manage_Account);
		mgr.waitUntilVisible(m.Sign_in);
	}

	@Test
	@And("Click on Espanol Button")
	public void Click_on_Espanol() throws IOException {

		mgr.click(m.Espanol);
		mgr.waitUntilVisible(m.Espanol_zipcode);
	}

	@Test
	@And("Scroll down to TV link icon")
	public void Scroll_to_Tv_ink() throws IOException, InterruptedException {
		mgr.waitUntilVisible(m.Espanol);
		mgr.scroll(m.TV_icon,false);

	}

	@Test
	@And("Click on TV link icon")
	public void Click_on_TV_link() throws IOException {

		mgr.click(m.TV_icon);
		mgr.waitUntilVisible(m.Stream_Tv);
	}
	@Test
	@And("Scroll down to Fotter Section")
	public void Scroll_to_Footer() throws IOException, InterruptedException {


	}

	@Test
	@And("Scroll down to One of the Internet plan")
	public void Scroll_to_Internet_Pans() throws IOException, InterruptedException {
		mgr.waitUntilVisible(m.Espanol);
		mgr.scroll(m.Get_500_MBps,false);
		Thread.sleep(5000);
	}

	@Test
	@And("Click on Get 500 MBps plan")
	public void Click_on_500_MBps_plan() throws IOException, InterruptedException {

		mgr.click(m.Get_500_MBps);
		mgr.waitUntilVisible(m.Terms_conditions);
		Thread.sleep(5000);
	}

	@Test
	@And("Scroll to Internet Check Box")
	public void Scroll_to_Internet_Check_Box() throws IOException, InterruptedException {

		mgr.scroll(m.Internet_plan_check_button,false);

	}
	@Test
	@And("Click on Internet Check Box")
	public void Click_on_Internet_Check_Box() throws IOException {

		mgr.click(m.Internet_plan_check_button);

	}

	@Test
	@And("Fill Street Address in Address Field")
	public void Fill_Street_Address_in_Address_Field() throws IOException {

		mgr.fillTextField(m.Street_Address,"1119 Anise Ln");

	}
	@Test
	@And("Fill Apt in Apt Field")
	public void Fill_Apt_in_Apt_Field() throws IOException {

		mgr.fillTextField(m.APT_Unit,"63026");

	}

	@Test
	@And("Fill Zipcode in zipcode Field")
	public void Fill_Zipcode_in_zipcode_Field() throws IOException {

		mgr.fillTextField(m.Zip_code,"63026");

	}


	@Test
	@And("Click on Build Custom plan")
	public void Click_on_Build_Custom_plan() throws IOException {

		mgr.click(m.Build_custom_plan);
		mgr.waitUntilVisible(m.Select_Button);
	}
	@Test
	@And("Select one of the Plan")
	public void Select_one_of_the_Plan() throws IOException {

		mgr.click(m.Select_Button);
		mgr.waitUntilVisible(m.Select_modem);
	}

	@Test
	@And("Select Internet Modem")
	public void Select_Internet_Modem() throws IOException {

		mgr.click(m.Select_modem);

	}

	@Test
	@And("Click on continue Button")
	public void Click_on_continue_Button() throws IOException {

		mgr.click(m.continue_button);
		mgr.waitUntilVisible(m.email_addresss);
	}

	@Test
	@And("Fill all the required information")
	public void Fill_all_the_required_information() throws IOException {
		mgr.scroll(m.First_name,false);
		mgr.fillTextField(m.First_name,"asad");
		mgr.waitUntilVisible(m.Last_name);
		mgr.fillTextField(m.Last_name,"raza");
		mgr.waitUntilVisible(m.email_addresss);
		mgr.fillTextField(m.email_addresss,"gasadraza@gmail.com");
		mgr.waitUntilVisible(m.phone_number);
		mgr.fillTextField(m.phone_number,"+1-212-456-7890");
		mgr.click(m.phone_type);
		mgr.click(m.yes_no);
		mgr.click(m.email_notified);
		mgr.click(m.check_to_proceed);
		mgr.click(m.calender);
		mgr.click(m.prev_month);
		mgr.click(m.select_date);
	}

	@Test
	@And("Click on Complete Order Button")
	public void Click_on_Complete_Order_Button() throws IOException {
		mgr.click(m.complete_order);


	}
	@Test
	@And("Scroll down to Voice link icon")
	public void Scroll_down_to_Voice_link_icon() throws IOException, InterruptedException {
		mgr.waitUntilVisible(m.Espanol);
		mgr.scroll(m.Voice_link_icon,false);

	}

	@Test
	@And("Click on Voice link icon")
	public void Click_on_Voice_link_icon() throws IOException {

		mgr.click(m.Voice_link_icon);
		mgr.waitUntilVisible(m.spectrum_voice);
	}












	
	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_Title(String Title){
		String actual_Title=mgr.getTitle();
		UIManager.assertEqual(actual_Title, Title, "Verify title is matched or not");
		
		
	}
	
	@Test
	@Then("Close the Browser")
	public void Close_Browser() throws IOException {
		mgr.endSession();

	}
	
	@Test
	@And("User Hover over on Mobile Tab")
	public void Hover_MobileTab() throws IOException {
		
	mgr.waitUntilVisible(m.Hover_Mobile_Tab);
	mgr.hover(m.Hover_Mobile_Tab);
	mgr.waitUntilVisible(m.click_spectrum_Mobile);
	
	}
	
	@Test
	@Then("Verify that User must see {string} in dropdown")
	public void verify_dropdown_value(String dropdown_value) throws IOException {
		String Text=m.click_spectrum_Mobile.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}
	
	
	@Test
	@And("User Hover over on Mobile Tab and Click on Spectrum Mobile")
	public void Click() throws IOException {
		mgr.waitUntilVisible(m.Hover_Mobile_Tab);
		mgr.hover(m.Hover_Mobile_Tab);
		mgr.waitUntilVisible(m.click_spectrum_Mobile);
		mgr.click(m.click_spectrum_Mobile);
		

	
	}
	
	@Test
	@Then("Verify that URL of the page should be {string}")
	public void Verify_URL(String URL) throws InterruptedException {
		Thread.sleep(5000);
		String actual_URL=mgr.getURL();
		UIManager.assertEqual(actual_URL, URL, "Verify URL is matched or not");
		
	    
	}
	
	@Test
	@And("User Hover over on Products Tab")
	public void Hover_Products_tab() throws IOException {
		
	mgr.waitUntilVisible(m.Hover_over_product);
	mgr.hover(m.Hover_over_product);
	mgr.waitUntilVisible(m.Select_phones);
	
	}
	
	@Test
	@Then("Verify that User should see {string} in dropdown")
	public void verify_dropdowns_value(String dropdown_value) throws IOException {
		String Text=m.Select_phones.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");

	}
	
	@Test
	@And("User Hover over on Products Tab and Click on Phones")
	public void Hover_Plus_click() throws IOException {
		mgr.waitUntilVisible(m.Hover_over_product);
		mgr.hover(m.Hover_over_product);
		mgr.waitUntilVisible(m.Select_phones);
		mgr.click(m.Select_phones);
		
		//mgr.hoverAndClick(m.Hover_over_product, m.Select_phones);
	
	}
	
	@Test
	@And("Click on Motorola Tab")
	public void Click_MotorolaTab() throws IOException {
		
		mgr.click(m.motorola_tab);
		
	}
	

	@Test
	@And("Click on Google Tab")
	public void Click_GoogleTab() throws IOException {
		
		mgr.click(m.Google_tab);
		
	}
	
	@Test
	@And("Click on samsung Tab")
	public void Click_samsungTab() throws IOException {
		
		mgr.click(m.samsung_tab);
		
	}
	
	@Test
	@And("Click on Deals Tab")
	public void Click_DealsTab() throws IOException {
		
		mgr.click(m.Deals_tab);
		
	}
	
	@Test
	@And("Scroll down to dropdown and click on it")
	public void Scroll_to_dropdown() throws IOException, InterruptedException {
		
		mgr.click(m.Dropdown);
		
	}
	@Test
	@And("Select {string} from dropdown")
	public void selevt_dropdown(String Text) throws InterruptedException {
		mgr.click(m.price_low_tohigh);
		
	}
	
	@Test
	@And("Select {string} from dropdowns")
	public void select_dropdown(String Text) throws InterruptedException {
		mgr.click(m.Featured);
		
	}
	
	@Test
	@And("Selects {string} from dropdown")
	public void selects_dropdown(String Text) throws InterruptedException {
		mgr.click(m.price_high_Low);
		
	}
	
	@Test
	@Then("Verify that User will see {string} in dropdown")
	public void verify_dropdown(String dropdown_value) throws IOException, InterruptedException {
		Thread.sleep(7000);
		String Text=m.Dropdown.getText();
		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is selected or not ");

	}
	
	
	
	@Test
	@And("User clicks on Apple Tab")
	public void Click_AppleTab() throws IOException {
		
		mgr.click(m.iphone_tab);
		
	}
	
	@Test
	@And("Scroll down to Iphone 14 promax and click on it")
	public void Click_14promax() throws IOException, InterruptedException {
		mgr.waitUntilVisible(m.Deals_tab);
		mgr.scroll(m.iphone_14_promax,false);
		mgr.click(m.iphone_14_promax);
		
	}
	
	@Test
	@And("Click on Gold color")
	public void Click_color() throws InterruptedException {
		mgr.click(m.select_iphone_colcor);
	}
	
	@Test
	@And("Click on 128GB storage")
	public void Select_storage() throws InterruptedException {
		mgr.click(m.select_storage);
		
	}
	
	@Test
	@And("Click on single Iphone picture")
	public void Select_Iphonepicture() throws InterruptedException {
		mgr.click(m.choose_second_picture);
		
	}
	@Test
	@And("Click on Payment option")
	public void Select_payment_option() throws InterruptedException {
		mgr.click(m.when_ship);
		
	}
	@Test
	@And("Click on Add protection plan")
	public void Select_protectionplan() throws InterruptedException {
		mgr.click(m.protection_plan);
		
	}
	@Test
	@And("Clik on Trade_In")
	public void Select_Trade_In() throws InterruptedException {
		mgr.click(m.Add_TradeIn);
		
	}
	
	@Test
	@And("Click on AT&T option from Carrier")
	public void Click_on_ATT() throws InterruptedException {
		mgr.click(m.select_ATT);
	}
	@Test
	@And("Click on Apple from Make")
	public void Click_on_Apple_from_Make() throws InterruptedException {
		mgr.click(m.select_apple);
		
	}
	@Test
	@And("Search for Model in Model Tab")
	public void Search_for_Model_in_Model_Tab() throws InterruptedException {
		mgr.click(m.inputfield);
		mgr.click(m.select_fromdropdown);
		
	}
	@Test
	@And("Click on 64GB storage")
	public void Click_on_64GB_storage() throws InterruptedException {
		mgr.click(m.storage);
		
	}
	
	@Test
	@Then("Verify that the {string} button should be enabled")
	public void Verify_Continue_Button_enability(String text) throws InterruptedException {
		Thread.sleep(4000);
		UIManager.assertTrue(m.click_continue.isEnabled(),"Verify Continue Button is enabled or not");
	    
	}
	@Test
	@And("User Click on Continue Button")
	public void Click_on_continue_button() throws InterruptedException {
		mgr.click(m.click_continue);
		
	}
	
	@Test
	@Then("Verify that the system must demand IMEI number from user")
	public void Verify_IMEI_number() {
		UIManager.assertTrue(m.imei_Number.isDisplayed(),"Verify IMEI number is diplayed");
	    
	}
	@Test
	@And("User enter IMEI number {string} in field")
	public void Enter_IMEI(String text) throws InterruptedException {
		mgr.fillTextField(m.imei_Number, text);
	}
	
	@Test
	@Then("Verify that the system must Open device condition page")
	public void Verify_mobile_conditionpage() throws InterruptedException {
		Thread.sleep(4000);
		UIManager.assertTrue(m.click_yes.isDisplayed(),"Verify Mobile condition page will open or not");
	    
	}
	
	@Test
	@And("User put all information about physical condition of Mobile")
	public void Enter_Mobile_condition_details() throws InterruptedException {
		mgr.click(m.click_yes);
		mgr.click(m.second_yes);
		mgr.click(m.third_yes);
		mgr.click(m.fourth_yes);
	}
	
	@Test
	@And("Scroll down to Continue Button and click on it")
	public void Scroll_To_Click() throws InterruptedException {
		mgr.waitUntilVisible(m.show_less);
		mgr.scroll(m.press_continue, false);
		mgr.waitUntilVisible(m.press_continue);
		mgr.click(m.press_continue);
	}
	
	@Test
	@And("Click on Noshop Internet Button")
	public void Click_Noshop_Internet_Button() throws InterruptedException {
		mgr.click(m.shop_internet);
		
	}

}
