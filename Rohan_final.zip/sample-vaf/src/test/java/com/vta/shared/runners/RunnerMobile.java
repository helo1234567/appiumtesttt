package com.vta.shared.runners;

import com.charter.BaseRunner;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		tags="@Spectrum_ToolBox_HomePages",
		features="src/test/resources/Features/UI/Mobile",
		glue={"com.vta.ui.steps.mobile",},
		monochrome=true,
		plugin = {"json:target/cucumber.json"})
public class RunnerMobile {



}
