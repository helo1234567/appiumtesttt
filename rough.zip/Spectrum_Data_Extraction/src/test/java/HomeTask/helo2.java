package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class helo2 {

    public static void main(String[] args) {
        // ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Excel file path
        String excelFilePath = "D:\\exce\\asad.xlsx";

        // Sheet name where URLs are present
        String sheetName = "Sheet1";

        // Column index where URLs are present (0-based)
        int urlColumn = 0;

        // Column index where image names should be collected
        int nameColumn = 3;

        // Column index where image src attributes should be collected
        int srcColumn = 2;

        // Create ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            FileInputStream fis = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            // Iterate over the URLs
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next(); // Skip header row

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Cell urlCell = row.getCell(urlColumn);
                String url = urlCell.getStringCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(7000);

                // Scroll to the bottom of the page
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollTo(0, document.body.scrollHeight)");

                // Collect image src attributes
                List<WebElement> images = driver.findElements(By.xpath("//img[@class='col-lg-3 image compatible-product']"));
                List<String> Attributes = new ArrayList<>();
                for (WebElement image : images) {
                    String src = image.getAttribute("src");
                    Attributes.add(src);
                }

                // Update the corresponding columns with src attributes
                int currentRow = row.getRowNum();
                for (int i = 0; i < Attributes.size(); i++) {
                    String src = Attributes.get(i);
                    Row currentRowToUpdate = sheet.getRow(currentRow + i);
                    if (currentRowToUpdate == null) {
                        currentRowToUpdate = sheet.createRow(currentRow + i);
                    }
                    Cell srcCell = currentRowToUpdate.createCell(srcColumn, CellType.STRING);
                    srcCell.setCellValue(src);
                }
            }

            // Save the updated workbook
            FileOutputStream fos = new FileOutputStream(excelFilePath);
            workbook.write(fos);
            fos.close();

            System.out.println("Data fetched and updated successfully!");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Quit the driver
            driver.quit();
        }
    }
}
