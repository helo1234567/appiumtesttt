package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class Final_Rohan {

    public static void main(String[] args) throws IOException, InterruptedException {
        // ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Excel file path
        String excelFilePath = "C:\\Users\\DELL\\Downloads\\asaddataextraction\\roug.xlsx";

        // Sheet name where URLs are present
        String sheetName = "Sheet1";

        // Column index where URLs are present (0-based)
        int urlColumn = 0;

        // Create ChromeDriver
        WebDriver driver = new ChromeDriver();
        List<String> names = new ArrayList<>();
        List<String> srcAttributes = new ArrayList<>();

        FileInputStream fis = new FileInputStream(excelFilePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        // Iterate over the URLs
        Iterator<Row> rowIterator = sheet.iterator();
        rowIterator.next(); // Skip header row

        // Create a new sheet to store names and src attributes
        Sheet newSheet = workbook.createSheet("Names and Src");

        int rowIndex = 0; // Start from the first row in the new sheet

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Cell urlCell = row.getCell(urlColumn);

            if (urlCell != null) { // Check if the cell is not null
                String url = urlCell.getStringCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(7000);

                // Find all the visible images on the page
                List<WebElement> images = driver.findElements(By.xpath("//div[@class='col-lg-3 image compatible-product']"));
                List<WebElement> accessoryNames = driver.findElements(By.xpath("//h2[@class='small name']"));

                // Collect image names and src attributes

                for (WebElement image : images) {
                    String src = image.getAttribute("src");
                    srcAttributes.add(src);
                }
                for (WebElement accessory : accessoryNames) {
                    String name = accessory.getText();
                    names.add(name);
                }
            }
        }

        if (!names.isEmpty() && !srcAttributes.isEmpty()) {
            for (int i = 0; i < names.size(); i++) {
                newSheet.createRow(i).createCell(0).setCellValue(names.get(i));
                newSheet.getRow(i).createCell(1).setCellValue(srcAttributes.get(i));
            }
        }

        // Save the updated workbook
        FileOutputStream fos = new FileOutputStream(excelFilePath);
        workbook.write(fos);
        fos.close();

        System.out.println("Data fetched and updated successfully!");
    }
}
