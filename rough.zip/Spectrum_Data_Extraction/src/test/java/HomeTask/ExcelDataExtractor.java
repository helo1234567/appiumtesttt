package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class ExcelDataExtractor {

    public static void main(String[] args) {
        // Set the path to ChromeDriver
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Set Chrome options


        // Create a new instance of ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Excel file path
        String excelFilePath = "D:\\exce\\helo.xlsx";

        // Excel column indexes
        int urlColumn = 0; // First column (URL column)
        int srcColumn = 1; // Second column (src column)

        try {
            // Load the Excel file
            FileInputStream fis = new FileInputStream(new File(excelFilePath));
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0); // Assuming the data is in the first sheet

            // Get the iterator for the rows in the Excel sheet
            Iterator<Row> rowIterator = sheet.iterator();

            // Skip the header row
            if (rowIterator.hasNext()) {
                rowIterator.next();
            }

            // Create an ArrayList to store the src links
            ArrayList<String> srcList = new ArrayList<>();

            // Loop through each row in the Excel sheet
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Cell urlCell = row.getCell(urlColumn);
                String url = urlCell.getStringCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(10000);

                // Find elements based on the generic XPath provided
                List<WebElement> elements = driver.findElements(By.xpath("//img[@class='col-lg-3 image compatible-product']"));

                // Extract src links from the found elements and add them to the srcList
                for (WebElement element : elements) {
                    String src = element.getAttribute("src");
                    srcList.add(src);
                }
            }

            // Loop through the srcList and put the data in the second column of the Excel sheet
            int srcListSize = srcList.size();
            int rowIndex = 1; // Start from the second row (index 1)
            for (String src : srcList) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) {
                    row = sheet.createRow(rowIndex);
                }
                Cell srcCell = row.createCell(srcColumn);
                srcCell.setCellValue(src);
                rowIndex++;
            }

            // Save the changes to the Excel file
            FileOutputStream fos = new FileOutputStream(new File(excelFilePath));
            workbook.write(fos);
            fos.close();

            // Close the browser
            driver.quit();

            System.out.println("Data extraction and Excel update complete.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
