package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class asad {
    public static void main(String[] args) throws IOException {
        // ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Excel file path
        String excelFilePath = "D:\\exce\\All.xlsx";

        // Sheet name where URLs are present
        String sheetName = "Sheet1";

        // Column index where URLs are present (0-based)
        int urlColumn = 0;

        // Create ChromeDriver
        WebDriver driver = new ChromeDriver();
        List<String> names = new ArrayList<>();
        List<String> srcAttributes = new ArrayList<>();

        try {
            FileInputStream fis = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            // Iterate over the URLs
            for (Row row : sheet) {
                Cell urlCell = row.getCell(urlColumn);
                String url = urlCell.getStringCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(10000);
//                WebElement rightArrow = driver.findElement(By.xpath("//*[@id=\"page-e41f866d9a\"]/div[1]/div/div[3]/div/div[8]/compatible-products/section/div/div/a[2]/span[1]"));
//
//                boolean scrollIntoView=false;
//                JavascriptExecutor js = (JavascriptExecutor) driver;
//                js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")",rightArrow );

                // Find elements and extract data
                List<WebElement> elements = driver.findElements(By.xpath("//img[@class='img-carousel']"));
                List<WebElement> accessoryNames = driver.findElements(By.xpath("//h2[@class='small name']"));
                for(WebElement e:elements) {
                    String namess=e.getAttribute("src");
                    names.add(namess);


                }
            }

            // Create a new workbook to store the extracted data
            Workbook extractedDataWorkbook = new XSSFWorkbook();
            Sheet extractedDataSheet = extractedDataWorkbook.createSheet("Extracted Data");

            // Write the extracted data to the new workbook
            for (int i = 0; i < names.size(); i++) {
                Row row = extractedDataSheet.createRow(i);
                Cell nameCell = row.createCell(0);
                Cell srcCell = row.createCell(1);
                nameCell.setCellValue(names.get(i));
                //srcCell.setCellValue(srcAttributes.get(i));
            }

            // Save the extracted data workbook
            FileOutputStream fos = new FileOutputStream("C:\\Users\\DELL\\Downloads\\asaddataextraction\\extracted_data.xlsx");
            extractedDataWorkbook.write(fos);
            fos.close();

            System.out.println("Data extracted and saved successfully!");

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            // Quit the driver
            driver.quit();
        }
    }
}
