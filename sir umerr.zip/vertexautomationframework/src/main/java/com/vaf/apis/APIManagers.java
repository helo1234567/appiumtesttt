package com.vaf.apis;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import java.io.IOException;

import static io.restassured.RestAssured.given;

public class APIManagers {


public Response PostRequest(String key1, String key2, String key3, String key4) throws IOException {
    RestAssured.baseURI = "https://rahulshettyacademy.com";
//    JSONObject headerJson = new JSONObject(key3);
//    Map<String, String> headers = new HashMap<>();
//
//    // Extract key-value pairs from the JSON object and store them in the HashMap
//    Iterator<String> keys = headerJson.keys();
//    while (keys.hasNext()) {
//        String key = keys.next();
//        String value = headerJson.getString(key);
//        headers.put(key, value);
//    }
    Response response = given().queryParam(key2)
            .header("Content-Type", "application/json")
            .body(key1)
            .when()
            .post(key4)
            .then()
            .log().all()
            .assertThat()
            .statusCode(200)
            .extract()
            .response();

    return response;
}
    public Response GetRequest(String key1, String key2, String key3, String key4) {
        RestAssured.baseURI = "https://rahulshettyacademy.com";

        Response response = given()
                .queryParam(key2,key1)
                .queryParam("key",key3)
                .when()
                .get(key4)
                .then()
                .log().all()
                .assertThat()
                .statusCode(200)
                .extract()
                .response();

        return response;
    }
//    public Response PutRequest(String key1, String key2, String key3, String key4) {
//        RestAssured.baseURI = "https://rahulshettyacademy.com";
//        Response response = given().
//                queryParam("key", "qaclick123").
//                header("Content-Type", "application/json")
//                .body("{\r\n"
//                        + "\"place_id\":\"" + placeid + "\",\r\n"
//                        + "\"address\":\"" + newadreess + "\",\r\n"
//                        + "\"key\":\"qaclick123\"\r\n"
//                        + "}")
//                .when()
//                .put("/maps/api/place/update/json")
//                .then().log().all().assertThat().statusCode(200)
//                .extract()
//                .response()
//                .asString();
//        return response;
//    }
	
}
