package com.charter.stepDefs;

import static org.junit.Assert.assertEquals;

import java.time.Duration;
import java.util.List;
import java.util.Map;

import com.charter.utils.ExcelUtil;
import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import com.charter.enumerations.BrowserType;
import com.charter.utils.ExcelXSSFUtility;
import com.charter.web.*;
import com.charter.web.UIManager.LocatorType;

public class BuyFlow {

	UIManager mgr = new UIManager(BrowserType.FF32);
	//String filePath = "src/main/resources/locators_datashee.xls";
	//String packagesLocator = "//a[@title='Packages' and @href='/packages' and @class='cmp-navigation__item-link' and @role='button']";
	//String headingLocator = "//h2[@class='sp-h1 mb-md-5']";





	@Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) {

		mgr.startSession(url);
	}

	@Test
	@When("Maximize the window")
	public void Maximize_window() {

		mgr.maximizeBrowser();
	}

	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_Title(String Page_Title) {

		String actual_Title = mgr.getTitle();
		UIManager.assertEqual(actual_Title, Page_Title, "Verify Title is matched or not");
	}

	@Test
	@Then("Close the Browser")
	public void Close_Browser() {

		mgr.endSession();
	}

	@Test
	@And("User Hover over on {string}")
	public void Hover_Over(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.hover(value, type);
	}

	@Test
	@Then("Verify that User will see {string} after Hover over")
	public void verify_dropdown_value(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isDisplayed(value, type);
	}

	@And("User Hover over on {string} and Click on {string}")
	public void Hover_and_click(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.hoverAndClick(value, value1, type);
	}

	@Test
	@Then("Verify that the URL of page should be {string}")
	public void Verify_URL(String Current_URL) {

		String actual_URL = mgr.getURL();
		UIManager.assertEqual(actual_URL, Current_URL, "Verify that URL is matched or not");
	}

	@Test
	@And("User Click on {string}")
	public void Click(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.click(value, type);
	}

	@Test
	@And("Scroll to {string}")
	public void Scroll_to_dropdown(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.scroll(value);

	}

	@Test
	@And("Select {string} from {string}")
	public void select_dropdown(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.selectDropdownOption(value1, value, type);

	}


	@Test
	@Then("User Scroll to {string} and Click on {string}")
	public void Scroll_and_click(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.scroll_and_Click(value, value1, type);

	}

	@Test
	@And("wait for {string}")
	public void Wait_For_Specific_condition(String key) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.waitUntilVisible(value, type);

	}

	@Test
	@Then("Verify that the {string} button should be enabled")
	public void Verify_Button_Enability(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isEnabled(value, type);

	}

	@Test
	@Then("Verify that {string} is selected successfully from {string}")
	public void verify_dropdown_selection(String key1, String key2) {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key1);
		Map<String, Object> locatorMap1 = ExcelUtil.getLocatorFor(key2);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		String value1 = (String) locatorMap1.get("value");
		LocatorType type1 = (LocatorType) locatorMap1.get("type");
		mgr.assertTrue_isDisplayed(value, type);

	}

	@Test
	@Then("Verify that user will see {string} on next page")
	public void Verify_Nextpage_ocator(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isDisplayed(value, type);

	}

	@Test
	@Then("Verify that user will see {string}")
	public void verify_nextpage_locator(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isDisplayed(value, type);

	}

	@Test
	@Then("Verify that {string} should be selected already")
	public void verify_isSelected(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertTrue_isSelected(value, type);

	}

	@Test
	@Then("Verify that user will see {string} in next page")
	public void verify_nextpage_locator_comapre_text(String key) throws InterruptedException {
		Map<String, Object> locatorMap = ExcelUtil.getLocatorFor(key);
		String name = (String) locatorMap.get("name");
		String value = (String) locatorMap.get("value");
		LocatorType type = (LocatorType) locatorMap.get("type");
		mgr.assertEqual_compareText(value, name, type);

	}

	@Test
	@Then("User gets all data from {string} and {string}")
	public void User_gets_all_data_from_excel(String usernameKey, String passwordKey) throws InterruptedException {
		List<String> usernames = ExcelUtil.valuesFor(usernameKey);
		List<String> passwords = ExcelUtil.valuesFor(passwordKey);
		for (int i = 0; i < usernames.size(); i++) {
			String username = usernames.get(i);
			String password = passwords.get(i);
			System.out.println(username);
		}
	}
}

//	@Test
//	@Given("I open chrome browser and goto {string}")
//	public void seleniumPOC(String url) {
//		WebDriver driver = openFirefox();
//
//        driver.get(url);
//
//        String title = driver.getTitle();
//        assertEquals("Web form", title);
//
//        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
//
//        WebElement textBox = driver.findElement(By.name("my-text"));
//        WebElement submitButton = driver.findElement(By.cssSelector("button"));
//
//        textBox.sendKeys("Selenium");
//        submitButton.click();
//
//        WebElement message = driver.findElement(By.id("message"));
//        String value = message.getText();
//        assertEquals("Received!", value);
//
//       // adding screenshots to log
//        ExtentReports extent = new ExtentReports();
//        ExtentTest test = extent.createTest("TestName");
//        test.fail("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
//
//        driver.quit();
//
//	}
//
//	public WebDriver openChrome() { return new ChromeDriver(); }
//	public WebDriver openFirefox() { return  new FirefoxDriver(); }
//
//
//
//
//	@Test
//	@Given("I open chrome browser through JAR and goto {string}")
//	public void jarUITestPOC(String url) {
//
////		WebDriver driver = new FirefoxDriver();
////		driver.get("https://www.spectrum.com/");
////		WebElement Hover_Mobile_Tab = driver.findElement(By.xpath("//a[@role='button' and @title='Mobile']"));
////		WebElement Hover_Mobile_Tab = driver.findElement(By.xpath("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']"));
////
////		WebElement click_spectrum_Mobile = driver.findElement(By.xpath("(//a[contains(text(),'Spectrum Mobile')])[1]"));
////
////		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(40));
////		Actions action = new Actions(driver);
////		wait.until(ExpectedConditions.visibilityOf(Hover_Mobile_Tab));
////		action.moveToElement(Hover_Mobile_Tab).build().perform();
//
////		wait.until(ExpectedConditions.visibilityOf(click_spectrum_Mobile));
//
//		UIManager mgr = new UIManager(BrowserType.FF32);
//
//		mgr.startSession("http://www.spectrum.com/");
//		//mgr.hover("//a[@role='button' and @title='Mobile']");
//		mgr.click("(//a[contains(text(),'Spectrum Mobile')])[1]");
//		mgr.waitUntilVisible("//h3[@class='sp-h1']", LocatorType.xpath);
//
//		mgr.endSession();
//
////		UIManager mgr = new UIManager(BrowserType.FF32);
////		mgr.startSession("http://www.spectrum.com/");
////		mgr.hover("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");
////		mgr.click("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");
////
////		mgr.fillTextField("//input[@id='address1-desktop']", "New York");
////		mgr.fillTextField("//input[@id='zip-desktop']", "12312");
////
////		mgr.fillTextField("zip-desktop", Keys.RETURN, LocatorType.cssId);
//
//		//mgr.click("button-get-offer", LocatorType.cssId);
//		//mgr.click("button#button-get-offer", LocatorType.cssSelector);
//		//mgr.click("cmp-button__icon--social-icons__facebook", LocatorType.cssClass);
//
//		//mgr.endSession();
//
//
//		// Working
//
////		WebDriver driver = new FirefoxDriver();
////		driver.get("http://www.spectrum.com");
////		WebElement streetAddressField = driver.findElement(By.cssSelector("input#address1-desktop"));//(By.id("address1-desktop"));
////		streetAddressField.sendKeys("New York");
//
//        // Working
////        driver.get("http://www.spectrum.com");
////        WebElement streetAddressField = driver.findElement(By.id("address1-desktop"));
////        WebElement zipcodeField = driver.findElement(By.id("zip-desktop"));
////        streetAddressField.sendKeys("New York");
////        zipcodeField.sendKeys("12312");
////        zipcodeField.sendKeys(Keys.RETURN);
////        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(50000));
////        System.out.println("VIEW: " + driver.findElement(By.xpath("//h3[@class='localization-error__error-text']")).getText() );
//
//
//		// Working
////		mgr.startSession(url);
////		mgr.click("a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");
//
//
//		// Working
////		mgr.startSession("https://stackoverflow.com/");
////		mgr.click("a[@class='s-topbar--item s-topbar--item__unset s-btn s-btn__filled ws-nowrap js-gps-track']");
////		mgr.endSession();
//	}
//
//	public static void selectFromDropDown(WebElement element , String Visibletext){
//        Select select = new Select(element);
//        select.selectByVisibleText(Visibletext);
//    }
//
//	UIManager mgr = new UIManager(BrowserType.FF32);
//
//	String packagesLocator = "//a[@title='Packages' and @href='/packages' and @class='cmp-navigation__item-link' and @role='button']";
//	String headingLocator  = "//h2[@class='sp-h1 mb-md-5']";
//
//
//	@Given("I open browser and visit {string}")
//	public void i_open_browser_and_visit(String url) {
//		mgr.startSession(url);
//	}
//
//	@Then("I click the {string} link")
//	public void i_click_on_packages_link(String key) {
//		String locator = ExcelXSSFUtility.locatorFor(key);
//		mgr.click(locator);
//	}
//
//	@Then("I wait for the {string} to load")
//	public void i_wait_for_packages_page_to_load(String key) {
//		String locator = ExcelXSSFUtility.locatorFor(key);
//		mgr.waitUntilVisible(locator, LocatorType.xpath);
//	}
//
//	@Then("I take a screenshot of the browser window")
//	public void i_take_screenshot() {
//		mgr.logScreenshot();
//	}
//
//	@Then("I close the browser")
//	public void i_close_the_browser() {
//		mgr.endSession();
//	}
//}
