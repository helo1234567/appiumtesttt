package com.vta.shared.runners;

import com.charter.BaseRunner;
import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		tags="@Spect,@Spectrum_Mobile_Tabss",
		features="src/test/resources/Features/UI/Mob",
		glue={"com.charter.stepDefs"},
		monochrome=true
		)
public class RunnerMobile extends BaseRunner{



}
