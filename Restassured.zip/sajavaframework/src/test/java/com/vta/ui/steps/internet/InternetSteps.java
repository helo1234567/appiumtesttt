package com.vta.ui.steps.internet;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.Internet.InternetModule;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class InternetSteps {
	UIManager mgr = new UIManager(BrowserType.CHROME);
	InternetModule m = new InternetModule(mgr.driver);

	@Test(priority=0)
	@When("I navigate {string}")
	public void I_navigate(String url) {

		mgr.startSession(url);
		mgr.maximizeBrowser();


	}

	@Test(priority=2)
	@And("hover on internet tab")
	public void hover_on_internet_tab() throws InterruptedException {
		Thread.sleep(8000);
		mgr.waitUntilVisible(m.internet_plan_navigation);
    mgr.hover(m.internet_plan_navigation);
	}

	@Test(priority=2)
	@And("click on internet plan tab")
	public void click_on_internet_plan_tab() {
		mgr.click(m.click_internetplan);
	}

	@Test(priority=1)
	@Then("Verify that url of the page must be {string}")
	public void Verify_that_url_of_the_page_must_be(String title) throws IOException {
		//mgr.waitUntilVisible(m.verify_internetplan_page);
		String actual_url=mgr.getURL();
		UIManager.assertEquals(title, actual_url, "Verify title is matched ");
	}

	@Test(priority=1)
	@And("Verify that url of the page must be this {string}")
	public void Verify_that_url_of_the_page_must_be_this(String title) throws IOException {
		mgr.waitUntilVisible(m.verify_internetplan_page);
		String actual_url=mgr.getURL();
		UIManager.assertEquals(title, actual_url, "Verify title is matched ");
	}

	@Test(priority=1)
	@Then("Verify that url of the page must be localizationPage {string}")
	public void Verify_that_url_of_the_page_must_be_localizationPage(String title) throws IOException {
		mgr.waitUntilVisible(m.localizationPage_verify);
		String actual_url=mgr.getURL();
		UIManager.assertEquals(title, actual_url, "Verify title is matched ");
	}

	@Test(priority=1)
	@Then("scroll down page")
	public void scroll_down_page() {
		mgr.waitUntilVisible(m.scrolldown_verify);
//		UIManager.assertTrue(m.Get_300_Mbps_button.isDisplayed(), "verification check");
		mgr.hover(m.checkhover);
		mgr.scroll(m.scrolldown_verify);
	}

	@Test(priority=0)
	@Then("click on Get offer 300Mbps button")
	public void click_on_Get_offer_300Mbps_button() throws InterruptedException {
		Thread.sleep(4000);
		mgr.waitUntilVisible(m.Get_300_Mbps_button);
		mgr.click(m.Get_300_Mbps_button);

	}

	@Test(priority=0)
	@Then("click on Get offer 500Mbps button")
	public void click_on_Get_offer_500Mbps_button() throws InterruptedException {
		Thread.sleep(4000);
		mgr.waitUntilVisible(m.Get_500_Mbps_button);
		mgr.click(m.Get_500_Mbps_button);

	}

	@Test(priority=0)
	@Then("click on Get offer 1Gbps button")
	public void click_on_Get_offer_1Gbps_button() throws InterruptedException {
		Thread.sleep(4000);
		mgr.waitUntilVisible(m.Get_1_Gbps_button);
		mgr.click(m.Get_1_Gbps_button);

	}

	@Test(priority=0)
	@Then("click on eligibility")
	public void click_on() throws InterruptedException {
		mgr.waitUntilVisible(m.espanol_link);
		mgr.scroll(m.eligibility_criteria,false);
		//Thread.sleep(4000);
		//mgr.waitUntilVisible(m.espanol_link);
		//mgr.scroll(m.eligibility_criteria,false);
		//mgr.click(m.eligibility_criteria);
		mgr.click(m.eligibility_criteria);

	}

//	@Then("click on Get offer")
//	public void click_on_get_offer() {
//		mgr.waitUntilVisible(common_methods.Getoffer_button);
//		mgr.click(m.Get_Offer);
//	}

	@When("enter street address in text field")
	public void enter_street_address_in_text_field() throws InterruptedException {
		mgr.waitUntilVisible(m.street_address);
		mgr.fillTextField(m.street_address, "41 Brenton Rd");
	}

	@And("enter Apt number in text field")
	public void enter_Apt_number_in_text_field() throws InterruptedException {
		mgr.waitUntilVisible(m.Apt_Unit);
		mgr.fillTextField(m.Apt_Unit, "");
	}

	@And("enter zipcode in text field")
	public void enter_zipcode_in_text_field() throws InterruptedException {
		mgr.waitUntilVisible(m.zipcodes);
		mgr.fillTextField(m.zipcodes, "76134");
	}

	@And("click on GO")
	public void click_on_go() {
		mgr.click(m.Go_button);
	}
//	@Test(priority=0)
//	@Then("click on Get offer 1Gbps button")
//	public void click_on_Get_offer_1Gbps_button() throws InterruptedException {
//		Thread.sleep(4000);
//		mgr.waitUntilVisible(m.Get_1_Gbps_button);
//		mgr.click(m.Get_1_Gbps_button);
//
//	}

	@Test(priority=0)
	@When("click on espanol link")
	public void click_on_espanol_link() throws IOException {

		mgr.click(m.espanol_link);

	}

//	@Test(priority=1)
//	@Then("Verify that url of the page must be {string}")
//	public void verify_url(String title) throws IOException {
//		String actual_url=mgr.getURL();
//		UIManager.assertEqual(title, actual_url, "Verify title is matched ");
//
//	}

	@Test(priority=1)
	@Then("Close the Browser")
	public void Browser() throws IOException {
		mgr.endSession();

	}

//	@Test(priority=2)
//	@Given("User is on Home page of Spectrum.com")
//	public void Home_Page() throws IOException {
//
//		System.out.print("spectrum.com");
//
//
//	}
//
//	@Test(priority=3)
//	@When("User Hover over on Internet Tab")
//	public void Hover_over() throws IOException {
//
//		System.out.print("spectrum.com");
//		mgr.waitUntilVisible(m.Internet_tab);
//		mgr.hover(m.Internet_tab);
//		mgr.waitUntilVisible(m.click_spectrum_Internet);
//	}
//
//	@Test(priority=4)
//	@Then("Verify that User must see {string} in dropdown")
//	public void verify_From_dropdown(String dropdown_value) throws IOException {
//		String Text=m.click_spectrum_Internet.getText();
//		UIManager.assertEqual(dropdown_value, Text, "Verify dropdown_value is displayed ");
//
//	}
//
//	@Test(priority=3)
//	@When("User Hover over on Internet Tab and click on Spectrum Internet in dropdown")
//	public void click_fromdropdown() throws IOException {
//		mgr.waitUntilVisible(m.Internet_tab);
//		mgr.hover(m.Internet_tab);
//		mgr.waitUntilVisible(m.click_spectrum_Internet);
//		mgr.click(m.click_spectrum_Internet);
//
//	}
//
//	@Test(priority=3)
//	@When("User scroll down to shopultra")
//	public void scroll() throws IOException {
//		JavascriptExecutor js = (JavascriptExecutor) mgr.driver;
//		js.executeScript("arguments[0].scrollIntoView(false)", m.shop_ultra);
//		m.shop_ultra.click();
//		//mgr.scroll(m.shop_ultra);
//
//	}
//
//	@Test(priority=3)
//	@And("Click on Shopultra")
//	public void scrolldown() throws IOException {
//
//		System.out.print("asad");
//
//	}
//
//	@Test(priority=3)
//	@And("Click on GetOffer")
//	public void Click_getoffer() throws IOException {
//		mgr.click(m.Get_Offer);
//
//
//	}
//
//	@Test
//	@And("User enter {string}in address field")
//	public void Enter_Address(String Text) throws IOException, InterruptedException {
//		Thread.sleep(5000);
//		mgr.waitUntilVisible(m.enter_address);
//		mgr.fillTextField(m.enter_address, Text);
//
//	}
//
//	@Test
//	@Then("Verify that Text field must be filled by address")
//	public void Enter_adress() throws IOException {
//		Assert.assertNotNull(m.enter_address);
//
//
//	}
//
//	@Test
//	@And("User enter {string}in Apt unit field")
//	public void Enter_Apt_unit(String Text) throws IOException, InterruptedException {
//		Thread.sleep(5000);
//		mgr.waitUntilVisible(m.app_unit);
//		mgr.fillTextField(m.app_unit, Text);
//
//	}
//
//	@Test
//	@Then("Verify that Text field must be filled by Apt")
//	public void Verify_Field_notNull() throws IOException {
//
//		Assert.assertNotNull(m.app_unit);
//
//
//	}
//
//	@Test
//	@And("User enter {string}in zipcode field")
//	public void Enter_zipcode(String Text) throws IOException, InterruptedException {
//		Thread.sleep(5000);
//		mgr.waitUntilVisible(m.zipcode);
//		mgr.fillTextField(m.zipcode, Text);
//
//	}
//
//	@Test
//	@Then("Verify that Text field must be filled by zipcode")
//	public void Verify_Fields_notNull() throws IOException {
//
//		Assert.assertNotNull(m.zipcode);
//
//
//	}
//
//	@And("click on Find Offers button")
//	public void click_on_Find_Offers_button() throws InterruptedException {
//		Thread.sleep(5000);
//		mgr.waitUntilVisible(m.Find_Offers_button);
//		mgr.click(m.Find_Offers_button);
//	}
//
//	@And("scroll down page")
//	public void scroll_down_page() throws InterruptedException {
//		Thread.sleep(5000);
//		mgr.scroll(m.Find_Offers_button);
//	}
//
//	@And("Verify that out of foot print page")
//	public void Verify_that_out_of_foot_print_page() {
//		UIManager.assertTrue(m.verify_address_page.isDisplayed(), "verification check");
//	}
//
//	@Then("navigate back to previous page")
//	public void navigate_back_to_previous_page() {
//		mgr.navigateTo("https://www.spectrum.com/internet");
//	}
//
//	@And("scroll down home page")
//	public void scroll_down_home_page() {
//		mgr.waitUntilVisible(m.shop_GIG_Button);
//		mgr.scroll(m.shop_GIG_Button, false);
//	}
//
//	@And("click on shop GIG button")
//	public void click_on_shop_GIG_button() {
//		mgr.click(m.shop_GIG_Button);
//	}
//
//	@And("Verify localization page")
//	public void Verify_localization_page() {
//		UIManager.assertTrue(m.verify_localization_page.isDisplayed(), "verfication check");
//	}

}
