package com.charter.api;

import static io.restassured.RestAssured.given;

import java.net.URISyntaxException;

import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;

import com.charter.utils.ConfigUtil;

import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

// Test 2
public class APIManager {
	// Abstraction for RestAssured given() method 
	// Returns RequestSpecification type object which can be used to further customise the API request
	public static RequestSpecification execute() { return given(); }
	
	// Assertion to check if the response returned from server was OK (Status code: 200)
	public static void verifyResponseOK(Response response) { 
		response.then().assertThat().statusCode(HttpStatus.SC_OK);
	}
	
	// Asserts that the response contains a key
	public static void verifyHasKey(Response response, String key) {
		response.then().body("$", Matchers.hasKey(key));
	}
	//Validate if key has given value
	public static <T> void keyHasValue(Response response, String key, T value) {
		response.then().body(key, Is.is(value));
	}
	
	
}
