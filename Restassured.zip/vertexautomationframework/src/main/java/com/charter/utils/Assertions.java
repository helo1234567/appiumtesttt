//package com.charter.utils;
//
//import com.charter.web.UIManager;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.WebDriver;
//import org.testng.Assert;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//
//public class Assertions {
//    private static final Logger LOGGER = LoggerFactory.getLogger(Assertions.class);
//    public static WebDriver driver;
//    public static void logScreenshot() {
//        String screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BASE64);
//        LogUtil.logBase64(screenshot, "Attached Screenshot");
//    }
//
//    public static void assertEquals(boolean original, boolean expected, String message) throws AssertionError {
//        try{
//        Assert.assertEquals(original, expected, message);
//        }catch (AssertionError error){
//            String errorMessage = "Assertion error occurred: " + message;
//            LOGGER.error(errorMessage,error);
//            LogUtil.logInfo(error.getMessage());
//            logScreenshot();
//            throw error;
//        }
//    }
//    public static void assertEquals(int original, int expected) {
//        Assert.assertEquals(original,expected);
//    }
//    public static void assertEquals(double original, double expected, double delta) throws AssertionError {
//        Assert.assertEquals(original,expected,delta);
//    }
//    public static void assertEquals(Object original,Object expected){
//        Assert.assertEquals(original,expected);
//    }
//    public static void assertTrue(boolean condition, String message) throws AssertionError {
//        Assert.assertTrue(condition, message);
//    }
//    public static void assertTrue(boolean condition){
//        Assert.assertTrue(condition);
//    }
//    public static void assertFalse(boolean condition, String message) throws AssertionError {
//        Assert.assertFalse(condition, message);
//    }
//    public static void assertFalse(boolean condition){
//        Assert.assertFalse(condition);
//    }
//    public static void assertNull(Object object){
//        Assert.assertNull(object);
//    }
//    public static void assertNull(Object object, String message) throws AssertionError {
//        Assert.assertNull(object,message);
//    }
//    public static void assertNotNull(Object object){
//        Assert.assertNotNull(object);
//    }
//    public static void assertNotNull(Object object, String message) throws AssertionError {
//        Assert.assertNotNull(object,message);
//    }
//    public static void assertSame(Object original,Object expected){
//        Assert.assertSame(original,expected);
//    }
//    public static void assertSame(Object original,Object expected,String message) throws AssertionError {
//        Assert.assertSame(original,expected,message);
//    }
//    public static void assertNotSame(Object original,Object unexpected){
//        Assert.assertNotSame(original,unexpected);
//    }
//    public static void assertNotSame(Object original,Object unexpected,String message) throws AssertionError {
//        Assert.assertNotSame(original,unexpected,message);
//    }
//    public static void fail(){
//        Assert.fail();
//    }
//    public static void fail(String message) throws AssertionError {
//        Assert.fail(message);
//    }
//}
