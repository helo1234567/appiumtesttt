package com.spec.runners;



import org.junit.Before;
import org.junit.runner.RunWith;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;

//@RunWith(Cucumber.class)
@CucumberOptions(
		tags = { "@Spectrumss" },
		features = { "src/test/resources/features/ui" },
		glue = { "classpath:com.charter.steps" })


public class RunSpectrumUIAll extends AbstractTestNGCucumberTests {
	private static WebDriver driver;
	@Parameters("browserType")
	@Before
	public void setUp(String browser) {
		//String browser = System.getProperty("browser");

		if (browser != null && browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\DELL\\Downloads\\geckodriver-v0.33.0-win32\\geckodriver.exe");
			driver = new FirefoxDriver();
		} else {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
		}
	}

	public static WebDriver getDriver() {
		return driver;
	}

}

