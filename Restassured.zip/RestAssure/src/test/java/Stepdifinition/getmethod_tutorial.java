package Stepdifinition;

import io.cucumber.core.internal.com.fasterxml.jackson.annotation.JacksonInject.Value;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.http.ContentType;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;
import static io.restassured.RestAssured.*;

import org.checkerframework.checker.units.qual.s; 

public class getmethod_tutorial {
	@Given("I perform GET operation for {string}")
	public void i_perform_get_operation_for(String url) {
	 given().contentType(ContentType.JSON);
	}

	@And("I perform GET for the post number {string}")
	public void i_perform_get_for_the_post_number(String postnumber) {
		when().get(String.format("http//:localhost:3000/posts/%s",postnumber)).
		then().body("author", hasItem("Karthik KK"));
		
		
	}

	@Then("I should see the author name as {string}")
	public void i_should_see_the_author_name_as(String string) {
	    
	}

}
