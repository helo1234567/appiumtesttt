package R_Tests;

import io.restassured.path.json.JsonPath;

public class Reusable {
	public static JsonPath rawJason(String response) {
		JsonPath js1=new JsonPath(response);
		return js1;
	}

}
