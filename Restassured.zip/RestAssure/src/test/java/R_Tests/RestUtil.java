package R_Tests;

import org.apache.commons.lang3.RandomStringUtils;

public class RestUtil {
	
	public static String getFirstName() {
		String generatedString =RandomStringUtils.randomAlphabetic(1);
		return ("john"+generatedString);
	}
	
	
	public static String empname() {
		String generatedString =RandomStringUtils.randomAlphabetic(2);
		return ("john"+generatedString);
	}
	
	public static String empsal() {
		String generatedString =RandomStringUtils.randomNumeric(3);
		return (generatedString);
	}
	public static String empage() {
		String generatedString =RandomStringUtils.randomNumeric(4);
		return (generatedString);
	}
}
