package R_Tests;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.cucumber.java.Before;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;
public class Udemy {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		RestAssured.baseURI="https://rahulshettyacademy.com";
	String response=given().log().all().queryParam("key", "=qaclick123").header("Content-Type","application/json").body(payload.AddPlace()).when().post("/maps/api/place/add/json").then().log().all().assertThat().statusCode(200)
			.body("scope",equalTo("APP")).header("server","Apache/2.4.41 (Ubuntu)").extract().response().asString(); 

//	System.out.println("asadrazamahmooddd");
	System.out.println(response);
//	
	JsonPath js=new JsonPath(response);
	String placeid=js.getString("place_id");
	System.out.println(placeid);
	String newadreess="Summer walk,Africa";
	
	String response2=given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json").body("{\r\n"
			+ "\"place_id\":\""+placeid+"\",\r\n"
			+ "\"address\":\""+newadreess+"\",\r\n"
			+ "\"key\":\"qaclick123\"\r\n"
			+ "}").when().put("/maps/api/place/update/json").then().log().all().assertThat().statusCode(200).body("msg",equalTo("Address successfully updated"))
			.extract().response().asString();
	//System.out.println(response2);
	
	
	String response5=given().log().all().queryParam("key", "qaclick123").queryParam("place_id", placeid).when().get("/maps/api/place/get/json").then().log().all().assertThat().statusCode(200).body("address",equalTo("Summer walk,Africa")).extract().response().asString();
	System.out.println(response5);
	
	//JsonPath js1=new JsonPath(response5);
	JsonPath js1 =Reusable.rawJason(response5);
	String actualadress =js1.getString("address");
	System.out.println(actualadress);

	}

}
