package R_Tests;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

public class Test_examples {
	
//	@Test
//	public void test1() {
//		Response response=get("https://reqres.in/api/users?page=2");
//		int res=response.getStatusCode();
//		//response.getTime();
//		System.out.println(response.getStatusCode());
//		System.out.println(response.getTime());
//		System.out.println(response.getBody().asString());
//		System.out.println(response.statusLine());
//		System.out.print(response.getHeader("content type"));
//		
//		Assert.assertEquals(res, 200);
//	
//	}
//	@Test
//	public void test2() {
//		baseURI="https://reqres.in/api";
//		//given().get("/users?page=2").then().statusCode(200).body("data.id[1]", equals(5));
//		given().get("/users?page=2").then().body("data[1].id", equalTo(8)).log().all();
//	}
	
//	@Test
//	public void test3() {
//		baseURI="https://reqres.in/api";
//		//given().get("/users?page=2").then().statusCode(200).body("data.id[1]", equals(5));
//		given().get("/users?page=2").then().body("data[1].id", equalTo(8)).
//		body("data.first_name", hasItems("George","Rachel"));
//	} 
	
	@Test
	public void test4() {

Map<String ,Object>map=new HashMap<String,Object>();
//
//map.put("name","asada" );
//map.put("job", "teacer");
//System.out.println(map);
JSONObject request=new JSONObject(map);
request.put("name","asada");
request.put("job","teacger");
System.out.println(request.toJSONString());
baseURI="https://reqres.in/api";
given().header("Content-Type","application/son").contentType(ContentType.JSON).accept(ContentType.JSON)
.body(request.toJSONString()).when().
post("/users").then().statusCode(201).log().all();


	}

}
