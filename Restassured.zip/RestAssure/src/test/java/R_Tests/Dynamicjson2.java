package R_Tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class Dynamicjson2 {
	
	
//	public void addbook(String isbn,String aisle) {
//		RestAssured.baseURI="http://216.10.245.166";
//		String response1=given().log().all().header("Content-Type","application/json").body(payload.addbook(isbn,aisle)).when().post("/Library/Addbook.php").then().log().all().assertThat().statusCode(200).extract().response().asString();
//		JsonPath js =Reusable.rawJason(response1);
//		String id=js.getString("ID");
//		System.out.println(id);
//		}
	
	@Test
	public void addBook() throws IOException
	{
		dataDriven d=new dataDriven();
		ArrayList data=d.getData("RestAddbook");
		
		
		HashMap<String, Object>  map = new HashMap<String, Object>();
		map.put("name", data.get(1));
		map.put("isbn", data.get(2));
		map.put("aisle", data.get(3));
		map.put("author", data.get(4));
		
	/*	HashMap<String, Object>  map2 = new HashMap<>();
		map.put("lat", "12");
		map.put("lng", "34");
		map.put("location", map2);*/
		
		
		RestAssured.baseURI="http://216.10.245.166";
		String resp=given().log().all().header("Content-Type","application/json").body(map).when().post("/Library/Addbook.php").then().log().all().assertThat().statusCode(200).extract().response().asString();
		
		 JsonPath js= Reusable.rawJason(resp);
		   String id=js.get("ID");
		   System.out.println(id);
		
		
	
		
		
		
	// Create a place =response (place id)
		
		// delete Place = (Request - Place id)	
		

	}
	
	
}
