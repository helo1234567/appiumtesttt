package R_Tests;

import io.restassured.path.json.JsonPath;

public class complexjson {

	public static void main(String[] args) {
		JsonPath js1=new JsonPath(payload.Courseprice());
	}

}
