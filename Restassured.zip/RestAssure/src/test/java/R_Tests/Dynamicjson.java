package R_Tests;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Dynamicjson {
	
	@Test(dataProvider="booksdata")
	public void addbook(String isbn,String aisle) {
		RestAssured.baseURI="http://216.10.245.166";
		String response1=given().log().all().header("Content-Type","application/json").body(payload.addbook(isbn,aisle)).when().post("/Library/Addbook.php").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js =Reusable.rawJason(response1);
		String id=js.getString("ID");
		System.out.println(id);
	}
	@DataProvider(name="booksdata")
	public Object[][] getdata() {
		return new Object[][] {{"avagssb","6565467"},{"arsrstsf","455625"},{"assesrafs","4521898"}};
	}

}
