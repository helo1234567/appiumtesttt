package R_Tests;
import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.cucumber.java.Before;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;
import org.asynchttpclient.netty.ssl.JsseSslEngineFactory;

import io.restassured.path.json.JsonPath;

public class Udemy_Depth {
	public static void main(String[] args) {
		JsonPath jss=new JsonPath(payload.Courseprice());
		int count=jss.getInt("courses.size()");
		System.out.println(count);
		int totalamount=jss.getInt("dashboard.purchaseAmount");
		System.out.println(totalamount);
		String title=jss.get("courses[0].title");
		System.out.println(title);
		
		for(int i=0;i<count;i++) {
			String title1=jss.get("courses["+i+"].title");
			String price=jss.get("courses["+i+"].price").toString();
			System.out.println(title1);
			System.out.println(price);
			
		}
		for(int i=0;i<count;i++) {
			String coursetitle=jss.get("courses["+i+"].title");
			if(coursetitle.equalsIgnoreCase("RPA")) {
				Integer copies=jss.get("courses["+i+"].copies");
				System.out.println(copies);
				
			}
		}
		
	}
	
	
	
}
