package R_Tests;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.cucumber.java.Before;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

public class SDET_Restassured {
	
	
	
	
	
	
	
	
	
	
	
//	public static HashMap map=new HashMap();
//	int emp_id=1;
////@Test
////	public void weather() {
////	RestAssured.baseURI="http://restapi.demoqa.com/utilities/weather/city/Hyderabad";
////	given()
////	.when()
////	.get("http://restapi.demoqa.com/utilities/weather/city/Hyderabad").
////	then().statusCode(200).statusLine("HTTP/1.1 200 OK").
////	assertThat().body("City", equalTo("Hyderabad")).
////	header("content-Type","appliccation/json");
//// 		
////	}
//	@BeforeClass
//	public void weather() {
//		map.put("name", RestUtil.empname());
//		map.put("salary", RestUtil.empsal());
//		map.put("age", RestUtil.getFirstName());
//		RestAssured.baseURI="http://dummy.restapiexample.com/api/v1";
//		RestAssured.basePath="/update/"+emp_id;
//	}
//	@Test
//	public void testPUt() {
//		Response response=
//		given().contentType("application/json").
//		body(map).
//		when().
//		put().
//		then().statusCode(301).extract().response();
//		String jsonAsString=response.asString();
//		Assert.assertEquals(jsonAsString.contains("deleted records"),true);
//	}
	
	
}
