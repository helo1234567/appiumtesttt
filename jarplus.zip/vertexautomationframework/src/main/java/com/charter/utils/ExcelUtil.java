package com.charter.utils;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.HashMap;
import java.util.Map;
import java.io.File;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;
import com.charter.web.UIManager.LocatorType;
public class ExcelUtil {

    private static String LOCATOR_FILE_PATH = "locators_datasheet.xlsx";

    public static Map<String, Object> getLocatorFor(String compoundKey) {
        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];

        try {
            File file;
            try {
                file = getFileFromURL(LOCATOR_FILE_PATH);
            } catch (Exception e) {
                System.out.println("File not found: " + e.getMessage());
                return null;
            }

            FileInputStream fis = new FileInputStream(file);
            Workbook wb;
            if (LOCATOR_FILE_PATH.toLowerCase().endsWith(".xlsx")) {
                wb = new XSSFWorkbook(fis);
            } else {
                wb = new HSSFWorkbook(fis);
            }
            Sheet sheet = wb.getSheet(sheetName);

            Iterator<Row> itr = sheet.iterator();

            while (itr.hasNext()) {
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();

                String locatorName = "";
                String locatorValue = "";
                LocatorType locatorType = null;

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (cell.getColumnIndex() == 0) {
                        locatorName = cell.getStringCellValue();
                    } else if (cell.getColumnIndex() == 1) {
                        locatorValue = cell.getStringCellValue();
                    } else if (cell.getColumnIndex() == 2) {
                        String type = cell.getStringCellValue().toLowerCase();
                        if ("xpath".equals(type)) {
                            locatorType = LocatorType.xpath;
                        } else if ("cssselector".equals(type)) {
                            locatorType = LocatorType.cssSelector;
                        } else if ("cssid".equals(type)) {
                            locatorType = LocatorType.cssId;
                        } else if ("cssclass".equals(type)) {
                            locatorType = LocatorType.cssClass;
                        } else {
                            throw new IllegalArgumentException("Invalid locator type: " + type);
                        }
                    }
                }

                if (locatorName.equals(key)) {
                    Map<String, Object> locatorMap = new HashMap<String, Object>();
                    locatorMap.put("value", locatorValue);
                    locatorMap.put("type", locatorType);
                    return locatorMap;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static File getFileFromURL(String filePath) throws URISyntaxException {
        URL url = new ExcelUtil().getClass().getClassLoader().getResource(filePath);
        File file = null;
        file = new File(url.toURI());
        return file;
    }
}

