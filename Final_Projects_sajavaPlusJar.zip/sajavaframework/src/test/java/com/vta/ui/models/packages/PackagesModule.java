package com.vta.ui.models.packages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PackagesModule {
WebDriver driver;
	
	public PackagesModule(WebDriver d) {
		driver=d;
		PageFactory.initElements(d, this);
	}
	
	@FindBy(xpath="(//a[@href='/packages'])[1]")
	public
	WebElement packages_tab;

	@FindBy(xpath="(//a[contains(text(),' Shop Packages ')])[1]")
	public
	WebElement packages_dropdown;

	@FindBy(xpath="(//a[contains(text(),' Shop Packages ')])[1]")
	public
	WebElement dropdown_shop_packages;

	@FindBy(xpath="(//input[@placeholder='Street Address'])[1]")
	public
	WebElement verify_shoppackages_page;

	@FindBy(xpath="//input[@class='sp-radio' and @type='radio' and @value='300 Mbps for $49.99/mo']")
	public WebElement choose_internet_speed_300Mbps;
	
	@FindBy(id="button-get-offer")
	public
	WebElement Getoffer_button;
	
//	@FindBy(xpath="(//input[@placeholder='Street Address'])[1]")
//	public
//	WebElement street_address;

//	@FindBy(xpath="//input[@class='ng-pristine ng-valid ng-touched' and @type='text' and @placeholder='Street Address']")
//	public
//	WebElement street_address;
	@FindBy(xpath="/html/body/app-root/div/app-bf-nav-header/header[1]/div[3]/app-bf-service-address/div/form/div/div[2]/div/app-bf-input-autocomplete/div/ng-autocomplete/div/div[1]/input")
	public
	WebElement street_address;
	@FindBy(id="address1-standalone")
	public
	WebElement street_address2;
	
	@FindBy(xpath="/html/body/app-root/div/app-bf-nav-header/header[1]/div[3]/app-bf-service-address/div/form/div/div[3]/div/app-bf-input-autocomplete/div/ng-autocomplete/div/div[1]/input")
	public
	WebElement Apt_Unit;

	@FindBy(id="apt-standalone")
	public
	WebElement Apt_Unit2;
	
	@FindBy(xpath="//*[@id=\"kite-label-input-0\"]")
	public
	WebElement zipcode;
	@FindBy(id="zip-standalone")
	public
	WebElement zipcode2;
	
	@FindBy(xpath="/html/body/app-root/div/app-bf-nav-header/header[1]/div[3]/app-bf-service-address/div/form/div/div[5]/div/kite-button/button/span")
	public
	WebElement Go_button;
	
	@FindBy(xpath="//button[@class='sp-localization-submit' and @data-linktype='cta_button' and @data-linkname='packages-test-localization_GO']")
	public WebElement Go2_button;
	
	@FindBy(id="radioGrp-packages-1")
	public
	WebElement choose_internet_speed_500Mbps;
	
	@FindBy(id="radioGrp-packages-2")
	public
	WebElement choose_internet_speed_1Gbps;
	
	@FindBy(id="SpectrumLogo")
	public
	WebElement out_of_footprint;

	@FindBy(xpath="(//span[@class='kite-button__inner'])[2]")
	public
	WebElement internetAssistButton;

	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-internet-speeds[1]/app-bf-page-container[1]/div[1]/div[1]/app-bf-template-engine[2]/div[1]/app-bf-button-bar[1]/div[1]/div[1]/div[1]/kite-button[1]/button[1]/span[1]/div[1]")
	public
	WebElement continueButton;

	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[1]/div[1]/kite-input[1]/div[1]/div[1]/input[1]")
	public
	WebElement checkoutFname;

	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[2]/app-bf-template-engine[1]/div[1]/app-bf-installation-form-section[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[3]")
	public
	WebElement proInstallCheckbox;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[2]/app-bf-template-engine[1]/div[1]/app-bf-installation-form-section[1]/div[3]/kite-button[1]/button[1]/span[1]")
	public
	WebElement completeOrderButton;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[2]/div[1]/div[1]/kite-input[1]/div[1]/div[1]/input[1]")
	public
	WebElement lastNameField;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[3]/div[1]/div[1]/kite-input[1]/div[1]/div[1]/input[1]")
	public
	WebElement emailField;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[4]/div[1]/div[1]/kite-input[1]/div[1]/div[1]/input[1]")
	public
	WebElement phoneNumberField;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[2]/div[1]/div[1]/kite-radio-group[1]/fieldset[1]/div[1]/kite-radio-button[1]/label[1]/span[1]")
	public
	WebElement phoneTypeMobile;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[2]/div[1]/div[2]/kite-radio-group[1]/fieldset[1]/div[1]/kite-radio-button[1]/label[1]/span[1]")
	public
	WebElement emailPaperless;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[3]/div[1]/div[1]/div[1]/app-bf-optin[1]/div[1]/kite-checkbox[1]/label[1]/span[1]/span[1]/span[1]/*[name()='svg'][1]")
	public
	WebElement textMessageCheckbox;
	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-checkout[1]/app-bf-page-container[1]/div[1]/div[1]/form[1]/section[1]/app-bf-template-engine[1]/div[1]/app-bf-checkout[1]/div[1]/div[1]/div[1]/form[1]/div[4]/div[1]/div[1]/div[1]/div[2]/kite-input[1]/div[1]/div[1]/input[1]")
	public
	WebElement dateOfBirth;

	@FindBy(xpath="/html[1]/body[1]/app-root[1]/div[1]/div[1]/app-internet-speeds[1]/app-bf-page-container[1]/div[1]/div[1]/app-bf-template-engine[1]/div[1]/app-bf-multi-step[1]/div[1]/div[1]/div[4]/app-bf-package-selector[1]/div[1]/div[2]/div[1]/app-bf-checkbox-card[1]/div[1]/div[1]/div[1]/div[3]/div[1]")
	public
	WebElement fiberModemCheckbox;

	@FindBy(xpath="(//img[@class='nav-logo-img w-auto' and @alt='GCI'])[1]")
	public
	WebElement GCI_logo;
	
	@FindBy(xpath="//div[@class='sp-bundleBuilder__item tv-container' and @data-linkname='card-bundletv' and @aria-label='TV from $59.99 per month for 12 months']")
	public WebElement TV_Service;
	
	@FindBy(xpath="//div[@class='sp-bundleBuilder__item internet-container' and @data-linkname='card-bundleinternet' and @aria-label='Internet from $49.99 per month for 12 months']")
	public
	WebElement internet_Service;
	
	@FindBy(xpath="//div[@class='sp-bundleBuilder__item homephone-container' and @data-linkname='card-bundlehomephone' and @aria-label='Home phone from $19.99 per month']")
	public WebElement home_phone_Service;
	
	@FindBy(xpath="(//div[@class='whole p-col'])[1]")
	public
	WebElement TV_monthly_charges;
	
	@FindBy(xpath="(//a[@class='cmp-navigation__item-link' and @data-linkname='Spectrum One' and @href='/packages/spectrum-one'])[1]")
	public WebElement Spectrum_One;
	
	@FindBy(xpath="//img[@class='image-superHero' and @alt='Spectrum One -  Get Internet, FREE Advanced WiFi and 1 FREE Unlimited Mobile line ']")
	public WebElement verify_Spectrum_One_page;
	
	@FindBy(xpath="//*[@id=\"button-5b019c64a1\"]/span")
	public WebElement Get_offer2_button;
	
	@FindBy(id="SpectrumLogo")
	public WebElement verify_address_page;
	
	@FindBy(xpath="//input[@class='form-control' and @name='line1']")
	public WebElement street_address3;
	
	@FindBy(xpath="//input[@class='form-control' and @name='line2']")
	public WebElement Apt_Unit3;
	
	@FindBy(xpath="//*[@id=\"zipcode--data\"]")
	public WebElement zipcode3;
	
	@FindBy(xpath="//*[@id=\"landmark-main\"]/div/div/form/button")
	public WebElement Find_Offers_button;

}
