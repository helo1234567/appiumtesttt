package com.charter;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        dryRun = false,
        strict = true,
        monochrome = true,
        plugin = { "pretty",
                "com.epam.reportportal.cucumber.StepReporter",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
        })
public class BaseRunner {
}
