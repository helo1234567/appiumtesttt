package com.charter.utils;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Iterator;

public class Excel {
    private static String MOCK_FILE_PATH = "mock_datashee.xls";
    private static String LOCATOR_FILE_PATH = "locators_datashee.xls";
    public static String locatorFor(String compoundKey) {

        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];



        try {
            File file;
            try {
                file = getFileFromURL(LOCATOR_FILE_PATH);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                //e.printStackTrace();
                System.out.println("File not found: " + e.getMessage());
                return null;
            }


            FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file
            //creating Workbook instance that refers to .xls file
            Workbook wb;
            if (LOCATOR_FILE_PATH.toLowerCase().endsWith(".xlsx")) {
                wb = new XSSFWorkbook(fis);
            } else {
                wb = new HSSFWorkbook(fis);
            }
            Sheet sheet = wb.getSheet(sheetName);//wb.getSheetAt(0);     //creating a Sheet object to retrieve object

            Iterator<Row> itr = sheet.iterator();    //iterating over excel file

            Integer rowIndex = 0;
            Boolean foundIndex = false;
            while (itr.hasNext())   {
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column

                Integer cellIndex = 0;

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (foundIndex) {
                        return cell.getStringCellValue();
                    }

                    if (cell.getStringCellValue().equals(key)) {
                        foundIndex = true;
                    } else {
                        break;
                    }

                    //System.out.println("CELL: " + cell.getStringCellValue());

                    cellIndex++;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return null;
    }
    private static File getFileFromURL(String filePath) throws URISyntaxException {
        URL url = new Excel().getClass().getClassLoader().getResource(filePath);
        File file = null;
        file = new File(url.toURI());
        return file;
    }
}
