package com.vaf.enumerations;

public enum BrowserType{ 
	CHROME, FIREFOX, EDGE, IE, OPERA, SAFARI
}

