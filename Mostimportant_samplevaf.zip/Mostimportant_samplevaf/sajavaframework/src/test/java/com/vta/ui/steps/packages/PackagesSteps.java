package com.vta.ui.steps.packages;


import com.charter.enumerations.BrowserType;
import com.charter.web.UIManager;
import com.vta.ui.models.packages.PackagesModule;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PackagesSteps {
	UIManager mgr = new UIManager(BrowserType.FF32);
	PackagesModule common_methods = new PackagesModule(mgr.driver);

	@When("enter URL in address bar {string}")
	public void enter_url_in_address_bar(String url) {
		mgr.startSession(url);
	}

	@Then("verify that title page is {string}")
	public void open_website(String title) {
	    String actual_title = mgr.getTitle();
		UIManager.assertEqual(actual_title, title, "verification check");
	}
	
	@Then("close the browser")
	public void close_the_browser() {
	    mgr.endSession();
	}

	@When("hover on packages tab")
	public void hover_on_packages_tab() {
	    mgr.hover(common_methods.packages_tab);
	}

	@And("click on packages tab")
	public void click_on_packages_tab() {
	    mgr.click(common_methods.packages_tab);
	}

	@Then("packages page open {string}")
	public void packages_page_open(String title) {
		String actual_title = mgr.getTitle();
		UIManager.assertEqual(actual_title,title,"verification check");
	    
	}

	@And("dropdown tabs open")
	public void dropdown_tabs_open() {
	    UIManager.assertTrue(common_methods.packages_dropdown.isDisplayed(),"verification check");
	}

	@And("click on shop packages tab")
	public void click_on_shop_packages_tab() {
	    mgr.click(common_methods.dropdown_shop_packages);
	}

	@Then("shop packages page open")
	public void shop_packages_page_open() {
	    UIManager.assertTrue(common_methods.verify_shoppackages_page.isDisplayed(), "verification check");
	}

	@When("scroll down page")
	public void scroll_down_page() throws InterruptedException {
		Thread.sleep(4000);
		mgr.scroll(common_methods.choose_internet_speed_300Mbps, false);
	}

	@And("select 300Mbps internet speed")
	public void select_300mbps_internet_speed() {
	    mgr.click(common_methods.choose_internet_speed_300Mbps);
	}

	@Then("click on Get offer")
	public void click_on_get_offer() {
		mgr.waitUntilVisible(common_methods.Getoffer_button);
	    mgr.click(common_methods.Getoffer_button);
	}

	@When("enter street address in text field")
	public void enter_street_address_in_text_field() {
	    mgr.fillTextField(common_methods.street_address, "71 ST. NICHOLAS DRIVE");
	}
	
	@And("enter Apt number in text field")
	public void enter_Apt_number_in_text_field() {
	    mgr.fillTextField(common_methods.Apt_Unit, "UNIT 9");
	}
	
	@And("enter zipcode in text field")
	public void enter_zipcode_in_text_field() {
	    mgr.fillTextField(common_methods.zipcode, "99705");
	}

	@And("click on GO")
	public void click_on_go() {
	    mgr.click(common_methods.Go_button);
	}

	@Then("verify that out of footprint page is displayed")
	public void verify_that_out_of_footprint_page_is_displayed() {
		mgr.waitUntilVisible(common_methods.out_of_footprint);
	}
	
	@Then("user navigate back to previous page")
	public void user_navigate_back_to_previous_page() throws InterruptedException {
		Thread.sleep(3000);
	   mgr.navigateTo("https://www.spectrum.com/packages");
	}
	
	@When("select 500Mbps internet speed")
	public void select_500mbps_internet_speed() {
	    mgr.click(common_methods.choose_internet_speed_500Mbps);
	}
	
	@When("select 1Gbps internet speed")
	public void select_1gbps_internet_speed() {
	    mgr.click(common_methods.choose_internet_speed_1Gbps);
	}
	
	@When("scroll downs page")
	public void scroll_downs_page() throws InterruptedException {
		Thread.sleep(2000);
		mgr.scroll(common_methods.TV_monthly_charges, false);
	}
	
	@And("select TV service")
	public void select_TV_service() {
		mgr.click(common_methods.TV_Service);
	}
	
	@And("select Internet service")
	public void select_Internet_service() {
		mgr.click(common_methods.internet_Service);
	}
	
	@And("select Home Phone service")
	public void select_Home_Phone_service() {
		mgr.click(common_methods.home_phone_Service);
	}
	
	@And("enter street address2 in text field")
	public void enter_street_address2_in_text_field() {
	    mgr.fillTextField(common_methods.street_address2, "71 ST. NICHOLAS DRIVE");
	}
	
	@And("enter Apt number2 in text field")
	public void enter_Apt_number2_in_text_field() {
	    mgr.fillTextField(common_methods.Apt_Unit2, "UNIT 9");
	}
	
	@And("enter zipcode2 in text field")
	public void enter_zipcode2_in_text_field() {
	    mgr.fillTextField(common_methods.zipcode2, "99705");
	}
	
	@And("click on GO2")
	public void click_on_go2() {
	    mgr.click(common_methods.Go2_button);
	}
	
	@And("click on Spectrum One tab")
	public void click_on_Spectrum_One_tab() {
	    mgr.click(common_methods.Spectrum_One);
	}
	
	@Then("Spectrum One page open")
	public void Spectrum_One_page_open() {
	    UIManager.assertTrue(common_methods.verify_Spectrum_One_page.isDisplayed(), "verification check");
	}
	
	@When("scroll down page spectrum one")
	public void scroll_down_page_spectrum_one() throws InterruptedException {
		Thread.sleep(2000);
		mgr.scroll(common_methods.Get_offer2_button, false);
	}

	@When("click on Get Offer button")
	public void click_on_get_offer_button() {
	    mgr.click(common_methods.Get_offer2_button);
	}
	
	@And("address page open")
	public void address_page_open() {
		mgr.waitUntilVisible(common_methods.verify_address_page);
		UIManager.assertTrue(common_methods.verify_address_page.isDisplayed(), "verification check");
	}
	
	@And("enter street address3 in text field")
	public void enter_street_address3_in_text_field() {
		 mgr.waitUntilVisible(common_methods.street_address3);
		 mgr.fillTextField(common_methods.street_address3, "71 ST. NICHOLAS DRIVE");
	}

	@And("enter Apt number3 in text field")
	public void enter_apt_number3_in_text_field() {
		mgr.waitUntilVisible(common_methods.Apt_Unit3);
		mgr.fillTextField(common_methods.Apt_Unit3, "UNIT 9");
	}

	@And("enter zipcode3 in text field")
	public void enter_zipcode3_in_text_field() {
		mgr.waitUntilVisible(common_methods.zipcode3);
		mgr.fillTextField(common_methods.zipcode3, "99705");
	}

	@And("scroll down address page")
	public void scroll_down_address_page() {
		mgr.scroll(common_methods.Find_Offers_button, false);
	}

	@And("click on Find Offers button")
	public void click_on_find_offers_button() {
	    mgr.click(common_methods.Find_Offers_button);
	}
	
	@Then("verify GCI page")
	public void verify_GCI_page() throws InterruptedException {
		Thread.sleep(40000);
		mgr.waitUntilVisible(common_methods.GCI_logo);
	    UIManager.assertTrue(common_methods.GCI_logo.isDisplayed(), "verification check");
	}
	
	@And("navigate to previous page")
	public void navigate_to_previous_page() {
		mgr.navigateTo("https://www.spectrum.com/packages/spectrum-one");
	}

}
