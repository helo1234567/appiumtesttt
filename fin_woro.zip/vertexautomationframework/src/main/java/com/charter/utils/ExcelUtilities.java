package com.charter.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFRow;
public class ExcelUtilities {

    public static String locatorFor(String filePath, String compoundKey) {

        String sheetName = compoundKey.split("[.]")[0];
        String key = compoundKey.split("[.]")[1];

        try {
            File file = new File(filePath);

            FileInputStream fis = new FileInputStream(file);   //obtaining bytes from the file
            //creating Workbook instance that refers to .xls file
            Workbook wb;
            if (filePath.toLowerCase().endsWith(".xlsx")) {
                wb = new XSSFWorkbook(fis);
            } else {
                wb = new HSSFWorkbook(fis);
            }
            Sheet sheet = wb.getSheet(sheetName);//wb.getSheetAt(0);     //creating a Sheet object to retrieve object

            Iterator<Row> itr = sheet.iterator();    //iterating over excel file

            Integer rowIndex = 0;
            Boolean foundIndex = false;
            while (itr.hasNext())   {
                Row row = itr.next();
                Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column

                Integer cellIndex = 0;

                while (cellIterator.hasNext()) {
                    Cell cell = cellIterator.next();

                    if (foundIndex) {
                        return cell.getStringCellValue();
                    }

                    if (cell.getStringCellValue().equals(key)) {
                        foundIndex = true;
                    } else {
                        break;
                    }

                    //System.out.println("CELL: " + cell.getStringCellValue());

                    cellIndex++;
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }

        return null;
    }

}
