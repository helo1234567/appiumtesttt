package com.spec.runners;

import com.charter.BaseRunner;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

import com.spec.Tests.ui.buyFlow.*;

//@RunWith(Cucumber.class)
//@CucumberOptions(
//		dryRun = false,
//        strict = true,
//        monochrome = true,
//		tags = { "@UITest" },
//		plugin = { "pretty",
//				"com.epam.reportportal.cucumber.StepReporter",
//				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
//		}, features = {
//				"src/test/resources/features/ui"
//		}, glue = {
//				"classpath:com.spec.Tests.ui.buyFlow"
//		})
@RunWith(Cucumber.class)
@CucumberOptions(
		tags = { "@Spectrum_Mobile_Tab" },
		features = { "src/test/resources/features/ui" },
		glue = { "classpath:com.spec.Tests.ui.buyFlow" })
public class RunSpectrumUIAll extends BaseRunner {}
