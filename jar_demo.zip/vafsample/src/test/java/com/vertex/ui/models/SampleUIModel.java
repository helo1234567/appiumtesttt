package com.vertex.ui.models;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SampleUIModel {
    WebDriver driver;


    @FindBy(xpath="//a[contains(text(),' Español ')]")
    public
    WebElement espanol_link;

    @FindBy(xpath="/html/body/app-root/div/div/app-internet-speeds/app-bf-page-container/div/div/app-bf-template-engine[1]/div/app-bf-superhero/div/div/div/div/div[1]")
    public
    WebElement verify_internetplan_page;

    public SampleUIModel(WebDriver d){

        PageFactory.initElements(d,this);
    }


}
