package com.spec.Tests.ui.buyFlow;

import static org.junit.Assert.assertEquals;

import java.time.Duration;

import com.charter.utils.ExcelHSSFUtility;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import cucumber.api.java.en.*;

import com.charter.enumerations.BrowserType;
import com.charter.utils.ConfigUtil;
import com.charter.utils.ConfigUtil.ConfigType;
import com.charter.utils.ExcelXSSFUtility;
import com.charter.web.*;
import com.charter.web.UIManager.LocatorType;

public class BuyFlow {

	UIManager mgr = new UIManager(BrowserType.FF32);

	String packagesLocator = "//a[@title='Packages' and @href='/packages' and @class='cmp-navigation__item-link' and @role='button']";
	String headingLocator  = "//h2[@class='sp-h1 mb-md-5']";


	public WebDriver openChrome() { return new ChromeDriver(); }

	public WebDriver openFirefox() { return  new FirefoxDriver(); }


	@Test
	@When("User navigate to {string}")
	public void navigate_To_URL(String url) {

		mgr.startSession(url);
	}

	@Test
	@When("Maximize the window")
	public void Maximize_window()  {

		mgr.maximizeBrowser();
	}

	@Test
	@Then("Verify that the title of page should be {string}")
	public void Verify_Title(String Page_Title){

		String actual_Title=mgr.getTitle();
		UIManager.assertEqual(actual_Title, Page_Title, "Verify Title is matched or not");
	}

	@Test
	@Then("Close the Browser")
	public void Close_Browser()  {

		mgr.endSession();
	}

	@Test
	@And("User Hover over on {string}")
	public void Hover_Over(String key)  {

		String locator = ExcelHSSFUtility.locatorFor(key);
		mgr.hover(locator);
	}

	@Test
	@Then("Verify that User will see {string} after Hover over")
	public void verify_dropdown_value(String key)  {
		String locator = ExcelHSSFUtility.locatorFor(key);
		String Text=mgr.getText(locator);
		UIManager.assertEqual(key, Text, "Verify dropdown_value is displayed ");

	}





































	@Test
	@Given("I open chrome browser and goto {string}")
	public void seleniumPOC(String url) {
		WebDriver driver = openFirefox();

		driver.get(url);
        
        WebElement packagesLink = driver.findElement(By.xpath(packagesLocator));
        
        packagesLink.click();
        
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(240));
        wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath(headingLocator))));

        driver.quit();

	}


	@Test
	@Given("I open chrome browser through JAR and goto {string}")
	public void jarUITestPOC(String url) {

		mgr.startSession(url);

		mgr.click(packagesLocator);

		mgr.waitUntilVisible(headingLocator, LocatorType.xpath);
		mgr.logScreenshot();

		mgr.endSession();

	}

	@Test
	@Given("I hover and click {string}")
	public void hoverAndClick(String url) {
		mgr.startSession(url);
		String hoverLocator = "//a[@class='cmp-navigation__item-link' and @title='Mobile' and @data-linktype='navigation-1283cba0cb' and @role='button']";
		String clickLocator = "(//a[contains(text(),'Mobile Data Plans')])[1]";//"//ul[@class='cmp-navigation__group show-menu']//a[@title='Tablets'][normalize-space()='Tablets']";
		//WebElement hoverElement =  mgr.elementBy(LocatorType.xpath, hoverLocator);
		//WebElement clickElement =  mgr.elementBy(LocatorType.xpath, clickLocator);
		mgr.hoverAndClick(hoverLocator, clickLocator, LocatorType.xpath);
		mgr.endSession();
	}

	@Given("I open browser and visit {string}")
	public void i_open_browser_and_visit(String url) {
		mgr.startSession(url);
	}

	@Then("I click chat with us")
	public void I_click_chat_with_us(){
		mgr.maximizeBrowser();

//		                    (getAttribute method functionality)
		String element= "//input[@id='address1-desktop']";
		String str1=mgr.getAttribute(element,"placeholder");
		System.out.println("get Attribute is " + str1);
//		String strPlaceholder=element.getAttribute("placeholder");
//		System.out.println("getAttribute is "+ strPlaceholder);
//		System.out.println("get Attribute is"+ element.getAttribute("placeholder"));
//		                    (given below code one tab to another tab switch functionality)
//		WebElement reservation = mgr.elementBy(LocatorType.xpath,"//a[@class='store-loc__store-list-btn-make-appointment' and @aria-label='Make appointment for Spectrum store located at 450 W 33rd St' ]");
//		mgr.click(reservation);
//		mgr.switchToTab(1);
//		mgr.waitImplicit(8000);
//		WebElement verificationpage = mgr.elementBy(LocatorType.xpath,"//span[@class='find-booking-text']");
//		mgr.waitUntilVisible(verificationpage);
//		UIManager.assertTrue(verificationpage.isDisplayed(), "verification check");
//		mgr.click(verificationpage);
//		mgr.switchToTab(0);
//		                       (given below code Switchframe functionality check purpose )
//		WebElement elm = mgr.elementBy(LocatorType.xpath, "//span[@class='asappChatSDKBadge__text']");
//		mgr.waitUntilVisible(elm);
//		mgr.click(elm);
//		mgr.waitImplicit(6000);
//		WebElement frame1=mgr.elementBy(LocatorType.xpath,"//iframe[@class='asappChatSDKFrameEl']");
//		mgr.waitUntilVisible(frame1);
//		mgr.frame(frame1);
//		mgr.waitImplicit(6000);
//		mgr.parentframe();
//		WebElement chat_text= mgr.elementBy(LocatorType.xpath,"//textarea[@class='sc-hLBbgP fEkqIv chatInput__textarea chatInput__textarea_sideBar']");
//		mgr.fillTextField(chat_text,"frame is working");
//		mgr.waitImplicit(6000);
//		WebElement minimize_button=mgr.elementBy(LocatorType.xpath,"//button[@class='sc-bqWxrE vRyBT closeChat chatNavBar__navButton alwaysShowMinimize']");
//		mgr.click(minimize_button);

	}

	@Then("I click the {string} link")
	public void i_click_on_packages_link(String key) {
		String locator = ExcelHSSFUtility.locatorFor(key);
		mgr.click(locator);
	}

	@Then("I wait for the {string} to load")
	public void i_wait_for_packages_page_to_load(String key) {
		String locator = ExcelXSSFUtility.locatorFor(key);
		mgr.waitUntilVisible(locator, LocatorType.xpath);
	}

	@Then("I take a screenshot of the browser window")
	public void i_take_screenshot() {
		mgr.logScreenshot();
	}

	@Then("I close the browser")
	public void i_close_the_browser() {
		mgr.endSession();
	}

	@When("I Fetch {string} Base Endpoint for {string}")
	public void i_fetch_ui_base_endpoints(String etype, String key){
		if(etype.equalsIgnoreCase("API")) {
			System.out.println("API BASE ENDPOINT: " +ConfigUtil.BASE_ENDPOINT(key, ConfigType.APIConfig));
		} else {
			System.out.println("UI BASE ENDPOINT: " +ConfigUtil.BASE_ENDPOINT(key, ConfigType.UIConfig));
		}

		//String locator = ExcelXSSFUtility.locatorFor("Home.nav-link-packages");
		String locator = ExcelXSSFUtility.locatorFor("Packages.banner-heading");
		System.out.println("locator: " + locator);
	}
//	public static void selectFromDropDown(WebElement element , String Visibletext){
//        Select select = new Select(element);
//        select.selectByVisibleText(Visibletext);
//    }

}


//Working

//WebDriver driver = new FirefoxDriver();
//driver.get("http://www.spectrum.com");
//WebElement streetAddressField = driver.findElement(By.cssSelector("input#address1-desktop"));//(By.id("address1-desktop"));
//streetAddressField.sendKeys("New York");

// Working
//driver.get("http://www.spectrum.com");
//WebElement streetAddressField = driver.findElement(By.id("address1-desktop"));
//WebElement zipcodeField = driver.findElement(By.id("zip-desktop"));
//streetAddressField.sendKeys("New York");
//zipcodeField.sendKeys("12312");
//zipcodeField.sendKeys(Keys.RETURN);
//driver.manage().timeouts().implicitlyWait(Duration.ofMillis(50000));
//System.out.println("VIEW: " + driver.findElement(By.xpath("//h3[@class='localization-error__error-text']")).getText() );


// Working
//mgr.startSession(url);
//mgr.click("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");


// Working
//mgr.startSession("https://stackoverflow.com/");
//mgr.click("//a[@class='s-topbar--item s-topbar--item__unset s-btn s-btn__filled ws-nowrap js-gps-track']");
//mgr.endSession();






// SELENIUM CODE

//WebDriver driver = openFirefox();
//
//driver.get(url);
//
//String title = driver.getTitle();
//assertEquals("Web form", title);
//
//driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
//
//WebElement textBox = driver.findElement(By.name("my-text"));
//WebElement submitButton = driver.findElement(By.cssSelector("button"));
//
//textBox.sendKeys("Selenium");
//submitButton.click();
//
//WebElement message = driver.findElement(By.id("message"));
//String value = message.getText();
//assertEquals("Received!", value);
//
//// adding screenshots to log
//ExtentReports extent = new ExtentReports();
//ExtentTest test = extent.createTest("TestName");
//test.fail("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
//
//driver.quit();

