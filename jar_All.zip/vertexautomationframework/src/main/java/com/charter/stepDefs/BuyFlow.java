package com.charter.stepDefs;

import static org.junit.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

import com.charter.enumerations.BrowserType;
import com.charter.utils.ExcelXSSFUtility;
import com.charter.web.*;
import com.charter.web.UIManager.LocatorType;

public class BuyFlow {

	@Test
	@Given("I open chrome browser and goto {string}")
	public void seleniumPOC(String url) {
		WebDriver driver = openFirefox();
		
        driver.get(url);

        String title = driver.getTitle();
        assertEquals("Web form", title);

        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));

        WebElement textBox = driver.findElement(By.name("my-text"));
        WebElement submitButton = driver.findElement(By.cssSelector("button"));

        textBox.sendKeys("Selenium");
        submitButton.click();

        WebElement message = driver.findElement(By.id("message"));
        String value = message.getText();
        assertEquals("Received!", value);
        
       // adding screenshots to log
        ExtentReports extent = new ExtentReports();
        ExtentTest test = extent.createTest("TestName");
        test.fail("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
        
        driver.quit();
        
	}
	
	public WebDriver openChrome() { return new ChromeDriver(); }
	public WebDriver openFirefox() { return  new FirefoxDriver(); }
	
	
	
	
	@Test
	@Given("I open chrome browser through JAR and goto {string}")
	public void jarUITestPOC(String url) {
		
//		WebDriver driver = new FirefoxDriver();
//		driver.get("https://www.spectrum.com/");
//		WebElement Hover_Mobile_Tab = driver.findElement(By.xpath("//a[@role='button' and @title='Mobile']"));
//		WebElement Hover_Mobile_Tab = driver.findElement(By.xpath("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']"));
//		
//		WebElement click_spectrum_Mobile = driver.findElement(By.xpath("(//a[contains(text(),'Spectrum Mobile')])[1]"));
//		
//		WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(40));
//		Actions action = new Actions(driver);
//		wait.until(ExpectedConditions.visibilityOf(Hover_Mobile_Tab));
//		action.moveToElement(Hover_Mobile_Tab).build().perform();
		
//		wait.until(ExpectedConditions.visibilityOf(click_spectrum_Mobile));
		
		UIManager mgr = new UIManager(BrowserType.FF32);
		
		mgr.startSession("http://www.spectrum.com/");
		//mgr.hover("//a[@role='button' and @title='Mobile']");
		mgr.click("(//a[contains(text(),'Spectrum Mobile')])[1]");
		mgr.waitUntilVisible("//h3[@class='sp-h1']", LocatorType.xpath);
		
		mgr.endSession();
		
//		UIManager mgr = new UIManager(BrowserType.FF32);
//		mgr.startSession("http://www.spectrum.com/");
//		mgr.hover("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");
//		mgr.click("//a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");
//		
//		mgr.fillTextField("//input[@id='address1-desktop']", "New York");
//		mgr.fillTextField("//input[@id='zip-desktop']", "12312");
//		
//		mgr.fillTextField("zip-desktop", Keys.RETURN, LocatorType.cssId);
		
		//mgr.click("button-get-offer", LocatorType.cssId);
		//mgr.click("button#button-get-offer", LocatorType.cssSelector);
		//mgr.click("cmp-button__icon--social-icons__facebook", LocatorType.cssClass);
		
		//mgr.endSession();
		
		
		// Working
		
//		WebDriver driver = new FirefoxDriver();
//		driver.get("http://www.spectrum.com");
//		WebElement streetAddressField = driver.findElement(By.cssSelector("input#address1-desktop"));//(By.id("address1-desktop"));
//		streetAddressField.sendKeys("New York");
		
        // Working
//        driver.get("http://www.spectrum.com");
//        WebElement streetAddressField = driver.findElement(By.id("address1-desktop"));
//        WebElement zipcodeField = driver.findElement(By.id("zip-desktop"));
//        streetAddressField.sendKeys("New York");
//        zipcodeField.sendKeys("12312");
//        zipcodeField.sendKeys(Keys.RETURN);
//        driver.manage().timeouts().implicitlyWait(Duration.ofMillis(50000));
//        System.out.println("VIEW: " + driver.findElement(By.xpath("//h3[@class='localization-error__error-text']")).getText() );
        
        
		// Working
//		mgr.startSession(url);
//		mgr.click("a[@class='cmp-navigation__item-link' and @role='button' and @href='/packages']");
		
		
		// Working
//		mgr.startSession("https://stackoverflow.com/");
//		mgr.click("a[@class='s-topbar--item s-topbar--item__unset s-btn s-btn__filled ws-nowrap js-gps-track']");
//		mgr.endSession();
	}
	
	public static void selectFromDropDown(WebElement element , String Visibletext){
        Select select = new Select(element);
        select.selectByVisibleText(Visibletext);
    }
	
	UIManager mgr = new UIManager(BrowserType.FF32);
	
	String packagesLocator = "//a[@title='Packages' and @href='/packages' and @class='cmp-navigation__item-link' and @role='button']";
	String headingLocator  = "//h2[@class='sp-h1 mb-md-5']";
	
	
	@Given("I open browser and visit {string}")
	public void i_open_browser_and_visit(String url) {
		mgr.startSession(url);
	}
	
	@Then("I click the {string} link")
	public void i_click_on_packages_link(String key) {
		String locator = ExcelXSSFUtility.locatorFor(key);
		mgr.click(locator);
	}
	
	@Then("I wait for the {string} to load")
	public void i_wait_for_packages_page_to_load(String key) {
		String locator = ExcelXSSFUtility.locatorFor(key);
		mgr.waitUntilVisible(locator, LocatorType.xpath);
	}
	
	@Then("I take a screenshot of the browser window")
	public void i_take_screenshot() {
		mgr.logScreenshot();
	}
	
	@Then("I close the browser")
	public void i_close_the_browser() {
		mgr.endSession();
	}
}
