package com.vta.shared.runners;


import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="src/test/resources/Features/UI/Mobile",
		glue={"com.vta.ui.steps.mobile"},
		tags = {"@Spectrum_Mobile_Tab"}

)

public class RunnerMobile {
	

}
