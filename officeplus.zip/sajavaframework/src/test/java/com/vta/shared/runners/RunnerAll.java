package com.vta.shared.runners;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		tags = {"@Debug"},
		features="src/test/resources/Features/UI",
		glue={"com.vta.ui.steps.tv"})
public class RunnerAll {}
