package com.vta.ui.models.mobile;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MobileModule {
	
WebDriver driver;

	@FindBy(xpath="//a[contains(text(),' Find a Store ')]")
	public
	WebElement Find_Store;

	@FindBy(xpath="//h2[contains(text(),' Visit Your Local Spectrum Store')]")
	public
	WebElement visit_store;

	@FindBy(xpath="//a[contains(text(),' Manage Account ')]")
	public
	WebElement Manage_Account;


	@FindBy(id="login-button")
	public
	WebElement Sign_in;


	@FindBy(xpath="//a[contains(text(),' Español ')]")
	public
	WebElement Espanol;

	@FindBy(xpath="//input[@id='zip-desktop']")
	public
	WebElement Espanol_zipcode;

	@FindBy(xpath="//h2[contains(text(),'Stream Anywhere with Spectrum')]")
	public
	WebElement Stream_Tv;

	@FindBy(id="icon-tv-mediumblue-2")
	public
	WebElement TV_icon;

	@FindBy(xpath="//div[@data-testid='bf-terms-conditions-2.copy-0']")
	public
	WebElement Terms_conditions;

	@FindBy(xpath="//span[contains(text(),' GET 500 MBPS ')]")
	public
	WebElement Get_500_MBps;
////div[@class='bf-checkbox-card__container--item']//preceding::kite-checkbox[@data-testid='bf-checkbox-card-0.checkbox-id']
	@FindBy(xpath="/html/body/app-root/div/div/app-localization/app-bf-page-container/div/div/app-bf-template-engine[1]/div/app-bf-multi-step/div/div/div[4]/app-bf-package-selector/div/div/div[1]/app-bf-checkbox-card/div[1]/div/div[2]/div")
	public
	WebElement Internet_plan_check_button;

	@FindBy(xpath="//div[contains(text(),'Build custom plan')]")
	public
	WebElement Build_custom_plan;

	@FindBy(xpath="//input[@placeholder='Street Address']")
	public
	WebElement Street_Address;

	@FindBy(xpath="//input[@placeholder='Apt/Unit']")
	public
	WebElement APT_Unit;

	@FindBy(xpath="//input[@placeholder='Zip Code']")
	public
	WebElement Zip_code;

	@FindBy(xpath="(//div[@class='bf-checkbox-card__group']//preceding::kite-button[@class='angular-kite-button bf-checkbox-card__button--control'])[1]")
	public
	WebElement Select_Button;

	@FindBy(xpath="//div[@data-testid='bf-checkbox-card-0.checkbox-container']")
	public
	WebElement Select_modem;

	@FindBy(xpath="//div[@data-testid='bf-button-bar-1.label-0']")
	public
	WebElement continue_button;

	@FindBy(xpath="//input[@placeholder='First Name']")
	public
	WebElement First_name;

	@FindBy(xpath="//input[@placeholder='Last Name']")
	public
	WebElement Last_name;

	@FindBy(xpath="//input[@placeholder='Email Address']")
	public
	WebElement email_addresss;

	@FindBy(xpath="//input[@placeholder='Phone Number']")
	public
	WebElement phone_number;

	@FindBy(xpath="(//span[@class='kite-radio__indicator'])[1]")
	public
	WebElement phone_type;

	@FindBy(id="radio-button-7-input")
	public
	WebElement yes_no;

	@FindBy(id="radio-button-11-input")
	public
	WebElement email_notified;

	@FindBy(xpath="//input[@id='checkbox-29']")
	public
	WebElement check_to_proceed;

	@FindBy(xpath="(//button[@class='kite-button kite-button--shrinkwrap kite-button--lg kite-button--primary']//child::span[@class='kite-button__inner'])[1]")
	public
	WebElement complete_order;

	@FindBy(xpath="//input[@placeholder='MM/DD/YYYY']")
	public
	WebElement calender;

	@FindBy(xpath="//span[@data-date='1680667200000']")
	public
	WebElement select_date;

	@FindBy(xpath="//button[@class='button prev-button prev-btn']")
	public
	WebElement prev_month;

	@FindBy(id="icon-voice-mediumblue-2")
	public
	WebElement Voice_link_icon;

	@FindBy(xpath="//h2[contains(text(),' SPECTRUM VOICE®')]")
	public
	WebElement spectrum_voice;

	@FindBy(xpath="//div[@data-testid='bf-price-visual-0.rate']")
	public
	WebElement Fifty_Dollar;





























	@FindBy(xpath="//a[@role='button' and @title='Mobile']")
	public
	WebElement Hover_Mobile_Tab;
	
	@FindBy(xpath="(//a[contains(text(),'Spectrum Mobile')])[1]")
	public
	WebElement click_spectrum_Mobile;
	
	@FindBy(xpath="//div[@class='spectrum-logo-container false']")
	public
	WebElement Spectrum_mobile_logo;
	
	@FindBy(xpath="//a[@id='collapsible-nav-dropdown-1']")
	public
	WebElement Hover_over_product;
	
	@FindBy(xpath="//a[@class='dropdown-item' and @data-linkname='Phones']")
	public
	WebElement Select_phones;
	
	@FindBy(xpath="//h1[contains(text(),'Shop the Newest Smartphones')]")
	WebElement shop_newest_phones;
	
	@FindBy(xpath="//a[@id='button-3c1e52eb88']")
	public
	WebElement shop_now;
	
	@FindBy(xpath="//li[@id='APL']")
	public
	WebElement iphone_tab;
	
	@FindBy(xpath="//h1[contains(text(),'Shop New Apple iPhones')]")
	public
	WebElement iphone_apple_des;
	
	@FindBy(xpath="//img[@alt='Apple iPhone 14 Pro Max Deep Purple']")
	public
	WebElement iphone_14_promax;
	
	@FindBy(xpath="//button[@aria-label='Gold' and @title='Gold']")
	public
	WebElement select_iphone_colcor;
	
	@FindBy(xpath="//span[contains(text(),'256 GB')]")
	public
	WebElement select_storage;
	
	@FindBy(xpath="//li[@aria-label='slide item 2']")
	public
	WebElement choose_second_picture;
	
	@FindBy(xpath="//span[contains(text(),'when it ships')]")
	public
	WebElement when_ship;
	
	@FindBy(xpath="//span[contains(text(),'$15/mo plus tax, if applicable')]")
	public
	WebElement protection_plan;
	
	@FindBy(xpath="//button[contains(text(),'Add Trade-In')]")
	public
	WebElement Add_TradeIn;
	
	@FindBy(xpath="//div[contains(text(),'Trade-In')]")
	public
	WebElement TradeIn_logo;
	
	@FindBy(xpath="//img[@alt='ATT']")
	public
	WebElement select_ATT;
	
	@FindBy(xpath="//img[@alt='Apple']")
	public
	WebElement select_apple;
	
	@FindBy(xpath="//input[@id='modelAutoComplete']")
	public
	WebElement inputfield;
	
	@FindBy(xpath="//li[contains(text(),'IPAD 10 10.9')]")
	public
	WebElement select_fromdropdown;
	
	@FindBy(xpath="//button[contains(text(),'256GB')]")
	public
	WebElement storage;
	
	@FindBy(xpath="//button[contains(text(),'CONTINUE')]")
	public
	WebElement click_continue;
	
	@FindBy(xpath="//input[@name='imeiNumber']")
	public
	WebElement imei_Number;
	
	@FindBy(xpath="//input[@name='DAM_FREE_CTI' and @value='DAMF_YES']")
	public
	WebElement click_yes;
	
	@FindBy(xpath="//input[@name='LCD_GOOD_CTI' and @value='LCDG_YES']")
	public
	WebElement second_yes;
	
	@FindBy(xpath="//input[@name='NO_LIQUID_CTI' and @value='NOLIQ_NO']")
	public
	WebElement first_No;
	
	@FindBy(xpath="//input[@name='NO_LIQUID_CTI' and @value='NOLIQ_YES']")
	public
	WebElement third_yes;
	
	@FindBy(xpath="//input[@name='POWER_ON_CTI' and @value='POWER_YES']")
	public
	WebElement fourth_yes;
	
	@FindBy(xpath="//input[@name='POWER_ON_CTI' and @value='POWER_NO']")
	public
	WebElement second_no;
	
	@FindBy(xpath="//div[contains(text(),'This device is not eligible for Trade-In.')]")
	WebElement message;
	
	@FindBy(xpath="//button[contains(text(),'Cancel')]")
	public
	WebElement cancel;
	
	@FindBy(xpath="//button[text()='NO, SHOP INTERNET']")
	public
	WebElement shop_internet;
	
	@FindBy(xpath="//button[@class='cmp-button' and @data-linktype='orange_button']")
	public
	WebElement order_now1;
	
	
	@FindBy(xpath="//button[@class='show-more']")
	public
	WebElement show_less;
	
	@FindBy(xpath="//input[@name='line1']")
	public
	WebElement enter_address;
	
	@FindBy(xpath="//input[@name='line2']")
	public
	WebElement app_unit;
	
	@FindBy(xpath="//input[@name='postalCode']")
	public
	WebElement zipcode;
	
	@FindBy(xpath="//button[@value='Find Offers']")
	public
	WebElement find_finder;
	
	@FindBy(xpath="//div[contains(text(),'S Park Ave, Fl 26, 10016')]")
	public
	WebElement location;
	
	@FindBy(xpath="//button[text()='YES, SIGN IN']")
	public
	WebElement sign_in;
	
	@FindBy(xpath="//a[contains(text(),'Create a Username')]")
	public
	WebElement create_user;
	
	@FindBy(xpath="//input[@id='contact-info-input']")
	public
	WebElement email_address;
	
	@FindBy(xpath="//input[@id='cc-username']")
	public
	WebElement login_email;
	
	@FindBy(xpath="//input[@id='cc-user-password']")
	public
	WebElement login_password;
	
	@FindBy(xpath="//button[@size='lg']")
	public
	WebElement click_signin;
	
	
	@FindBy(xpath="//div[@class='recaptcha-checkbox-border']")
	public
	WebElement recaptcha;
	
	@FindBy(xpath="//button[@class='kite-btn kite-btn-primary kite-btn-lg']")
	public
	WebElement click_next;
	
	@FindBy(xpath="//h3[@class='localization-error__error-text']")
	public
	WebElement large_text;
	
	@FindBy(id="title-bf9fd1c3f8")
	public
	WebElement shop_newphone;
	
	@FindBy(id="title-8679fcab7a")
	public
	WebElement shop_newapplephone;
	
	@FindBy(xpath="//h1[contains(text(),'Are You a Spectrum Customer?')]")
	public
	WebElement pectrumornot;
	
	@FindBy(xpath="//div[@class='ngk-alert-inline-wrapper']")
	public
	WebElement error_message;
	
	@FindBy(xpath="//a[contains(text(),'Motorola')]")
	public
	WebElement motorola_tab;
	
	@FindBy(xpath="//a[contains(text(),'Google')]")
	public
	WebElement Google_tab;
	
	@FindBy(xpath="//a[contains(text(),'Samsung')]")
	public
	WebElement samsung_tab;
	
	@FindBy(xpath="//li[@id='Deal']")
	public
	WebElement Deals_tab;
	
	@FindBy(xpath="//button[@class='btn-previous']")
	public
	WebElement previuos_tab;
	
	@FindBy(xpath="//button[contains(text(),'APPLY')]")
	public
	WebElement apply;
	
	@FindBy(xpath="//a[contains(text(),'Price Low-High')]")
	public
	WebElement price_low_tohigh;
	
	@FindBy(xpath="//a[contains(text(),'Featured')]")
	public
	WebElement Featured;
	
	@FindBy(xpath="//a[contains(text(),'Price High-Low')]")
	public
	WebElement price_high_Low;

	
	@FindBy(xpath="//button[@data-linkname='cta_button_CONTINUE_device-description-out-of-stock']")
	public
	WebElement press_continue;
	
	@FindBy(xpath="//button[@id='dropdown-basic-button-sortBy']")
	public
	WebElement Dropdown;
	
	public MobileModule(WebDriver d){
		
		PageFactory.initElements(d,this);
}
	
	

}
