package com.vaf.api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import com.vaf.utils.Excel_Api;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import org.apache.http.HttpStatus;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.testng.annotations.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class APIManager {

    public Response PostRequest(String key1, String key2, String key3, String key4) throws IOException {
        RestAssured.baseURI = "https://rahulshettyacademy.com";
        JSONObject headerJson = new JSONObject(key3);
        Map<String, String> headers = new HashMap<>();

        // Extract key-value pairs from the JSON object and store them in the HashMap
        Iterator<String> keys = headerJson.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            String value = headerJson.getString(key);
            headers.put(key, value);
        }



        Response response = given().queryParam(key2)
                .headers(headers)
                .body(key1)
                .when()
                .post(key4)
                .then()
                .log().all()
                .assertThat()
                .statusCode(200)
                .extract()
                .response();
                return response;


    }
public void update(Response response,String placeid,String key2,Integer index) throws IOException {

    JSONObject responseJson = new JSONObject(response.getBody().asString());
    String placeId = responseJson.getString(placeid);
    updatePlaceIdInExcel("C:\\Users\\DELL\\Documents\\api\\demodata.xlsx", "testdata", key2, placeId,index,placeid);
    }





    public void updatePlaceIdInExcel(String excelFilePath, String sheetName, int cellRowNum, int cellColNum, String placeId) throws IOException {
        FileInputStream fis = new FileInputStream(new File(excelFilePath));
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        // Get the specified cell and parse the JSON string
        Row row = sheet.getRow(cellRowNum);
        Cell cell = row.getCell(cellColNum, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
        cell.setCellType(CellType.STRING);
        String jsonCellData = cell.getStringCellValue();

        // Parse the JSON string into a JSONObject
        JSONObject jsonObject = new JSONObject(jsonCellData);

        // Update the place ID value in the JSONObject
        jsonObject.put("place_id", placeId);

        // Update the cell value with the modified JSON string
        cell.setCellValue(jsonObject.toString());

        fis.close();

        FileOutputStream fos = new FileOutputStream(new File(excelFilePath));
        workbook.write(fos);
        workbook.close();
        fos.close();
    }

    public void updatePlaceIdInExcel(String excelFilePath, String sheetName, String key, String placeId, int index,String place_id) throws IOException {
        FileInputStream fis = new FileInputStream(new File(excelFilePath));
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        // Find the row based on the key value in the first column
        int rowIndex = findRowIndex(sheet, key);

        if (rowIndex != -1) {
            // Get the row at the found index
            Row row = sheet.getRow(rowIndex);

            // Get the cell at the specified index
            Cell cell = row.getCell(index, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            cell.setCellType(CellType.STRING);

            // Get the JSON string from the cell
            String jsonCellValue = cell.getStringCellValue();

            // Parse the JSON string into a JSONObject
            JSONObject jsonObject = new JSONObject(jsonCellValue);

            // Update the place ID value in the JSONObject
            jsonObject.put(place_id, placeId);

            // Update the cell value with the modified JSON string
            cell.setCellValue(jsonObject.toString());
        } else {
            // Handle the case where the key is not found in the first column
            System.out.println("Key not found: " + key);
        }

        fis.close();

        FileOutputStream fos = new FileOutputStream(new File(excelFilePath));
        workbook.write(fos);
        workbook.close();
        fos.close();
    }

    public int findRowIndex(Sheet sheet, String key) {
        for (Row row : sheet) {
            Cell cell = row.getCell(0, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
            cell.setCellType(CellType.STRING);
            String cellValue = cell.getStringCellValue();
            if (cellValue.equalsIgnoreCase(key)) {
                return row.getRowNum();
            }
        }
        return -1; // Key not found
    }

    public void updatePlaceIdsInExcel(String excelFilePath, String sheetName, String key, Map<String, String> placeIds, int index) throws IOException {
        FileInputStream fis = new FileInputStream(new File(excelFilePath));
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        // Find the row based on the key value in the first column
        int rowIndex = findRowIndex(sheet, key);

        if (rowIndex != -1) {
            // Get the row at the found index
            Row row = sheet.getRow(rowIndex);

            // Iterate over the placeIds map
            for (Map.Entry<String, String> entry : placeIds.entrySet()) {
                String placeIdKey = entry.getKey();
                String placeIdValue = entry.getValue();

                // Get the cell at the specified index
                Cell cell = row.getCell(index, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                cell.setCellType(CellType.STRING);

                // Get the JSON string from the cell
                String jsonCellValue = cell.getStringCellValue();

                // Parse the JSON string into a JSONObject
                JSONObject jsonObject = new JSONObject(jsonCellValue);

                // Update the place ID value in the JSONObject
                jsonObject.put(placeIdKey, placeIdValue);

                // Update the cell value with the modified JSON string
                cell.setCellValue(jsonObject.toString());
            }
        } else {
            // Handle the case where the key is not found in the first column
            System.out.println("Key not found: " + key);
        }

        fis.close();

        FileOutputStream fos = new FileOutputStream(new File(excelFilePath));
        workbook.write(fos);
        workbook.close();
        fos.close();
    }
}
