package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class final_collect {

    public static void main(String[] args) {
        // ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Excel file path
        String excelFilePath = "D:\\exce\\asad.xlsx";

        // Sheet name where URLs are present
        String sheetName = "Sheet1";

        // Column index where URLs are present (0-based)
        int urlColumn = 0;

        // Column index where image names should be collected
        int nameColumn = 3;

        // Column index where image src attributes should be collected
        int srcColumn = 2;

        // Create ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            FileInputStream fis = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            // Iterate over the URLs
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next(); // Skip header row

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Cell urlCell = row.getCell(urlColumn);
                String url = urlCell.getStringCellValue();

                // Get the maxIterations value from the second column of the current row
                Cell iterationsCell = row.getCell(1);
                int maxIterations = (int) iterationsCell.getNumericCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(7000);

                WebElement rightArrow = driver.findElement(By.xpath("//*[@id=\"page-e41f866d9a\"]/div[1]/div/div[3]/div/div[8]/compatible-products/section/div/div/a[2]/span[1]"));
                WebElement rightArrows = driver.findElement(By.xpath("(//span[contains(text(),'White')])[1]"));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                boolean scrollIntoView = false;
                js.executeScript("arguments[0].scrollIntoView(" + (scrollIntoView ? "true" : "false") + ")", rightArrows);
                // Collect image names and src attributes
                Thread.sleep(10000);
                List<String> newSrcAttributes = new ArrayList<>();

                // Scroll and fetch data for the specified number of iterations
                for (int i = 0; i < maxIterations; i++) {
                    // Find all the visible images on the page
                    List<WebElement> images = driver.findElements(By.xpath("//img[@class='col-lg-3 image compatible-product']"));
                    for (WebElement image : images) {
                        String src = image.getAttribute("src");
                        newSrcAttributes.add(src);
                    }

                    // Click the right arrow and wait
                    rightArrow.click();
                    Thread.sleep(2000);
                }

                // Update the corresponding columns with src attributes
                int currentRow = row.getRowNum();
                int newSrcAttributesSize = newSrcAttributes.size();
                int numRowsToUpdate = Math.min(newSrcAttributesSize, maxIterations);

                for (int i = 0; i < numRowsToUpdate; i++) {
                    String src = newSrcAttributes.get(i);
                    Row currentRowToUpdate = sheet.getRow(currentRow);
                    Cell srcCell = currentRowToUpdate.getCell(srcColumn);
                    if (srcCell == null) {
                        srcCell = currentRowToUpdate.createCell(srcColumn);
                    }

                    // Set the src attribute value
                    srcCell.setCellValue(src);
                }
            }

            // Write the updated workbook back to the file
            FileOutputStream fos = new FileOutputStream(excelFilePath);
            workbook.write(fos);
            fos.close();

            System.out.println("Data collection completed and saved to the Excel file.");

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Quit the ChromeDriver
            driver.quit();
        }
    }
}