package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class yes {

    public static void main(String[] args) {
        // ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Excel file path
        String excelFilePath = "D:\\exce\\asad.xlsx";

        // Sheet name where URLs are present
        String sheetName = "Sheet1";

        // Column index where URLs are present (0-based)
        int urlColumn = 0;

        // Column index where data should be stored (0-based)
        int dataColumn = 1;



        // Create ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            FileInputStream fis = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            // Iterate over the URLs
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next(); // Skip header row

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Cell urlCell = row.getCell(urlColumn);
                String url = urlCell.getStringCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(7000);

                // Find the elements using XPath
                List<WebElement> elements = driver.findElements(By.xpath("//img[@class='col-lg-3 image compatible-product']"));

                // Extract data from each element and store in the ArrayList
                List<String> dataList = new ArrayList<>();
                for (WebElement element : elements) {
                    String data = element.getAttribute("src");
                    dataList.add(data);
                }

                // Write the data to the corresponding row
                int currentRow = row.getRowNum();
                for (int i = 0; i < dataList.size(); i++) {
                    String extractedData = dataList.get(i);
                    Cell dataCell = sheet.getRow(currentRow + i).createCell(dataColumn);
                    dataCell.setCellValue(extractedData);
                }
            }

            // Write the modified workbook back to the Excel file
            FileOutputStream fos = new FileOutputStream(excelFilePath);
            workbook.write(fos);
            fos.close();

            System.out.println("Data extraction completed successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Quit the WebDriver
            driver.quit();
        }
    }

}
