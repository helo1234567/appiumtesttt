package HomeTask;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;


import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Object_Class {
	
WebDriver driver;
	
@FindBy(xpath="//a[@role='button' and @title='Mobile']")
public
WebElement Hover_Mobile_Tab;
	

	@FindBy(xpath="//a[@id='collapsible-nav-dropdown-1']")
	public
	WebElement Click_product;
	
	@FindBy(xpath="//h1[contains(text(),'Shop the Newest Smartphones')]")
	WebElement shop_newest_phones;
	
	@FindBy(xpath="//h2[@class='name']")
	WebElement All_Phones_names;
	
	@FindBy(xpath="//a[@aria-label='Next Page']")
	WebElement Next_page;
	
	

	
	
	
	
	    public Object_Class(WebDriver d){
		this.driver=d;
		PageFactory.initElements(d,this);
	}
	   
   
	  public void clicklaptop(String key,String key2,Integer key3) throws InterruptedException, IOException, AWTException {
		  driver.get(key);
		  driver.manage().window().maximize();
		   WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(35));

		   Thread.sleep(15000);
		   ArrayList<String> Price=new ArrayList<String>(); 
		   ArrayList<String> Tnames=new ArrayList<String>();
		  ArrayList<String> Linkes=new ArrayList<String>();
		  ArrayList<String> URL=new ArrayList<String>();
		  ArrayList<String> Next_Page_URL=new ArrayList<String>();
		  boolean scrollIntoView=false;
		   for(int m=0;m<key3;m++) {
	  
		   
		   List<WebElement> Mobilenames=driver.findElements(By.className("name"));
		   for(WebElement e:Mobilenames) {
			   String names=e.getText();
			   Tnames.add(names);
			 
			  
		   }
			   List<WebElement> URLs=driver.findElements(By.xpath("//img[@class='product-image img-responsive img-fluid']"));
			   for(WebElement e:URLs) {
				   String namess=e.getAttribute("url");
				   URL.add(namess);

			   }
		   
		   
		   List<WebElement> Prices=driver.findElements(By.xpath("//img[@class='product-image img-responsive img-fluid']"));
		   for(WebElement e:Prices) {
			   String price1=e.getAttribute("srcset");
			   Price.add(price1);
			   
		   }

			   List<WebElement> Link=driver.findElements(By.xpath("//img[@class='product-image img-responsive img-fluid']"));
			   for(WebElement e:Link) {
				   String price2=e.getAttribute("src");
				   Linkes.add(price2);

			   }
			   List<WebElement> NextURL=driver.findElements(By.xpath("//a[@class='parentWrap']"));
			   for(WebElement e:NextURL) {
				   String price3=e.getAttribute("href");
				   Next_Page_URL.add(price3);

			   }



		  if((m+1)<key3) {
		   JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")",Next_page );
		   Next_page.click();
		   Thread.sleep(15000);
		  }
		   }	   
	   
		   
		   	XSSFWorkbook workbook1=new XSSFWorkbook();
			XSSFSheet sheet1=workbook1.createSheet("Sheet1");
			
			sheet1.createRow(0);
			
			sheet1.getRow(0).createCell(0).setCellValue("Names");
			
			sheet1.getRow(0).createCell(1).setCellValue("SrcTestLink");

		  	sheet1.getRow(0).createCell(2).setCellValue("SrcLink");
		  	sheet1.getRow(0).createCell(3).setCellValue("Url");
		  sheet1.getRow(0).createCell(3).setCellValue("Next_Page_Url");
			
			for(int i=1;i<Tnames.size();i++) {
				DataFormatter df=new DataFormatter();
				sheet1.createRow(i);
				sheet1.getRow(i).createCell(0).setCellValue(Tnames.get(i));
			}
				for(int i=1;i<Price.size();i++) {
					DataFormatter df=new DataFormatter();
					sheet1.getRow(i).createCell(1).setCellValue(Price.get(i));
					
				}
				for(int i=1;i<Linkes.size();i++) {
			  DataFormatter df=new DataFormatter();
			  sheet1.getRow(i).createCell(2).setCellValue(Linkes.get(i));

		  }

		  for(int i=1;i<Linkes.size();i++) {
			  DataFormatter df=new DataFormatter();
			  sheet1.getRow(i).createCell(3).setCellValue(URL.get(i));

		  }

		  for(int i=1;i<Next_Page_URL.size();i++) {
			  DataFormatter df=new DataFormatter();
			  sheet1.getRow(i).createCell(4).setCellValue(Next_Page_URL.get(i));

		  }

			File fil=new File(key2);
			FileOutputStream fos=new FileOutputStream(fil);
			workbook1.write(fos);
		   

	}
	  

}
