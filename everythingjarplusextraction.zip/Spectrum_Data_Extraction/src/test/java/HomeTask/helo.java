package HomeTask;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class helo {

    public static void main(String[] args) {
        // ChromeDriver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32\\chromedriver.exe");

        // Excel file path
        String excelFilePath = "C:\\Users\\DELL\\Downloads\\asaddataextraction\\roug.xlsx";

        // Sheet name where URLs are present
        String sheetName = "Sheet1";

        // Column index where URLs are present (0-based)
        int urlColumn = 0;

        // Column index where image names should be collected
        int nameColumn = 1;

        // Column index where image src attributes should be collected
        int srcColumn = 2;

        // Create ChromeDriver
        WebDriver driver = new ChromeDriver();

        try {
            FileInputStream fis = new FileInputStream(excelFilePath);
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheet(sheetName);

            // Iterate over the URLs
            Iterator<Row> rowIterator = sheet.iterator();
            rowIterator.next(); // Skip header row

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Cell urlCell = row.getCell(urlColumn);
                String url = urlCell.getStringCellValue();

                // Navigate to the URL
                driver.get(url);
                driver.manage().window().maximize();
                Thread.sleep(7000);
                //proddescdisclaimer aem-GridColumn aem-GridColumn--default--12
                //(//span[contains(text(),'White')])[1]
                // Find the right arrow element
                WebElement rightArrow = driver.findElement(By.xpath("//*[@id=\"page-e41f866d9a\"]/div[1]/div/div[3]/div/div[8]/compatible-products/section/div/div/a[2]/span[1]"));
                WebElement rightArrows=driver.findElement(By.xpath("(//span[contains(text(),'White')])[1]"));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                boolean scrollIntoView=false;
                js.executeScript("arguments[0].scrollIntoView("+ (scrollIntoView ? "true" : "false") +")",rightArrows );
                // Collect image names and src attributes
                Thread.sleep(5000);
                List<String> names = new ArrayList<>();
                List<String> srcAttributes = new ArrayList<>();

                // Scroll and fetch data until the right arrow becomes disabled
                while (rightArrow.isEnabled()) {
                    // Find all the visible images on the page
                    List<WebElement> images = driver.findElements(By.xpath("//div[@class='product-card-image']"));
                    for (WebElement image : images) {
                        //String name = image.getAttribute("name");
                        String src = image.getAttribute("src");
                        //names.add(name);
                        srcAttributes.add(src);
                    }

                    // Click the right arrow
                    rightArrow.click();
                    Thread.sleep(2000);
                }

                // Update the corresponding columns with image names and src attributes
                Cell nameCell = row.createCell(nameColumn, CellType.STRING);
                Cell srcCell = row.createCell(srcColumn, CellType.STRING);
               // nameCell.setCellValue(String.join(", ", names));
                srcCell.setCellValue(String.join(", ", srcAttributes));
            }

            // Save the updated workbook
            FileOutputStream fos = new FileOutputStream(excelFilePath);
            workbook.write(fos);
            fos.close();

            System.out.println("Data fetched and updated successfully!");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            // Quit the driver
            driver.quit();
        }
    }
}

