package com.spec.runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		dryRun = false,
        strict = true,
        monochrome = true,
		tags = { "@UITest" },
		plugin = { "pretty", 
				"com.epam.reportportal.cucumber.StepReporter",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
		}, features = {
				"src/test/resources/features/api"
		}, glue = { 
				"com.spec.Tests" 
		})
public class RunSpectrumApi {
}