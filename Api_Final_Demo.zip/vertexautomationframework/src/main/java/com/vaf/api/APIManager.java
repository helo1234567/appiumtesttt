package com.vaf.api;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import com.vaf.utils.Excel_Api;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.apache.http.HttpStatus;
import org.hamcrest.Matchers;
import org.hamcrest.core.Is;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;


public class APIManager {


public Response PostRequest(String key1, String key2, String key3, String key4) throws IOException {
    RestAssured.baseURI = "https://rahulshettyacademy.com";

    Response response = given().queryParam("key", key2)
            .header("Content-Type", key3)
            .body(key1)
            .when()
            .post(key4)
            .then()
            .log().all()
            .assertThat()
            .statusCode(200)
            .extract()
            .response();

    return response;
}
    public Response GetRequest(String key1, String key2, String key3, String key4) {
        RestAssured.baseURI = "https://rahulshettyacademy.com";

        Response response = given()
                .queryParam(key2,key1)
                .queryParam("key",key3)
                .when()
                .get(key4)
                .then()
                .log().all()
                .assertThat()
                .statusCode(200)
                .extract()
                .response();

        return response;
    }

	
	
}
