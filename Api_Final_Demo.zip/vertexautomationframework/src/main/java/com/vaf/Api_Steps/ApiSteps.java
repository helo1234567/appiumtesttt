package com.vaf.Api_Steps;

import com.vaf.api.APIManager;
import com.vaf.utils.Excel_Api;
import cucumber.api.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class ApiSteps {
    Excel_Api excelApi = new Excel_Api();
    APIManager mgr = new APIManager();
    private Response postresponse;
    private Response getresponse;
    @Test
    @And("User send post request to Add place in {string}")
    public void Post_Request(String key) throws IOException {

        ArrayList<String> data = excelApi.getData(key);
        postresponse=mgr.PostRequest(data.get(1),data.get(3),data.get(5),data.get(6));

    }

    @Test
    @And("Set the {string} in {string} on Index <{int}>")
    public void Set_ID_In_Excel(String key1,String key2,Integer key3) throws IOException {
        updateExcelData("testdata", key2,key3, postresponse.jsonPath().get(key1).toString());

    }

    @Test
    @And("Verify that status code must be <{int}>")
    public void Status_code(Integer key) throws IOException {
        int statusCode = postresponse.getStatusCode();
        Assert.assertEquals(key, statusCode);


    }

    @Then("Validate that the {string} must be {string}")
    public void validatePlaceId(String key, String expectedPlaceId) throws IOException {
        JsonPath jsonPath = postresponse.jsonPath();
        String actualPlaceId = jsonPath.get(key);
        System.out.println(actualPlaceId);
        //Assert.assertEquals(expectedPlaceId, actualPlaceId);

    }

    @And("User send get request to retrieve place details by sending new {string} in {string}")
    public void sendGetRequest(String key1,String key2) throws IOException {
        ArrayList<String> data = excelApi.getData(key2);
        JsonPath jsonPath = postresponse.jsonPath();
        String placeId = jsonPath.get(key1);
        getresponse = mgr.GetRequest(data.get(7),key1,data.get(3),data.get(6));
    }

    private void updateExcelData(String sheetName, String testCaseName, int columnIndex, String value) throws IOException {
        FileInputStream fis = new FileInputStream("C:\\Users\\DELL\\Documents\\Asad\\demodata.xlsx");
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        // Find the row for the given test case name
        for (Row row : sheet) {
            Cell cell = row.getCell(0); // Assuming the test case names are in the first column (index 0)
            if (cell.getStringCellValue().equalsIgnoreCase(testCaseName)) {
                Cell valueCell = row.createCell(columnIndex);
                valueCell.setCellValue(value);
                break;
            }
        }

        // Write changes back to the Excel file
        FileOutputStream fos = new FileOutputStream("C:\\Users\\DELL\\Documents\\Asad\\demodata.xlsx");
        workbook.write(fos);
        fos.close();
        workbook.close();
    }
}
